import React, { useState, useEffect } from 'react';
import { GameItem, OnlineRoomData, ChatMessage } from '../types/game';
import { soundManager } from '../lib/sound';
import { Users, Send, Copy, Check, Play, Globe, X, MessageSquare, Shield, Sparkles } from 'lucide-react';

interface Props {
  game?: GameItem;
  onClose: () => void;
  onStartOnlineGame?: (roomData: OnlineRoomData, wsSocket: WebSocket) => void;
}

export const OnlineLobbyModal: React.FC<Props> = ({ game, onClose, onStartOnlineGame }) => {
  const [roomCodeInput, setRoomCodeInput] = useState('');
  const [playerName, setPlayerName] = useState(() => localStorage.getItem('gh_player_name') || 'CyberPlayer');
  const [roomData, setRoomData] = useState<OnlineRoomData | null>(null);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [copied, setCopied] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [publicRooms, setPublicRooms] = useState<any[]>([]);

  useEffect(() => {
    // Save name
    localStorage.setItem('gh_player_name', playerName);
  }, [playerName]);

  useEffect(() => {
    if (!game?.id) return;
    // Fetch active public rooms
    fetch('/api/rooms')
      .then(r => r.json())
      .then(d => {
        if (d.rooms) setPublicRooms(d.rooms.filter((r: any) => r.gameId === game.id));
      })
      .catch(() => {});
  }, [game?.id]);

  const connectWebSocket = (action: 'CREATE' | 'JOIN', targetCode?: string) => {
    soundManager.play('click');
    setErrorMsg(null);

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      if (action === 'CREATE') {
        ws.send(JSON.stringify({
          type: 'CREATE_ROOM',
          payload: {
            gameId: game?.id || 'game',
            gameTitle: game?.title || 'Game',
            playerName,
            avatar: '🎮',
            maxPlayers: game?.playersMax || 2
          }
        }));
      } else {
        ws.send(JSON.stringify({
          type: 'JOIN_ROOM',
          payload: {
            roomCode: targetCode || roomCodeInput,
            playerName,
            avatar: '🕹️'
          }
        }));
      }
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'ROOM_JOINED') {
          setRoomData(msg.payload.room);
          setMessages(msg.payload.room.messages || []);
          setSocket(ws);
        } else if (msg.type === 'ROOM_UPDATED') {
          setRoomData(msg.payload.room);
          setMessages(msg.payload.room.messages || []);
        } else if (msg.type === 'CHAT_RECEIVED') {
          setMessages(msg.payload.messages || []);
        } else if (msg.type === 'GAME_STARTED') {
          onStartOnlineGame(msg.payload.room, ws);
        } else if (msg.type === 'ERROR') {
          setErrorMsg(msg.payload.message);
          ws.close();
        }
      } catch (err) {
        console.error('WS Parse Error', err);
      }
    };

    ws.onerror = () => {
      setErrorMsg('Failed to connect to game room server.');
    };
  };

  const copyRoomCode = () => {
    if (roomData?.code) {
      navigator.clipboard.writeText(roomData.code);
      setCopied(true);
      soundManager.play('click');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !socket) return;
    socket.send(JSON.stringify({
      type: 'SEND_CHAT',
      payload: { text: chatInput }
    }));
    setChatInput('');
  };

  const handleStartGame = () => {
    if (!socket || !roomData) return;
    socket.send(JSON.stringify({
      type: 'START_GAME',
      payload: {}
    }));
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#121214] border border-white/10 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl text-slate-200">
        {/* Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-[#18181b]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600/20 text-indigo-400 rounded-xl border border-indigo-500/30">
              <Globe className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">{game?.title || 'Game'} — Online Multiplayer</h3>
              <p className="text-xs text-slate-400">Host custom private room or join public servers</p>
            </div>
          </div>
          <button
            onClick={() => {
              if (socket) socket.close();
              onClose();
            }}
            className="p-2 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {errorMsg && (
            <div className="p-3 bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs rounded-xl font-medium">
              {errorMsg}
            </div>
          )}

          {!roomData ? (
            /* Room Creation / Joining View */
            <div className="space-y-6">
              {/* Profile Name Setup */}
              <div className="bg-[#1a1a1e] p-4 rounded-2xl border border-white/5">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Your Multiplayer Gamer Tag
                </label>
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full bg-[#09090b] border border-white/10 px-4 py-2.5 rounded-xl text-white font-semibold text-sm focus:outline-none focus:border-indigo-500"
                  placeholder="Enter username..."
                />
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-4">
                <button
                  onClick={() => connectWebSocket('CREATE')}
                  className="p-5 bg-gradient-to-br from-indigo-600 to-indigo-800 hover:from-indigo-500 hover:to-indigo-700 text-white font-bold rounded-2xl border border-indigo-400/30 shadow-lg shadow-indigo-600/20 text-left transition-all active:scale-98"
                >
                  <Users className="w-6 h-6 mb-2 text-indigo-200" />
                  <div className="text-base font-black">Create Room</div>
                  <div className="text-xs text-indigo-200/80 font-normal mt-0.5">Generate a 6-digit room code for friends</div>
                </button>

                <div className="p-5 bg-[#1a1a1e] rounded-2xl border border-white/5 flex flex-col justify-between">
                  <div>
                    <div className="text-sm font-bold text-white mb-1">Join Room Code</div>
                    <p className="text-xs text-slate-400 mb-3">Have a private code from a friend?</p>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      value={roomCodeInput}
                      onChange={(e) => setRoomCodeInput(e.target.value.toUpperCase())}
                      placeholder="E.g. A8X912"
                      className="w-full bg-[#09090b] border border-white/10 px-3 py-1.5 rounded-xl text-white uppercase text-center font-mono font-bold text-sm tracking-widest focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      onClick={() => connectWebSocket('JOIN')}
                      disabled={!roomCodeInput.trim()}
                      className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl disabled:opacity-40"
                    >
                      Join
                    </button>
                  </div>
                </div>
              </div>

              {/* Active Public Lobbies list */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Active Public Lobbies ({publicRooms.length})
                </h4>
                {publicRooms.length === 0 ? (
                  <div className="text-center py-6 bg-[#1a1a1e] rounded-2xl border border-white/5 text-slate-500 text-xs">
                    No active public lobbies for {game?.title || 'Game'}. Click "Create Room" to start one!
                  </div>
                ) : (
                  <div className="space-y-2">
                    {publicRooms.map((r) => (
                      <div key={r.code} className="flex items-center justify-between p-3.5 bg-[#1a1a1e] hover:bg-[#222226] border border-white/5 rounded-xl transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                          <div>
                            <span className="font-bold text-white text-sm">Host: {r.hostName}</span>
                            <span className="text-xs text-slate-400 ml-2">[{r.code}]</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-xs text-slate-400">{r.playerCount} / {r.maxPlayers} Players</span>
                          <button
                            onClick={() => connectWebSocket('JOIN', r.code)}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg"
                          >
                            Join Lobby
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            /* Inside Room Lobby View */
            <div className="space-y-6">
              {/* Room Code & Info Banner */}
              <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-2xl flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-indigo-300 block">Private Room Code</span>
                  <span className="text-2xl font-black text-white font-mono tracking-wider">{roomData.code}</span>
                </div>
                <button
                  onClick={copyRoomCode}
                  className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-colors"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied Code!' : 'Copy Code'}
                </button>
              </div>

              {/* Joined Players */}
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  Players in Room ({roomData.players.length} / {roomData.maxPlayers})
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {roomData.players.map((p) => (
                    <div key={p.id} className="p-3 bg-[#1a1a1e] border border-white/5 rounded-xl flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <span className="text-xl">{p.avatar}</span>
                        <div>
                          <p className="text-sm font-bold text-white flex items-center gap-1.5">
                            {p.name}
                            {p.isHost && <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono">HOST</span>}
                          </p>
                          <p className="text-[10px] text-slate-400">Score: {p.score}</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-emerald-400">Ready</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Chat Box */}
              <div className="bg-[#1a1a1e] border border-white/5 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-400 mb-3">
                  <MessageSquare className="w-4 h-4 text-indigo-400" />
                  Room Chat
                </div>
                <div className="h-32 overflow-y-auto space-y-2 mb-3 text-xs pr-1">
                  {messages.map((m, i) => (
                    <div key={i} className="bg-[#09090b] p-2 rounded-lg border border-white/5">
                      <span className="font-bold text-indigo-400 mr-2">{m.sender}:</span>
                      <span className="text-slate-200">{m.text}</span>
                      <span className="text-[9px] text-slate-500 float-right">{m.time}</span>
                    </div>
                  ))}
                </div>
                <form onSubmit={handleSendChat} className="flex gap-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type chat message..."
                    className="flex-1 bg-[#09090b] border border-white/10 px-3 py-1.5 rounded-xl text-white text-xs outline-none focus:border-indigo-500"
                  />
                  <button type="submit" className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold">
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              </div>

              {/* Host Start Game Trigger */}
              <div className="pt-2 flex justify-end">
                <button
                  onClick={handleStartGame}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black rounded-xl shadow-lg shadow-emerald-500/20 active:scale-95"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Start Match
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
