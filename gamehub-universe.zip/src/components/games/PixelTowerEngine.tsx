import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Shield, Sparkles, Zap, Heart } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelTowerEngine: React.FC<Props> = () => {
  const [gold, setGold] = useState<number>(100);
  const [lives, setLives] = useState<number>(10);
  const [wave, setWave] = useState<number>(1);
  const [towers, setTowers] = useState<{ id: number; x: number; y: number; type: string }[]>([]);
  const [score, setScore] = useState<number>(0);

  const placeTower = (x: number, y: number, type: 'archer' | 'mage') => {
    const cost = type === 'archer' ? 40 : 70;
    if (gold < cost) return;

    soundManager.play('click');
    setGold(g => g - cost);
    setTowers(prev => [...prev, { id: Date.now(), x, y, type }]);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Health: ❤️ {lives}</div>
          <div className="text-xs text-amber-400 font-bold">Gold: 💰 {gold}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">PIXEL TOWER DEFENSE</div>
          <div className="text-xs font-bold text-slate-300">Wave {wave}</div>
        </div>
        <div>
          <button
            onClick={() => { soundManager.play('score'); setWave(w => w + 1); setGold(g => g + 50); }}
            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-xl text-xs"
          >
            Next Wave ➔
          </button>
        </div>
      </div>

      <div className="grid grid-cols-6 gap-2 w-full aspect-square p-3 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-4">
        {Array.from({ length: 36 }).map((_, idx) => {
          const x = idx % 6;
          const y = Math.floor(idx / 6);
          const isPath = (y === 1 && x < 5) || (x === 4 && y >= 1 && y <= 4) || (y === 4 && x >= 1 && x <= 4);
          const tower = towers.find(t => t.x === x && t.y === y);

          return (
            <button
              key={idx}
              onClick={() => {
                if (!isPath && !tower) placeTower(x, y, gold >= 70 ? 'mage' : 'archer');
              }}
              className={`flex items-center justify-center rounded-xl font-bold transition-all text-xl ${
                isPath
                  ? 'bg-amber-900/30 border border-amber-600/30 text-amber-500'
                  : tower
                  ? 'bg-indigo-900/60 border border-indigo-500 text-indigo-300'
                  : 'bg-slate-900 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {isPath ? '🐾' : tower ? (tower.type === 'mage' ? '🔮' : '🏹') : ''}
            </button>
          );
        })}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Click empty tiles to deploy Archer (40g) or Mage (70g) Towers</span>
      </div>
    </div>
  );
};
