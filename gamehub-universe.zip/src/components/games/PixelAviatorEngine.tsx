import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelAviatorEngine: React.FC<Props> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [gameOver, setGameOver] = useState<boolean>(false);

  const gameState = useRef({
    bird: { y: 180, vy: 0 },
    pipes: [] as { x: number; top: number; bottom: number; passed: boolean }[],
    score: 0
  });

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.bird = { y: 180, vy: 0 };
    gameState.current.pipes = [];
    gameState.current.score = 0;
    setScore(0);
    setGameOver(false);
  };

  useEffect(() => {
    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frameCount = 0;

    const handleFlap = () => {
      soundManager.play('click');
      gameState.current.bird.vy = -7.5;
    };

    window.addEventListener('keydown', handleFlap);

    const loop = () => {
      const state = gameState.current;

      if (!gameOver) {
        state.bird.vy += 0.45; // gravity
        state.bird.y += state.bird.vy;

        // Spawn pipes
        frameCount++;
        if (frameCount % 90 === 0) {
          const top = 40 + Math.random() * 140;
          state.pipes.push({
            x: canvas.width,
            top,
            bottom: canvas.height - top - 110,
            passed: false
          });
        }

        // Move pipes
        state.pipes.forEach(p => {
          p.x -= 2.2;

          // Check score
          if (!p.passed && p.x < 100) {
            soundManager.play('score');
            p.passed = true;
            state.score += 1;
            setScore(state.score);
          }

          // Check collision
          if (p.x < 120 && p.x + 40 > 80) {
            if (state.bird.y < p.top || state.bird.y > canvas.height - p.bottom) {
              soundManager.play('move');
              setGameOver(true);
            }
          }
        });

        // Floor / Ceiling check
        if (state.bird.y <= 0 || state.bird.y >= canvas.height - 15) {
          soundManager.play('move');
          setGameOver(true);
        }
      }

      // Render
      ctx.fillStyle = '#0284c7';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Pipes
      ctx.fillStyle = '#16a34a';
      state.pipes.forEach(p => {
        ctx.fillRect(p.x, 0, 40, p.top);
        ctx.fillRect(p.x, canvas.height - p.bottom, 40, p.bottom);
      });

      // Pixel Bird
      ctx.fillStyle = '#facc15';
      ctx.beginPath();
      ctx.arc(100, state.bird.y, 12, 0, Math.PI * 2);
      ctx.fill();

      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleFlap);
    };
  }, [gameOver]);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-cyan-400 font-bold">FLAPPY AVIATOR</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-amber-400 font-bold">Score: {score}</div>
        </div>
      </div>

      <div
        onClick={() => {
          soundManager.play('click');
          gameState.current.bird.vy = -7.5;
        }}
        className="relative w-full aspect-[4/3] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4 cursor-pointer"
      >
        <canvas ref={canvasRef} width={500} height={375} className="w-full h-full object-cover" />

        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Flight Ended!</h3>
            <p className="text-xs text-slate-400 mb-4">Score: {score}</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Fly Again
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Click screen or Press Any Key to <strong className="text-amber-300">Flap Wings</strong></span>
      </div>
    </div>
  );
};
