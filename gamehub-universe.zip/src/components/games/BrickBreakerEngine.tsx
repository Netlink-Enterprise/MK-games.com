import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, Zap } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const BrickBreakerEngine: React.FC<Props> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [gameOver, setGameOver] = useState<boolean>(false);

  const gameState = useRef({
    paddle: { x: 200, w: 80, h: 12 },
    ball: { x: 240, y: 250, vx: 4, vy: -4, radius: 6 },
    bricks: [] as { x: number; y: number; w: number; h: number; color: string; alive: boolean }[],
    score: 0,
    lives: 3
  });

  const initBricks = () => {
    const bricks = [];
    const colors = ['#f43f5e', '#f59e0b', '#10b981', '#38bdf8', '#818cf8'];
    for (let r = 0; r < 5; r++) {
      for (let c = 0; c < 8; c++) {
        bricks.push({
          x: 15 + c * 58,
          y: 40 + r * 22,
          w: 52,
          h: 16,
          color: colors[r],
          alive: true
        });
      }
    }
    gameState.current.bricks = bricks;
  };

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.paddle = { x: 200, w: 80, h: 12 };
    gameState.current.ball = { x: 240, y: 250, vx: 4, vy: -4, radius: 6 };
    gameState.current.score = 0;
    gameState.current.lives = 3;
    initBricks();
    setScore(0);
    setLives(3);
    setGameOver(false);
  };

  useEffect(() => {
    initBricks();

    const handleMouseMove = (e: MouseEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      gameState.current.paddle.x = Math.max(0, Math.min(canvas.width - gameState.current.paddle.w, mx - gameState.current.paddle.w / 2));
    };

    window.addEventListener('mousemove', handleMouseMove);

    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      const state = gameState.current;
      const b = state.ball;
      const p = state.paddle;

      if (state.lives > 0 && !gameOver) {
        b.x += b.vx;
        b.y += b.vy;

        // Wall collisions
        if (b.x - b.radius <= 0 || b.x + b.radius >= canvas.width) {
          soundManager.play('click');
          b.vx *= -1;
        }
        if (b.y - b.radius <= 0) {
          soundManager.play('click');
          b.vy *= -1;
        }

        // Paddle collision
        if (
          b.y + b.radius >= canvas.height - 25 &&
          b.x >= p.x &&
          b.x <= p.x + p.w
        ) {
          soundManager.play('click');
          b.vy = -Math.abs(b.vy);
          b.vx = ((b.x - (p.x + p.w / 2)) / (p.w / 2)) * 6;
        }

        // Bottom hit -> Lose life
        if (b.y + b.radius >= canvas.height) {
          soundManager.play('move');
          state.lives--;
          setLives(state.lives);
          if (state.lives <= 0) {
            setGameOver(true);
          } else {
            b.x = 240;
            b.y = 250;
            b.vx = 4;
            b.vy = -4;
          }
        }

        // Brick collisions
        state.bricks.forEach(brick => {
          if (
            brick.alive &&
            b.x >= brick.x &&
            b.x <= brick.x + brick.w &&
            b.y >= brick.y &&
            b.y <= brick.y + brick.h
          ) {
            soundManager.play('score');
            brick.alive = false;
            b.vy *= -1;
            state.score += 10;
            setScore(state.score);
          }
        });
      }

      // Render
      ctx.fillStyle = '#0a0a0f';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Bricks
      state.bricks.forEach(brick => {
        if (brick.alive) {
          ctx.fillStyle = brick.color;
          ctx.fillRect(brick.x, brick.y, brick.w, brick.h);
        }
      });

      // Paddle
      ctx.fillStyle = '#6366f1';
      ctx.fillRect(p.x, canvas.height - 25, p.w, p.h);

      // Ball
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.radius, 0, Math.PI * 2);
      ctx.fill();

      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [gameOver]);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Lives: {'❤️'.repeat(lives)}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">RETRO BRICK BREAKER</div>
          <div className="text-xs font-bold text-slate-300">Arcade Smash</div>
        </div>
        <div>
          <div className="text-xs text-amber-400 font-bold">Score: {score}</div>
        </div>
      </div>

      <div className="relative w-full aspect-[4/3] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4 cursor-none">
        <canvas ref={canvasRef} width={500} height={375} className="w-full h-full object-cover" />

        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Game Over!</h3>
            <p className="text-xs text-slate-400 mb-4">Final Score: {score}</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Restart Match
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Controls: Move mouse left and right to guide the paddle</span>
      </div>
    </div>
  );
};
