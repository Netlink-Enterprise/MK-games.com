import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, Zap, Shield, Flame, Crosshair } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelKnightEngine: React.FC<Props> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [coins, setCoins] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [won, setWon] = useState<boolean>(false);
  const [level, setLevel] = useState<number>(1);

  const gameState = useRef({
    player: {
      x: 40,
      y: 280,
      vx: 0,
      vy: 0,
      w: 24,
      h: 32,
      grounded: false,
      facing: 'right' as 'left' | 'right',
      animTimer: 0,
      attacking: false,
      attackTimer: 0
    },
    keys: {} as Record<string, boolean>,
    coins: [
      { x: 140, y: 200, taken: false },
      { x: 260, y: 140, taken: false },
      { x: 380, y: 220, taken: false }
    ],
    platforms: [
      { x: 0, y: 340, w: 500, h: 40 }, // Ground
      { x: 120, y: 250, w: 90, h: 16 },
      { x: 240, y: 190, w: 90, h: 16 },
      { x: 360, y: 270, w: 100, h: 16 }
    ],
    spikes: [
      { x: 210, y: 320, w: 30, h: 20 }
    ],
    enemies: [
      { x: 130, y: 234, w: 20, h: 16, vx: 1, minX: 120, maxX: 200, alive: true, type: 'slime' },
      { x: 250, y: 174, w: 20, h: 16, vx: -1.2, minX: 240, maxX: 320, alive: true, type: 'slime' },
      { x: 360, y: 140, w: 22, h: 18, vx: 1.5, minX: 300, maxX: 450, alive: true, type: 'bat' }
    ],
    particles: [] as { x: number; y: number; vx: number; vy: number; color: string; life: number }[],
    portal: { x: 440, y: 220, w: 32, h: 50 },
    score: 0,
    lives: 3
  });

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.player = {
      x: 40,
      y: 280,
      vx: 0,
      vy: 0,
      w: 24,
      h: 32,
      grounded: false,
      facing: 'right',
      animTimer: 0,
      attacking: false,
      attackTimer: 0
    };
    gameState.current.coins.forEach(c => (c.taken = false));
    gameState.current.enemies = [
      { x: 130, y: 234, w: 20, h: 16, vx: 1, minX: 120, maxX: 200, alive: true, type: 'slime' },
      { x: 250, y: 174, w: 20, h: 16, vx: -1.2, minX: 240, maxX: 320, alive: true, type: 'slime' },
      { x: 360, y: 140, w: 22, h: 18, vx: 1.5, minX: 300, maxX: 450, alive: true, type: 'bat' }
    ];
    gameState.current.particles = [];
    gameState.current.score = 0;
    gameState.current.lives = 3;
    setCoins(0);
    setLives(3);
    setWon(false);
  };

  const handleAttack = () => {
    const p = gameState.current.player;
    if (p.attacking) return;
    p.attacking = true;
    p.attackTimer = 15;
    soundManager.play('laser');

    // Check hit on enemies
    gameState.current.enemies.forEach(e => {
      if (!e.alive) return;
      const reach = 35;
      const attackBoxX = p.facing === 'right' ? p.x + p.w : p.x - reach;
      if (
        attackBoxX < e.x + e.w &&
        attackBoxX + reach > e.x &&
        p.y < e.y + e.h &&
        p.y + p.h > e.y
      ) {
        e.alive = false;
        soundManager.play('score');
        // Spawn particles
        for (let i = 0; i < 10; i++) {
          gameState.current.particles.push({
            x: e.x + e.w / 2,
            y: e.y + e.h / 2,
            vx: (Math.random() - 0.5) * 6,
            vy: (Math.random() - 0.5) * 6,
            color: '#f43f5e',
            life: 20
          });
        }
      }
    });
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      gameState.current.keys[k] = true;
      if (['arrowup', 'arrowleft', 'arrowright', ' ', 'j', 'f'].includes(k)) e.preventDefault();
      if (k === 'j' || k === 'f') {
        handleAttack();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      const state = gameState.current;
      const p = state.player;

      if (state.lives > 0 && !won) {
        // Controls
        if (state.keys['a'] || state.keys['arrowleft']) {
          p.vx = -4;
          p.facing = 'left';
          p.animTimer += 0.2;
        } else if (state.keys['d'] || state.keys['arrowright']) {
          p.vx = 4;
          p.facing = 'right';
          p.animTimer += 0.2;
        } else {
          p.vx *= 0.7;
        }

        if ((state.keys['w'] || state.keys['arrowup'] || state.keys[' ']) && p.grounded) {
          soundManager.play('click');
          p.vy = -10;
          p.grounded = false;
        }

        if (state.keys['j'] || state.keys['f']) {
          handleAttack();
        }

        if (p.attacking) {
          p.attackTimer--;
          if (p.attackTimer <= 0) p.attacking = false;
        }

        // Physics
        p.vy += 0.5; // gravity
        p.x += p.vx;
        p.y += p.vy;

        // Boundaries
        if (p.x < 0) p.x = 0;
        if (p.x + p.w > canvas.width) p.x = canvas.width - p.w;

        // Platform collisions
        p.grounded = false;
        state.platforms.forEach(plat => {
          if (
            p.x + p.w > plat.x &&
            p.x < plat.x + plat.w &&
            p.y + p.h >= plat.y &&
            p.y + p.h <= plat.y + 12 &&
            p.vy >= 0
          ) {
            p.y = plat.y - p.h;
            p.vy = 0;
            p.grounded = true;
          }
        });

        // Spike collisions
        state.spikes.forEach(spk => {
          if (
            p.x + p.w > spk.x &&
            p.x < spk.x + spk.w &&
            p.y + p.h > spk.y
          ) {
            soundManager.play('move');
            state.lives--;
            setLives(state.lives);
            p.x = 40;
            p.y = 280;
            p.vx = 0;
            p.vy = 0;
          }
        });

        // Patrol Enemies
        state.enemies.forEach(e => {
          if (!e.alive) return;
          e.x += e.vx;
          if (e.x < e.minX || e.x > e.maxX) e.vx *= -1;

          // Player collision with enemy
          if (
            p.x + p.w > e.x &&
            p.x < e.x + e.w &&
            p.y + p.h > e.y &&
            p.y < e.y + e.h
          ) {
            // Jump stomp kill
            if (p.vy > 0 && p.y + p.h - p.vy <= e.y + 8) {
              e.alive = false;
              p.vy = -7;
              soundManager.play('score');
            } else {
              // Hurt player
              soundManager.play('move');
              state.lives--;
              setLives(state.lives);
              p.x = 40;
              p.y = 280;
              p.vx = 0;
              p.vy = 0;
            }
          }
        });

        // Coins pickup
        state.coins.forEach(c => {
          if (!c.taken && Math.hypot(p.x - c.x, p.y - c.y) < 25) {
            soundManager.play('score');
            c.taken = true;
            state.score += 1;
            setCoins(state.score);
            // Spawn gold sparkles
            for (let i = 0; i < 8; i++) {
              state.particles.push({
                x: c.x,
                y: c.y,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                color: '#facc15',
                life: 15
              });
            }
          }
        });

        // Portal reached
        if (
          p.x + p.w > state.portal.x &&
          p.x < state.portal.x + state.portal.w &&
          p.y + p.h > state.portal.y
        ) {
          soundManager.play('win');
          setWon(true);
        }
      }

      // Update Particles
      state.particles.forEach(pt => {
        pt.x += pt.vx;
        pt.y += pt.vy;
        pt.life--;
      });
      state.particles = state.particles.filter(pt => pt.life > 0);

      // Render Background
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Distant Stars / Dungeon Pillars
      ctx.fillStyle = '#1e293b';
      for (let i = 0; i < 5; i++) {
        ctx.fillRect(i * 120 + 20, 40, 16, 300);
      }

      // Platforms
      state.platforms.forEach(plat => {
        ctx.fillStyle = '#334155';
        ctx.fillRect(plat.x, plat.y, plat.w, plat.h);
        ctx.fillStyle = '#10b981';
        ctx.fillRect(plat.x, plat.y, plat.w, 4); // Moss / Grass top
      });

      // Spikes
      ctx.fillStyle = '#f43f5e';
      state.spikes.forEach(spk => {
        ctx.beginPath();
        ctx.moveTo(spk.x, spk.y + spk.h);
        ctx.lineTo(spk.x + spk.w / 2, spk.y);
        ctx.lineTo(spk.x + spk.w, spk.y + spk.h);
        ctx.fill();
      });

      // Animated Enemies
      state.enemies.forEach(e => {
        if (!e.alive) return;
        if (e.type === 'slime') {
          ctx.fillStyle = '#10b981';
          const bounce = Math.sin(Date.now() / 150) * 2;
          ctx.beginPath();
          ctx.arc(e.x + e.w / 2, e.y + e.h / 2 + bounce, e.w / 2, Math.PI, 0, false);
          ctx.fill();
          // Eyes
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(e.x + 4, e.y + 4 + bounce, 3, 3);
          ctx.fillRect(e.x + 12, e.y + 4 + bounce, 3, 3);
        } else {
          // Bat
          ctx.fillStyle = '#a855f7';
          const wing = Math.sin(Date.now() / 80) * 6;
          ctx.beginPath();
          ctx.arc(e.x + e.w / 2, e.y + e.h / 2, 6, 0, Math.PI * 2);
          ctx.fill();
          // Wings
          ctx.fillRect(e.x - 8, e.y + wing, 8, 4);
          ctx.fillRect(e.x + e.w, e.y + wing, 8, 4);
        }
      });

      // Coins
      ctx.fillStyle = '#facc15';
      state.coins.forEach(c => {
        if (!c.taken) {
          const spin = Math.sin(Date.now() / 200) * 4;
          ctx.beginPath();
          ctx.ellipse(c.x, c.y, Math.max(2, 7 + spin / 2), 7, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Portal
      const portalGlow = Math.sin(Date.now() / 200) * 3;
      ctx.fillStyle = '#818cf8';
      ctx.fillRect(
        state.portal.x - portalGlow / 2,
        state.portal.y - portalGlow / 2,
        state.portal.w + portalGlow,
        state.portal.h + portalGlow
      );
      ctx.fillStyle = '#312e81';
      ctx.fillRect(state.portal.x + 4, state.portal.y + 4, state.portal.w - 8, state.portal.h - 8);

      // Particles
      state.particles.forEach(pt => {
        ctx.fillStyle = pt.color;
        ctx.fillRect(pt.x, pt.y, 3, 3);
      });

      // Animated Player Knight
      if (state.lives > 0) {
        const legOffset = Math.sin(p.animTimer) * 4;
        ctx.fillStyle = '#6366f1'; // Knight Armor Body
        ctx.fillRect(p.x, p.y + 6, p.w, p.h - 12);

        // Legs
        ctx.fillStyle = '#4338ca';
        ctx.fillRect(p.x + 4, p.y + p.h - 6 + (p.vx !== 0 ? legOffset : 0), 6, 6);
        ctx.fillRect(p.x + 14, p.y + p.h - 6 - (p.vx !== 0 ? legOffset : 0), 6, 6);

        // Helmet & Visor
        ctx.fillStyle = '#818cf8';
        ctx.fillRect(p.x + 2, p.y, p.w - 4, 10);
        ctx.fillStyle = '#0f172a'; // Eye Slit
        const visorX = p.facing === 'right' ? p.x + 12 : p.x + 2;
        ctx.fillRect(visorX, p.y + 3, 8, 3);

        // Sword Attack Slash Effect
        if (p.attacking) {
          ctx.fillStyle = '#e0e7ff';
          ctx.beginPath();
          const swordX = p.facing === 'right' ? p.x + p.w : p.x - 20;
          ctx.arc(swordX + 10, p.y + 12, 18, -Math.PI / 3, Math.PI / 3, p.facing === 'left');
          ctx.fill();
        }
      }

      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [won]);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Lives: {'❤️'.repeat(lives)}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1 justify-center">
            <Zap className="w-3.5 h-3.5" /> PIXEL KNIGHT PLATFORMER
          </div>
          <div className="text-xs font-bold text-slate-300">Stage {level}</div>
        </div>
        <div>
          <div className="text-xs text-amber-400 font-bold">Gems: {coins}/3</div>
        </div>
      </div>

      <div className="relative w-full aspect-[4/3] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4">
        <canvas ref={canvasRef} width={500} height={375} className="w-full h-full object-cover" />

        {won && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Dungeon Stage Cleared!</h3>
            <p className="text-xs text-slate-400 mb-4">Slashed Enemies & Collected {coins} Gems</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 active:scale-95 transition-all shadow-lg shadow-indigo-600/30"
            >
              <RefreshCw className="w-4 h-4" /> Next Stage
            </button>
          </div>
        )}

        {/* On-Screen Touch / Action Controls */}
        <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between pointer-events-auto z-10 opacity-80 hover:opacity-100 transition-opacity">
          <div className="flex gap-1.5">
            <button
              onMouseDown={() => { gameState.current.keys['a'] = true; }}
              onMouseUp={() => { gameState.current.keys['a'] = false; }}
              onTouchStart={() => { gameState.current.keys['a'] = true; }}
              onTouchEnd={() => { gameState.current.keys['a'] = false; }}
              className="w-10 h-10 bg-slate-800/80 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-600 flex items-center justify-center active:bg-indigo-600"
            >
              ←
            </button>
            <button
              onMouseDown={() => { gameState.current.keys['d'] = true; }}
              onMouseUp={() => { gameState.current.keys['d'] = false; }}
              onTouchStart={() => { gameState.current.keys['d'] = true; }}
              onTouchEnd={() => { gameState.current.keys['d'] = false; }}
              className="w-10 h-10 bg-slate-800/80 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-600 flex items-center justify-center active:bg-indigo-600"
            >
              →
            </button>
          </div>

          <div className="flex gap-1.5">
            <button
              onClick={handleAttack}
              className="px-3 h-10 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase rounded-xl border border-rose-400 flex items-center gap-1 active:scale-95 shadow-md"
            >
              ⚔️ Slash (J)
            </button>
            <button
              onMouseDown={() => { gameState.current.keys['w'] = true; }}
              onMouseUp={() => { gameState.current.keys['w'] = false; }}
              onTouchStart={() => { gameState.current.keys['w'] = true; }}
              onTouchEnd={() => { gameState.current.keys['w'] = false; }}
              className="w-10 h-10 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl border border-indigo-400 flex items-center justify-center active:scale-95 shadow-md"
            >
              ↑
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Run: <strong className="text-slate-200">A/D / Arrows</strong></span>
        <span>Slash: <strong className="text-rose-400">J or F</strong></span>
        <span>Jump: <strong className="text-indigo-300">W / Space</strong></span>
      </div>
    </div>
  );
};

