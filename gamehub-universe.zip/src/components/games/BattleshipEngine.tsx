import React, { useState } from 'react';
import { soundManager } from '../../lib/sound';
import { Crosshair, Shield, RefreshCw, Trophy, Zap, Grid } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const BattleshipEngine: React.FC<Props> = ({ mode }) => {
  const [level, setLevel] = useState<1 | 2 | 3>(1);
  const getGridSize = (lvl: number) => (lvl === 1 ? 6 : lvl === 2 ? 7 : 8);
  const getTotalShips = (lvl: number) => (lvl === 1 ? 7 : lvl === 2 ? 10 : 13);

  const [enemyGrid, setEnemyGrid] = useState<number[][]>(() => createFleet(6, 7));
  const [playerGrid, setPlayerGrid] = useState<number[][]>(() => createFleet(6, 7));
  const [shots, setShots] = useState<number>(0);
  const [hits, setHits] = useState<number>(0);
  const [botHits, setBotHits] = useState<number>(0);
  const [turn, setTurn] = useState<'player' | 'bot'>('player');

  function createFleet(gridSize: number, totalShipCells: number) {
    const grid = Array(gridSize).fill(null).map(() => Array(gridSize).fill(0));
    let placed = 0;
    while (placed < totalShipCells) {
      const r = Math.floor(Math.random() * gridSize);
      const c = Math.floor(Math.random() * gridSize);
      if (grid[r][c] === 0) {
        grid[r][c] = 1;
        placed++;
      }
    }
    return grid;
  }

  const changeLevel = (lvl: 1 | 2 | 3) => {
    soundManager.play('click');
    setLevel(lvl);
    const size = getGridSize(lvl);
    const shipCells = getTotalShips(lvl);
    setEnemyGrid(createFleet(size, shipCells));
    setPlayerGrid(createFleet(size, shipCells));
    setShots(0);
    setHits(0);
    setBotHits(0);
    setTurn('player');
  };

  const handleCellClick = (r: number, c: number) => {
    if (enemyGrid[r][c] === 2 || enemyGrid[r][c] === 3 || turn !== 'player') return;

    const nextG = enemyGrid.map(row => [...row]);
    setShots(prev => prev + 1);

    if (enemyGrid[r][c] === 1) {
      nextG[r][c] = 2; // Hit
      soundManager.play('laser');
      const newHits = hits + 1;
      setHits(newHits);
      if (newHits >= getTotalShips(level)) {
        soundManager.play('win');
      }
    } else {
      nextG[r][c] = 3; // Miss
      soundManager.play('click');
      if (mode === 'vs_bot') {
        setTurn('bot');
        setTimeout(() => makeBotCounterAttack(), 600);
      }
    }

    setEnemyGrid(nextG);
  };

  const makeBotCounterAttack = () => {
    const size = getGridSize(level);
    const validCells: [number, number][] = [];
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (playerGrid[r][c] !== 2 && playerGrid[r][c] !== 3) {
          validCells.push([r, c]);
        }
      }
    }

    if (validCells.length === 0) {
      setTurn('player');
      return;
    }

    const [r, c] = validCells[Math.floor(Math.random() * validCells.length)];
    const nextP = playerGrid.map(row => [...row]);

    if (playerGrid[r][c] === 1) {
      nextP[r][c] = 2; // Hit
      soundManager.play('score');
      setBotHits(prev => prev + 1);
    } else {
      nextP[r][c] = 3; // Miss
      soundManager.play('move');
    }

    setPlayerGrid(nextP);
    setTurn('player');
  };

  const resetGame = () => {
    soundManager.play('click');
    const size = getGridSize(level);
    const shipCells = getTotalShips(level);
    setEnemyGrid(createFleet(size, shipCells));
    setPlayerGrid(createFleet(size, shipCells));
    setShots(0);
    setHits(0);
    setBotHits(0);
    setTurn('player');
  };

  const isWon = hits >= getTotalShips(level);
  const isLost = botHits >= getTotalShips(level);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-slate-400 font-bold">Shots Fired</div>
          <div className="text-xl font-black text-cyan-400">{shots}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Battleship Radar</div>
          {isWon ? (
            <div className="text-sm font-black text-amber-400 animate-bounce">Enemy Fleet Sunk! 🎉</div>
          ) : isLost ? (
            <div className="text-sm font-black text-rose-500 animate-pulse">Your Fleet Sunk! 💀</div>
          ) : (
            <div className="text-xs font-bold text-slate-300">
              Hits: {hits} / {getTotalShips(level)}
            </div>
          )}
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 font-bold">Accuracy</div>
          <div className="text-xl font-black text-emerald-400">
            {shots > 0 ? `${Math.round((hits / shots) * 100)}%` : '100%'}
          </div>
        </div>
      </div>

      {/* Level Selector */}
      <div className="flex items-center gap-2 mb-4 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-bold w-full justify-center">
        <span className="text-slate-400 flex items-center gap-1">
          <Grid className="w-3.5 h-3.5 text-cyan-400" /> Sector:
        </span>
        {([1, 2, 3] as const).map(lvl => (
          <button
            key={lvl}
            onClick={() => changeLevel(lvl)}
            className={`px-3 py-1 rounded-lg transition-all ${
              level === lvl ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Level {lvl} ({getGridSize(lvl)}x{getGridSize(lvl)})
          </button>
        ))}
      </div>

      <div
        className="grid gap-2 w-full aspect-square p-3 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-4"
        style={{ gridTemplateColumns: `repeat(${getGridSize(level)}, minmax(0, 1fr))` }}
      >
        {enemyGrid.map((row, rIdx) =>
          row.map((cell, cIdx) => (
            <button
              key={`${rIdx}-${cIdx}`}
              onClick={() => handleCellClick(rIdx, cIdx)}
              disabled={isWon || isLost}
              className={`flex items-center justify-center rounded-xl font-black transition-all shadow-md ${
                cell === 2
                  ? 'bg-rose-600 text-white shadow-rose-600/50 animate-pulse'
                  : cell === 3
                  ? 'bg-slate-800 text-slate-500'
                  : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-700 hover:text-cyan-400'
              }`}
            >
              {cell === 2 ? '💥' : cell === 3 ? '•' : '🎯'}
            </button>
          ))
        )}
      </div>

      <button
        onClick={resetGame}
        className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-cyan-400" />
        Redeploy Fleet
      </button>
    </div>
  );
};
