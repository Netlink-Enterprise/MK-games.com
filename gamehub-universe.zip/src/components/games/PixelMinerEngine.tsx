import React, { useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Sparkles, Trophy } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelMinerEngine: React.FC<Props> = () => {
  const [player, setPlayer] = useState({ x: 2, y: 0 });
  const [depth, setDepth] = useState<number>(0);
  const [gold, setGold] = useState<number>(0);
  const [grid, setGrid] = useState<string[][]>(() => {
    const rows = [];
    for (let r = 0; r < 8; r++) {
      const row = [];
      for (let c = 0; c < 5; c++) {
        row.push(Math.random() > 0.7 ? '💎' : Math.random() > 0.8 ? '💣' : '🪨');
      }
      rows.push(row);
    }
    return rows;
  });

  const dig = (dx: number, dy: number) => {
    const nx = player.x + dx;
    const ny = player.y + dy;

    if (nx < 0 || nx >= 5 || ny < 0 || ny >= 8) return;

    soundManager.play('click');
    const tile = grid[ny][nx];

    if (tile === '💎') {
      soundManager.play('score');
      setGold(g => g + 100);
    } else if (tile === '💣') {
      soundManager.play('move');
      setGold(g => Math.max(0, g - 50));
    }

    grid[ny][nx] = '🕳️';
    setGrid([...grid]);
    setPlayer({ x: nx, y: ny });
    setDepth(d => d + 1);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-amber-400 font-bold">Gold Ores: 💎 {gold}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">PIXEL MINER & DIG</div>
          <div className="text-xs font-bold text-slate-300">Depth: {depth} meters</div>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-1.5 w-full aspect-[5/8] p-3 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-4">
        {grid.map((row, rIdx) =>
          row.map((cell, cIdx) => {
            const isPlayer = player.x === cIdx && player.y === rIdx;
            return (
              <div
                key={`${rIdx}-${cIdx}`}
                className="flex items-center justify-center bg-slate-900 border border-slate-800 rounded-xl text-xl select-none"
              >
                {isPlayer ? '⛏️' : cell}
              </div>
            );
          })
        )}
      </div>

      <div className="flex gap-2 w-full">
        <button
          onClick={() => dig(-1, 0)}
          className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95"
        >
          ◀ LEFT
        </button>
        <button
          onClick={() => dig(0, 1)}
          className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 font-bold rounded-xl text-xs active:scale-95"
        >
          ▼ DIG DOWN
        </button>
        <button
          onClick={() => dig(1, 0)}
          className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95"
        >
          RIGHT ▶
        </button>
      </div>
    </div>
  );
};
