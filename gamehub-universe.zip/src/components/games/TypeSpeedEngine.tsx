import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Keyboard, Zap, Trophy } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
}

const SAMPLE_WORDS = [
  'retro', 'arcade', 'cyber', 'laser', 'matrix', 'vector', 'pixel', 'arcade',
  'speed', 'circuit', 'signal', 'nexus', 'quantum', 'synapse', 'glitch', 'duels'
];

export const TypeSpeedEngine: React.FC<Props> = ({ mode }) => {
  const [currentWord, setCurrentWord] = useState<string>('cyber');
  const [userInput, setUserInput] = useState<string>('');
  const [score, setScore] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [wpm, setWpm] = useState<number>(0);

  useEffect(() => {
    if (!isActive || timeLeft <= 0) return;

    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setIsActive(false);
          soundManager.play('win');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setUserInput(val);

    if (!isActive && val.length > 0) {
      setIsActive(true);
    }

    if (val.trim() === currentWord) {
      soundManager.play('click');
      setScore(prev => prev + 1);
      setWpm(Math.round(((score + 1) / (30 - timeLeft || 1)) * 60));
      setUserInput('');
      const nextWord = SAMPLE_WORDS[Math.floor(Math.random() * SAMPLE_WORDS.length)];
      setCurrentWord(nextWord);
    }
  };

  const resetGame = () => {
    soundManager.play('click');
    setScore(0);
    setTimeLeft(30);
    setIsActive(false);
    setUserInput('');
    setWpm(0);
    setCurrentWord('cyber');
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-6 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="text-center">
          <div className="text-xs text-slate-400 font-bold">Time Left</div>
          <div className="text-2xl font-black text-amber-400">{timeLeft}s</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Speed Type Blitz</div>
          <div className="text-xs font-bold text-slate-300">WPM: {wpm}</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 font-bold">Score</div>
          <div className="text-2xl font-black text-emerald-400">{score}</div>
        </div>
      </div>

      <div className="w-full bg-slate-950 p-6 rounded-2xl border-2 border-slate-800 text-center mb-6">
        <div className="text-xs font-bold text-cyan-400 mb-2 uppercase tracking-widest">Type the target word:</div>
        <div className="text-3xl font-black text-indigo-300 tracking-wider mb-6">{currentWord}</div>

        <input
          type="text"
          value={userInput}
          onChange={handleInputChange}
          placeholder="Start typing here..."
          disabled={timeLeft <= 0}
          autoFocus
          className="w-full px-4 py-3 bg-slate-900 border-2 border-indigo-500/50 focus:border-indigo-400 rounded-xl text-center text-lg font-bold text-slate-100 outline-none"
        />
      </div>

      <button
        onClick={resetGame}
        className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-indigo-400" />
        Restart Race
      </button>
    </div>
  );
};
