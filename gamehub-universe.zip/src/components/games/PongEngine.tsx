import React, { useEffect, useRef, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { Play, RotateCcw, Trophy, Cpu, Users } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
  onlineData?: any;
  onSendMove?: (moveData: any) => void;
}

export const PongEngine: React.FC<Props> = ({ mode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });
  const [winner, setWinner] = useState<string | null>(null);

  // State refs
  const p1YRef = useRef<number>(150);
  const p2YRef = useRef<number>(150);

  const ballRef = useRef<{ x: number; y: number; vx: number; vy: number }>({
    x: 250,
    y: 175,
    vx: 4,
    vy: 3
  });

  const paddleHeight = 70;
  const paddleWidth = 10;
  const canvasWidth = 500;
  const canvasHeight = 350;

  // Keyboard Control (W/S vs Up/Down)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || winner) return;

      if (e.key === 'w' || e.key === 'W') {
        p1YRef.current = Math.max(0, p1YRef.current - 20);
      } else if (e.key === 's' || e.key === 'S') {
        p1YRef.current = Math.min(canvasHeight - paddleHeight, p1YRef.current + 20);
      }

      if (e.key === 'ArrowUp') {
        p2YRef.current = Math.max(0, p2YRef.current - 20);
      } else if (e.key === 'ArrowDown') {
        p2YRef.current = Math.min(canvasHeight - paddleHeight, p2YRef.current + 20);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, winner]);

  // Mouse / Touch movement for Player 1
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isPlaying || winner) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const mouseY = e.clientY - rect.top;
    p1YRef.current = Math.max(0, Math.min(canvasHeight - paddleHeight, mouseY - paddleHeight / 2));
  };

  // Game Loop
  useEffect(() => {
    if (!isPlaying || winner) return;

    const interval = setInterval(() => {
      updatePhysics();
      renderCanvas();
    }, 1000 / 60);

    return () => clearInterval(interval);
  }, [isPlaying, winner]);

  const updatePhysics = () => {
    const ball = ballRef.current;

    // Move Ball
    ball.x += ball.vx;
    ball.y += ball.vy;

    // Top / Bottom Wall collision
    if (ball.y <= 5 || ball.y >= canvasHeight - 5) {
      ball.vy = -ball.vy;
      soundManager.play('move');
    }

    // Bot AI for Player 2
    if (mode === 'vs_bot') {
      const targetY = ball.y - paddleHeight / 2;
      const speed = 3.5;
      if (p2YRef.current < targetY) {
        p2YRef.current = Math.min(canvasHeight - paddleHeight, p2YRef.current + speed);
      } else if (p2YRef.current > targetY) {
        p2YRef.current = Math.max(0, p2YRef.current - speed);
      }
    }

    // Paddle 1 Collision
    if (
      ball.x <= 20 &&
      ball.y >= p1YRef.current &&
      ball.y <= p1YRef.current + paddleHeight
    ) {
      ball.vx = Math.abs(ball.vx) + 0.2; // Slight speed up
      ball.x = 21;
      soundManager.play('jump');
    }

    // Paddle 2 Collision
    if (
      ball.x >= canvasWidth - 20 &&
      ball.y >= p2YRef.current &&
      ball.y <= p2YRef.current + paddleHeight
    ) {
      ball.vx = -Math.abs(ball.vx) - 0.2;
      ball.x = canvasWidth - 21;
      soundManager.play('jump');
    }

    // Score Check
    if (ball.x < 0) {
      // P2 Scores
      soundManager.play('score');
      setScores(prev => {
        const nextP2 = prev.p2 + 1;
        if (nextP2 >= 5) {
          setWinner(mode === 'vs_bot' ? 'Gemini AI Bot Wins!' : 'Player 2 Wins!');
          setIsPlaying(false);
          soundManager.play('lose');
        }
        return { ...prev, p2: nextP2 };
      });
      resetBall(1);
    } else if (ball.x > canvasWidth) {
      // P1 Scores
      soundManager.play('score');
      setScores(prev => {
        const nextP1 = prev.p1 + 1;
        if (nextP1 >= 5) {
          setWinner('Player 1 Wins!');
          setIsPlaying(false);
          soundManager.play('win');
        }
        return { ...prev, p1: nextP1 };
      });
      resetBall(-1);
    }
  };

  const resetBall = (direction: number) => {
    ballRef.current = {
      x: canvasWidth / 2,
      y: canvasHeight / 2,
      vx: 4 * direction,
      vy: (Math.random() - 0.5) * 6
    };
  };

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw Dark Field
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);

    // Center dotted line
    ctx.strokeStyle = '#334155';
    ctx.setLineDash([8, 8]);
    ctx.beginPath();
    ctx.moveTo(canvasWidth / 2, 0);
    ctx.lineTo(canvasWidth / 2, canvasHeight);
    ctx.stroke();
    ctx.setLineDash([]);

    // Paddle 1 (Cyan)
    ctx.fillStyle = '#06b6d4';
    ctx.shadowColor = '#06b6d4';
    ctx.shadowBlur = 12;
    ctx.fillRect(10, p1YRef.current, paddleWidth, paddleHeight);

    // Paddle 2 (Rose)
    ctx.fillStyle = '#f43f5e';
    ctx.shadowColor = '#f43f5e';
    ctx.shadowBlur = 12;
    ctx.fillRect(canvasWidth - 20, p2YRef.current, paddleWidth, paddleHeight);

    // Ball (Gold)
    ctx.fillStyle = '#eab308';
    ctx.shadowColor = '#eab308';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(ballRef.current.x, ballRef.current.y, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  };

  const startMatch = () => {
    soundManager.play('click');
    setScores({ p1: 0, p2: 0 });
    setWinner(null);
    resetBall(1);
    setIsPlaying(true);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-cyan-400" />
          <span className="text-xl font-black text-cyan-400">{scores.p1}</span>
        </div>
        <div className="text-center">
          <div className="text-xs font-bold uppercase tracking-widest text-slate-400">Air Hockey & Pong</div>
          <div className="text-xs text-slate-500">First to 5 Points</div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xl font-black text-rose-400">{scores.p2}</span>
          <div className="w-3 h-3 rounded-full bg-rose-500" />
        </div>
      </div>

      {/* Canvas */}
      <div className="relative border-4 border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        <canvas
          ref={canvasRef}
          width={canvasWidth}
          height={canvasHeight}
          onMouseMove={handleMouseMove}
          className="block bg-slate-950 cursor-none"
        />

        {(!isPlaying || winner) && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            {winner && (
              <div className="mb-4">
                <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-2 animate-bounce" />
                <h3 className="text-2xl font-black text-amber-300">{winner}</h3>
              </div>
            )}
            <p className="text-slate-300 text-sm mb-6 max-w-xs">
              Move your mouse or use <span className="text-cyan-400 font-bold">W / S</span> keys to control the left paddle.
            </p>
            <button
              onClick={startMatch}
              className="flex items-center gap-2 px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-lg rounded-xl transition-all shadow-lg shadow-cyan-500/20 active:scale-95"
            >
              <Play className="w-5 h-5 fill-current" />
              {winner ? 'Rematch' : 'Start Match'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
