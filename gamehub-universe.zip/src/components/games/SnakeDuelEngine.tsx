import React, { useEffect, useRef, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Zap, Trophy, Play, Pause } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
  onlineData?: any;
  onSendMove?: (moveData: any) => void;
}

interface Point {
  x: number;
  y: number;
}

const GRID_SIZE = 20;

export const SnakeDuelEngine: React.FC<Props> = ({ mode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [winner, setWinner] = useState<string | null>(null);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });

  // Game state refs for fast animation loop
  const snake1Ref = useRef<Point[]>([
    { x: 4, y: 10 },
    { x: 3, y: 10 },
    { x: 2, y: 10 }
  ]);
  const dir1Ref = useRef<Point>({ x: 1, y: 0 });

  const snake2Ref = useRef<Point[]>([
    { x: 15, y: 10 },
    { x: 16, y: 10 },
    { x: 17, y: 10 }
  ]);
  const dir2Ref = useRef<Point>({ x: -1, y: 0 });

  const foodRef = useRef<Point>({ x: 10, y: 10 });

  // Handle Keyboard Inputs (Player 1: WASD, Player 2: Arrow Keys)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || gameOver) return;

      // Player 1 (WASD)
      if (e.key === 'w' || e.key === 'W') {
        if (dir1Ref.current.y === 0) dir1Ref.current = { x: 0, y: -1 };
      } else if (e.key === 's' || e.key === 'S') {
        if (dir1Ref.current.y === 0) dir1Ref.current = { x: 0, y: 1 };
      } else if (e.key === 'a' || e.key === 'A') {
        if (dir1Ref.current.x === 0) dir1Ref.current = { x: -1, y: 0 };
      } else if (e.key === 'd' || e.key === 'D') {
        if (dir1Ref.current.x === 0) dir1Ref.current = { x: 1, y: 0 };
      }

      // Player 2 (Arrow Keys)
      if (e.key === 'ArrowUp') {
        if (dir2Ref.current.y === 0) dir2Ref.current = { x: 0, y: -1 };
      } else if (e.key === 'ArrowDown') {
        if (dir2Ref.current.y === 0) dir2Ref.current = { x: 0, y: 1 };
      } else if (e.key === 'ArrowLeft') {
        if (dir2Ref.current.x === 0) dir2Ref.current = { x: -1, y: 0 };
      } else if (e.key === 'ArrowRight') {
        if (dir2Ref.current.x === 0) dir2Ref.current = { x: 1, y: 0 };
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, gameOver]);

  // Main Game Loop
  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const interval = setInterval(() => {
      updateGame();
      renderCanvas();
    }, 110);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver]);

  const updateGame = () => {
    // If bot mode, AI controls Snake 2
    if (mode === 'vs_bot') {
      const head2 = snake2Ref.current[0];
      const food = foodRef.current;

      const safeDirs = [
        { x: 0, y: -1 },
        { x: 0, y: 1 },
        { x: -1, y: 0 },
        { x: 1, y: 0 }
      ].filter(d => {
        // Prevent 180 turn
        if (d.x === -dir2Ref.current.x && d.y === -dir2Ref.current.y) return false;

        const nextX = head2.x + d.x;
        const nextY = head2.y + d.y;

        // Check boundaries
        if (nextX < 0 || nextX >= GRID_SIZE || nextY < 0 || nextY >= GRID_SIZE) return false;

        // Check collision with Snake 1 or Snake 2 bodies
        if (snake1Ref.current.some(p => p.x === nextX && p.y === nextY)) return false;
        if (snake2Ref.current.some(p => p.x === nextX && p.y === nextY)) return false;

        return true;
      });

      const candidateDirs = safeDirs.length > 0 ? safeDirs : [
        { x: 0, y: -1 },
        { x: 0, y: 1 },
        { x: -1, y: 0 },
        { x: 1, y: 0 }
      ].filter(d => !(d.x === -dir2Ref.current.x && d.y === -dir2Ref.current.y));

      // Choose direction closer to food
      let bestDir = candidateDirs[0];
      let minDist = Infinity;
      candidateDirs.forEach(d => {
        const nextX = head2.x + d.x;
        const nextY = head2.y + d.y;
        const dist = Math.abs(nextX - food.x) + Math.abs(nextY - food.y);
        if (dist < minDist) {
          minDist = dist;
          bestDir = d;
        }
      });
      if (bestDir) dir2Ref.current = bestDir;
    }

    // Move Snake 1
    const head1 = {
      x: snake1Ref.current[0].x + dir1Ref.current.x,
      y: snake1Ref.current[0].y + dir1Ref.current.y
    };

    // Move Snake 2
    const head2 = {
      x: snake2Ref.current[0].x + dir2Ref.current.x,
      y: snake2Ref.current[0].y + dir2Ref.current.y
    };

    let p1Dead = false;
    let p2Dead = false;

    // Boundary check
    if (head1.x < 0 || head1.x >= GRID_SIZE || head1.y < 0 || head1.y >= GRID_SIZE) p1Dead = true;
    if (head2.x < 0 || head2.x >= GRID_SIZE || head2.y < 0 || head2.y >= GRID_SIZE) p2Dead = true;

    // Body collisions
    if (snake1Ref.current.some(p => p.x === head1.x && p.y === head1.y)) p1Dead = true;
    if (snake2Ref.current.some(p => p.x === head1.x && p.y === head1.y)) p1Dead = true;

    if (snake2Ref.current.some(p => p.x === head2.x && p.y === head2.y)) p2Dead = true;
    if (snake1Ref.current.some(p => p.x === head2.x && p.y === head2.y)) p2Dead = true;

    if (p1Dead || p2Dead) {
      setGameOver(true);
      setIsPlaying(false);
      if (p1Dead && p2Dead) {
        setWinner('Draw!');
        soundManager.play('lose');
      } else if (p1Dead) {
        setWinner(mode === 'vs_bot' ? 'Bot Wins!' : 'Player 2 Wins!');
        soundManager.play('lose');
        setScores(prev => ({ ...prev, p2: prev.p2 + 1 }));
      } else {
        setWinner('Player 1 Wins!');
        soundManager.play('win');
        setScores(prev => ({ ...prev, p1: prev.p1 + 1 }));
      }
      return;
    }

    // Food collision Snake 1
    const newSnake1 = [head1, ...snake1Ref.current];
    if (head1.x === foodRef.current.x && head1.y === foodRef.current.y) {
      soundManager.play('score');
      spawnFood();
    } else {
      newSnake1.pop();
    }
    snake1Ref.current = newSnake1;

    // Food collision Snake 2
    const newSnake2 = [head2, ...snake2Ref.current];
    if (head2.x === foodRef.current.x && head2.y === foodRef.current.y) {
      soundManager.play('score');
      spawnFood();
    } else {
      newSnake2.pop();
    }
    snake2Ref.current = newSnake2;
  };

  const spawnFood = () => {
    foodRef.current = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE)
    };
  };

  const renderCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cellSize = canvas.width / GRID_SIZE;

    // Clear Canvas with dark grid theme
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw Grid Lines
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 0.5;
    for (let i = 0; i < GRID_SIZE; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }

    // Draw Food
    const food = foodRef.current;
    ctx.fillStyle = '#f59e0b'; // Amber Gold
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(food.x * cellSize + cellSize / 2, food.y * cellSize + cellSize / 2, cellSize / 2.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw Snake 1 (Cyan Neon)
    ctx.fillStyle = '#06b6d4';
    snake1Ref.current.forEach((p, idx) => {
      ctx.fillRect(p.x * cellSize + 1, p.y * cellSize + 1, cellSize - 2, cellSize - 2);
    });

    // Draw Snake 2 (Magenta Neon)
    ctx.fillStyle = '#e11d48';
    snake2Ref.current.forEach((p, idx) => {
      ctx.fillRect(p.x * cellSize + 1, p.y * cellSize + 1, cellSize - 2, cellSize - 2);
    });
  };

  const startGame = () => {
    soundManager.play('click');
    snake1Ref.current = [{ x: 4, y: 10 }, { x: 3, y: 10 }, { x: 2, y: 10 }];
    dir1Ref.current = { x: 1, y: 0 };

    snake2Ref.current = [{ x: 15, y: 10 }, { x: 16, y: 10 }, { x: 17, y: 10 }];
    dir2Ref.current = { x: -1, y: 0 };

    spawnFood();
    setGameOver(false);
    setWinner(null);
    setIsPlaying(true);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* Score Header */}
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse" />
          <span className="font-bold text-cyan-400">P1 (WASD): {snake1Ref.current.length - 3} pts</span>
        </div>
        <div className="text-xs font-black uppercase text-slate-400 tracking-wider">Snake Clash Duel</div>
        <div className="flex items-center gap-2">
          <span className="font-bold text-rose-400">{mode === 'vs_bot' ? 'Bot' : 'P2'} (Arrows): {snake2Ref.current.length - 3} pts</span>
          <div className="w-3 h-3 rounded-full bg-rose-500 animate-pulse" />
        </div>
      </div>

      {/* Canvas Frame */}
      <div className="relative border-4 border-slate-800 rounded-xl overflow-hidden shadow-2xl">
        <canvas ref={canvasRef} width={400} height={400} className="block bg-slate-950" />

        {(!isPlaying || gameOver) && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            {gameOver && (
              <div className="mb-4">
                <Trophy className="w-12 h-12 text-amber-400 mx-auto mb-2 animate-bounce" />
                <h3 className="text-2xl font-black text-amber-300">{winner}</h3>
              </div>
            )}
            <p className="text-slate-300 text-sm mb-6 max-w-xs">
              Player 1 controls <span className="text-cyan-400 font-bold">WASD</span> keys.<br />
              Player 2 uses <span className="text-rose-400 font-bold">Arrow Keys</span>.
            </p>
            <button
              onClick={startGame}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black text-lg rounded-xl transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              <Play className="w-5 h-5 fill-current" />
              {gameOver ? 'Play Again' : 'Start Duel'}
            </button>
          </div>
        )}
      </div>

      {/* Controls legend */}
      <div className="flex items-center justify-between w-full mt-4 text-xs text-slate-400 px-2">
        <div><span className="text-cyan-400 font-bold">P1:</span> W A S D</div>
        <div><span className="text-amber-400 font-bold">Food:</span> Golden Orbs</div>
        <div><span className="text-rose-400 font-bold">P2:</span> ↑ ← ↓ →</div>
      </div>
    </div>
  );
};
