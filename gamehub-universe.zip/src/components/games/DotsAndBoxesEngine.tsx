import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Box, Cpu } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
}

const GRID_SIZE = 4; // 4x4 dots = 3x3 boxes

export const DotsAndBoxesEngine: React.FC<Props> = ({ mode }) => {
  // Horizontal lines: 4 rows of 3 lines
  const [hLines, setHLines] = useState<boolean[][]>(() =>
    Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE - 1).fill(false))
  );
  // Vertical lines: 3 rows of 4 lines
  const [vLines, setVLines] = useState<boolean[][]>(() =>
    Array(GRID_SIZE - 1).fill(null).map(() => Array(GRID_SIZE).fill(false))
  );
  // Boxes owners (0 = empty, 1 = P1, 2 = P2)
  const [boxes, setBoxes] = useState<number[][]>(() =>
    Array(GRID_SIZE - 1).fill(null).map(() => Array(GRID_SIZE - 1).fill(0))
  );

  const [currentPlayer, setCurrentPlayer] = useState<number>(1);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });

  useEffect(() => {
    if (mode === 'vs_bot' && currentPlayer === 2) {
      const timer = setTimeout(() => makeBotMove(), 450);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, mode, hLines, vLines, boxes]);

  const makeBotMove = () => {
    // 1. Look for any line that completes a box
    const availableHLines: [number, number][] = [];
    for (let r = 0; r < GRID_SIZE; r++) {
      for (let c = 0; c < GRID_SIZE - 1; c++) {
        if (!hLines[r][c]) availableHLines.push([r, c]);
      }
    }

    const availableVLines: [number, number][] = [];
    for (let r = 0; r < GRID_SIZE - 1; r++) {
      for (let c = 0; c < GRID_SIZE; c++) {
        if (!vLines[r][c]) availableVLines.push([r, c]);
      }
    }

    // Test horizontal lines for box completion
    for (const [r, c] of availableHLines) {
      // Test top box
      if (r > 0) {
        const top = hLines[r - 1][c];
        const left = vLines[r - 1][c];
        const right = vLines[r - 1][c + 1];
        if (top && left && right) {
          handleLineClick('h', r, c);
          return;
        }
      }
      // Test bottom box
      if (r < GRID_SIZE - 1) {
        const bottom = hLines[r + 1][c];
        const left = vLines[r][c];
        const right = vLines[r][c + 1];
        if (bottom && left && right) {
          handleLineClick('h', r, c);
          return;
        }
      }
    }

    // Test vertical lines for box completion
    for (const [r, c] of availableVLines) {
      // Test left box
      if (c > 0) {
        const top = hLines[r][c - 1];
        const bottom = hLines[r + 1][c - 1];
        const left = vLines[r][c - 1];
        if (top && bottom && left) {
          handleLineClick('v', r, c);
          return;
        }
      }
      // Test right box
      if (c < GRID_SIZE - 1) {
        const top = hLines[r][c];
        const bottom = hLines[r + 1][c];
        const right = vLines[r][c + 1];
        if (top && bottom && right) {
          handleLineClick('v', r, c);
          return;
        }
      }
    }

    // Otherwise pick random available line
    const allAvailable = [
      ...availableHLines.map(([r, c]) => ({ type: 'h' as const, r, c })),
      ...availableVLines.map(([r, c]) => ({ type: 'v' as const, r, c }))
    ];

    if (allAvailable.length > 0) {
      const choice = allAvailable[Math.floor(Math.random() * allAvailable.length)];
      handleLineClick(choice.type, choice.r, choice.c);
    }
  };

  const handleLineClick = (type: 'h' | 'v', r: number, c: number) => {
    if (type === 'h' && hLines[r][c]) return;
    if (type === 'v' && vLines[r][c]) return;

    soundManager.play('click');

    const nextH = hLines.map(row => [...row]);
    const nextV = vLines.map(row => [...row]);

    if (type === 'h') nextH[r][c] = true;
    if (type === 'v') nextV[r][c] = true;

    setHLines(nextH);
    setVLines(nextV);

    // Check newly completed boxes
    let newCompletedCount = 0;
    const nextBoxes = boxes.map(row => [...row]);

    for (let br = 0; br < GRID_SIZE - 1; br++) {
      for (let bc = 0; bc < GRID_SIZE - 1; bc++) {
        if (nextBoxes[br][bc] === 0) {
          const top = nextH[br][bc];
          const bottom = nextH[br + 1][bc];
          const left = nextV[br][bc];
          const right = nextV[br][bc + 1];

          if (top && bottom && left && right) {
            nextBoxes[br][bc] = currentPlayer;
            newCompletedCount++;
          }
        }
      }
    }

    setBoxes(nextBoxes);

    if (newCompletedCount > 0) {
      soundManager.play('score');
      setScores(prev => ({
        ...prev,
        [currentPlayer === 1 ? 'p1' : 'p2']: prev[currentPlayer === 1 ? 'p1' : 'p2'] + newCompletedCount
      }));
      // Player retains turn when completing box
    } else {
      setCurrentPlayer(currentPlayer === 1 ? 2 : 1);
    }
  };

  const resetGame = () => {
    soundManager.play('click');
    setHLines(Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE - 1).fill(false)));
    setVLines(Array(GRID_SIZE - 1).fill(null).map(() => Array(GRID_SIZE).fill(false)));
    setBoxes(Array(GRID_SIZE - 1).fill(null).map(() => Array(GRID_SIZE - 1).fill(0)));
    setCurrentPlayer(1);
    setScores({ p1: 0, p2: 0 });
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between w-full mb-6 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="text-center">
          <div className="text-xs text-cyan-400 font-bold">Player 1</div>
          <div className="text-xl font-black text-cyan-400">{scores.p1} Boxes</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Dots & Boxes</div>
          <div className="text-xs font-bold text-slate-300">Turn: {currentPlayer === 1 ? 'Player 1' : 'Player 2'}</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-rose-400 font-bold">Player 2</div>
          <div className="text-xl font-black text-rose-400">{scores.p2} Boxes</div>
        </div>
      </div>

      {/* Grid Canvas representation */}
      <div className="bg-slate-950 p-6 rounded-2xl border-2 border-slate-800 flex flex-col items-center justify-center">
        {Array(GRID_SIZE).fill(null).map((_, r) => (
          <React.Fragment key={`row-${r}`}>
            {/* Dots + Horizontal Lines Row */}
            <div className="flex items-center">
              {Array(GRID_SIZE).fill(null).map((_, c) => (
                <React.Fragment key={`dot-${r}-${c}`}>
                  {/* Dot */}
                  <div className="w-4 h-4 rounded-full bg-cyan-400 shadow-lg shadow-cyan-500/50 z-10" />
                  {/* Horizontal Line */}
                  {c < GRID_SIZE - 1 && (
                    <button
                      onClick={() => handleLineClick('h', r, c)}
                      className={`h-2 w-16 transition-all duration-150 rounded-full mx-0.5 ${
                        hLines[r][c]
                          ? 'bg-amber-400 shadow-md shadow-amber-400/50'
                          : 'bg-slate-800 hover:bg-slate-700'
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>

            {/* Vertical Lines + Box Interiors Row */}
            {r < GRID_SIZE - 1 && (
              <div className="flex items-center">
                {Array(GRID_SIZE).fill(null).map((_, c) => (
                  <React.Fragment key={`vrow-${r}-${c}`}>
                    {/* Vertical Line */}
                    <button
                      onClick={() => handleLineClick('v', r, c)}
                      className={`w-2 h-16 transition-all duration-150 rounded-full my-0.5 ${
                        vLines[r][c]
                          ? 'bg-amber-400 shadow-md shadow-amber-400/50'
                          : 'bg-slate-800 hover:bg-slate-700'
                      }`}
                    />
                    {/* Box interior */}
                    {c < GRID_SIZE - 1 && (
                      <div className={`w-16 h-16 flex items-center justify-center font-black text-xl rounded-lg transition-all ${
                        boxes[r][c] === 1 ? 'bg-cyan-500/30 text-cyan-400' : boxes[r][c] === 2 ? 'bg-rose-500/30 text-rose-400' : 'bg-transparent'
                      }`}>
                        {boxes[r][c] === 1 ? 'P1' : boxes[r][c] === 2 ? 'P2' : ''}
                      </div>
                    )}
                  </React.Fragment>
                ))}
              </div>
            )}
          </React.Fragment>
        ))}
      </div>

      <button
        onClick={resetGame}
        className="mt-6 flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-cyan-400" />
        Reset Grid
      </button>
    </div>
  );
};
