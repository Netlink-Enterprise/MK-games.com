import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, Shield, Zap } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const SpaceInvadersEngine: React.FC<Props> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [gameOver, setGameOver] = useState<boolean>(false);

  const gameState = useRef({
    cannon: { x: 230, w: 32, h: 16 },
    keys: {} as Record<string, boolean>,
    aliens: [] as { x: number; y: number; alive: boolean }[],
    bullets: [] as { x: number; y: number }[],
    alienDirection: 1,
    score: 0,
    lives: 3
  });

  const initAliens = () => {
    const aliens = [];
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 8; c++) {
        aliens.push({
          x: 40 + c * 50,
          y: 40 + r * 35,
          alive: true
        });
      }
    }
    gameState.current.aliens = aliens;
  };

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.cannon = { x: 230, w: 32, h: 16 };
    gameState.current.bullets = [];
    gameState.current.score = 0;
    gameState.current.lives = 3;
    initAliens();
    setScore(0);
    setLives(3);
    setGameOver(false);
  };

  useEffect(() => {
    initAliens();

    const handleKeyDown = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = true;
      if (['ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault();
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let animationFrameId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let shootCooldown = 0;

    const loop = () => {
      const state = gameState.current;
      const c = state.cannon;

      if (state.lives > 0 && !gameOver) {
        if (state.keys['a'] || state.keys['arrowleft']) c.x = Math.max(0, c.x - 4);
        if (state.keys['d'] || state.keys['arrowright']) c.x = Math.min(canvas.width - c.w, c.x + 4);

        if (shootCooldown > 0) shootCooldown--;

        if ((state.keys[' '] || state.keys['w']) && shootCooldown === 0) {
          soundManager.play('click');
          shootCooldown = 15;
          state.bullets.push({ x: c.x + c.w / 2, y: canvas.height - 30 });
        }

        // Bullets movement
        state.bullets.forEach(b => (b.y -= 7));
        state.bullets = state.bullets.filter(b => b.y > 0);

        // Aliens movement
        let moveDown = false;
        state.aliens.forEach(a => {
          if (a.alive) {
            a.x += state.alienDirection * 0.8;
            if (a.x <= 10 || a.x >= canvas.width - 30) moveDown = true;
          }
        });

        if (moveDown) {
          state.alienDirection *= -1;
          state.aliens.forEach(a => {
            if (a.alive) a.y += 12;
          });
        }

        // Collision Check
        state.bullets.forEach((b, bIdx) => {
          state.aliens.forEach(a => {
            if (a.alive && Math.abs(b.x - a.x) < 20 && Math.abs(b.y - a.y) < 15) {
              soundManager.play('score');
              a.alive = false;
              b.y = -999;
              state.score += 20;
              setScore(state.score);
            }
          });
        });
      }

      // Render
      ctx.fillStyle = '#05050d';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Aliens
      ctx.fillStyle = '#10b981';
      state.aliens.forEach(a => {
        if (a.alive) {
          ctx.fillRect(a.x, a.y, 24, 18);
        }
      });

      // Bullets
      ctx.fillStyle = '#f59e0b';
      state.bullets.forEach(b => {
        ctx.fillRect(b.x - 2, b.y, 4, 10);
      });

      // Cannon
      ctx.fillStyle = '#6366f1';
      ctx.fillRect(c.x, canvas.height - 25, c.w, c.h);

      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameOver]);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Base Shields: 🟢 Active</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">SPACE INVADERS 80s</div>
          <div className="text-xs font-bold text-slate-300">Alien Defense</div>
        </div>
        <div>
          <div className="text-xs text-amber-400 font-bold">Score: {score}</div>
        </div>
      </div>

      <div className="relative w-full aspect-[4/3] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4">
        <canvas ref={canvasRef} width={500} height={375} className="w-full h-full object-cover" />

        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Invaders Repelled!</h3>
            <p className="text-xs text-slate-400 mb-4">Final Score: {score}</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Restart Invasion
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Move: <strong className="text-slate-200">A/D or Left/Right</strong></span>
        <span>Shoot: <strong className="text-indigo-300">Spacebar</strong></span>
      </div>
    </div>
  );
};
