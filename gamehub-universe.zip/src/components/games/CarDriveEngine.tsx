import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Zap, Flame, Gauge, Trophy } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const CarDriveEngine: React.FC<Props> = () => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [speed, setSpeed] = useState<number>(0);
  const [distance, setDistance] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [nitro, setNitro] = useState<number>(100);
  const [crashed, setCrashed] = useState<boolean>(false);

  const gameState = useRef({
    carX: 0,
    speed: 60, // MPH base
    distance: 0,
    score: 0,
    nitro: 100,
    keys: {} as Record<string, boolean>,
    traffic: [] as { mesh: THREE.Group; lane: number; z: number }[],
    coins: [] as { mesh: THREE.Mesh; z: number }[],
    roadLines: [] as THREE.Mesh[]
  });

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.carX = 0;
    gameState.current.speed = 60;
    gameState.current.distance = 0;
    gameState.current.score = 0;
    gameState.current.nitro = 100;
    setSpeed(60);
    setDistance(0);
    setScore(0);
    setNitro(100);
    setCrashed(false);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = true;
      if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' '].includes(e.key)) {
        e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    const container = mountRef.current;
    if (!container) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x05050d);
    scene.fog = new THREE.FogExp2(0x05050d, 0.015);

    const camera = new THREE.PerspectiveCamera(65, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 3, 7);
    camera.lookAt(0, 1, -10);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Ambient & Directional Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xa5b4fc, 1.8);
    dirLight.position.set(10, 20, 10);
    scene.add(dirLight);

    // Road Plane
    const roadGeo = new THREE.PlaneGeometry(16, 200);
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });
    const road = new THREE.Mesh(roadGeo, roadMat);
    road.rotation.x = -Math.PI / 2;
    road.position.z = -80;
    scene.add(road);

    // Road Dash Lines
    const lineGeo = new THREE.PlaneGeometry(0.3, 3);
    const lineMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });

    for (let z = 0; z > -180; z -= 8) {
      const line = new THREE.Mesh(lineGeo, lineMat);
      line.rotation.x = -Math.PI / 2;
      line.position.set(0, 0.02, z);
      scene.add(line);
      gameState.current.roadLines.push(line);
    }

    // Player Car 3D Group
    const carGroup = new THREE.Group();

    // Body
    const bodyGeo = new THREE.BoxGeometry(1.8, 0.8, 3.6);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x4f46e5, roughness: 0.2, metalness: 0.8 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.position.y = 0.6;
    carGroup.add(body);

    // Cabin
    const cabinGeo = new THREE.BoxGeometry(1.4, 0.6, 1.8);
    const cabinMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 });
    const cabin = new THREE.Mesh(cabinGeo, cabinMat);
    cabin.position.set(0, 1.1, -0.2);
    carGroup.add(cabin);

    // Headlights
    const lightGeo = new THREE.BoxGeometry(0.3, 0.2, 0.1);
    const lightMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    const leftLight = new THREE.Mesh(lightGeo, lightMat);
    leftLight.position.set(-0.6, 0.6, -1.8);
    const rightLight = new THREE.Mesh(lightGeo, lightMat);
    rightLight.position.set(0.6, 0.6, -1.8);
    carGroup.add(leftLight);
    carGroup.add(rightLight);

    carGroup.position.set(0, 0, 0);
    scene.add(carGroup);

    // Traffic Cars Spawning
    const spawnTraffic = () => {
      const trafficGroup = new THREE.Group();
      const colors = [0xe11d48, 0x10b981, 0xd97706, 0x9333ea];
      const color = colors[Math.floor(Math.random() * colors.length)];

      const tBody = new THREE.Mesh(
        new THREE.BoxGeometry(1.8, 0.8, 3.6),
        new THREE.MeshStandardMaterial({ color, roughness: 0.3 })
      );
      tBody.position.y = 0.6;
      trafficGroup.add(tBody);

      const lane = (Math.floor(Math.random() * 3) - 1) * 4.5;
      const z = -120 - Math.random() * 40;
      trafficGroup.position.set(lane, 0, z);

      scene.add(trafficGroup);
      gameState.current.traffic.push({ mesh: trafficGroup, lane, z });
    };

    for (let i = 0; i < 4; i++) spawnTraffic();

    // Coins Spawning
    const coinGeo = new THREE.CylinderGeometry(0.6, 0.6, 0.2, 16);
    coinGeo.rotateX(Math.PI / 2);
    const coinMat = new THREE.MeshBasicMaterial({ color: 0xfacc15 });

    const spawnCoin = () => {
      const coin = new THREE.Mesh(coinGeo, coinMat);
      const lane = (Math.floor(Math.random() * 3) - 1) * 4.5;
      const z = -60 - Math.random() * 80;
      coin.position.set(lane, 0.8, z);
      scene.add(coin);
      gameState.current.coins.push({ mesh: coin, z });
    };

    for (let i = 0; i < 6; i++) spawnCoin();

    // Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const state = gameState.current;

      if (!crashed) {
        // Steering
        const turnSpeed = 0.18;
        if (state.keys['a'] || state.keys['arrowleft']) state.carX -= turnSpeed;
        if (state.keys['d'] || state.keys['arrowright']) state.carX += turnSpeed;

        // Clamp car to road lanes
        state.carX = Math.max(-6.5, Math.min(6.5, state.carX));
        carGroup.position.x = state.carX;
        carGroup.rotation.z = -state.carX * 0.03; // Bank angle

        // Nitro boost
        let currentSpeed = 70;
        if ((state.keys[' '] || state.keys['w'] || state.keys['arrowup']) && state.nitro > 0) {
          currentSpeed = 130;
          state.nitro -= 0.6;
          setNitro(Math.max(0, Math.round(state.nitro)));
        } else if (state.nitro < 100) {
          state.nitro += 0.1;
          setNitro(Math.min(100, Math.round(state.nitro)));
        }

        setSpeed(currentSpeed);
        state.distance += currentSpeed / 200;
        setDistance(Math.round(state.distance));

        // Move road dash lines
        state.roadLines.forEach(line => {
          line.position.z += currentSpeed * 0.015;
          if (line.position.z > 10) line.position.z = -170;
        });

        // Move Traffic
        state.traffic.forEach((t, idx) => {
          t.mesh.position.z += (currentSpeed - 30) * 0.015;

          // Collision Check
          if (Math.abs(t.mesh.position.z) < 2.5 && Math.abs(t.mesh.position.x - carGroup.position.x) < 1.6) {
            soundManager.play('move');
            setCrashed(true);
          }

          if (t.mesh.position.z > 15) {
            t.mesh.position.z = -140 - Math.random() * 40;
            t.mesh.position.x = (Math.floor(Math.random() * 3) - 1) * 4.5;
          }
        });

        // Move Coins
        state.coins.forEach((c, idx) => {
          c.mesh.position.z += currentSpeed * 0.015;
          c.mesh.rotation.z += 0.05;

          // Pickup
          if (Math.abs(c.mesh.position.z) < 2 && Math.abs(c.mesh.position.x - carGroup.position.x) < 1.5) {
            soundManager.play('score');
            state.score += 50;
            setScore(state.score);
            c.mesh.position.z = -120 - Math.random() * 60;
            c.mesh.position.x = (Math.floor(Math.random() * 3) - 1) * 4.5;
          }

          if (c.mesh.position.z > 15) {
            c.mesh.position.z = -120 - Math.random() * 60;
            c.mesh.position.x = (Math.floor(Math.random() * 3) - 1) * 4.5;
          }
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [crashed]);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-400">Nitro Fuel</div>
          <div className="w-24 bg-slate-800 h-3 rounded-full overflow-hidden border border-slate-700">
            <div className="h-full bg-cyan-400 transition-all duration-150" style={{ width: `${nitro}%` }} />
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-amber-400 uppercase tracking-widest flex items-center justify-center gap-1">
            <Gauge className="w-4 h-4" /> {speed} MPH
          </div>
          <div className="text-xs font-bold text-slate-300">{distance} Meters Traveled</div>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-slate-400">Gold Coins</div>
          <div className="text-xl font-black text-emerald-400">{score}</div>
        </div>
      </div>

      <div className="relative w-full aspect-[16/9] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4">
        <div ref={mountRef} className="w-full h-full" />

        {/* On-screen Touch Controls */}
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-auto z-10 opacity-70 hover:opacity-100 transition-opacity">
          <div className="flex gap-2">
            <button
              onMouseDown={() => { gameState.current.keys['a'] = true; }}
              onMouseUp={() => { gameState.current.keys['a'] = false; }}
              onTouchStart={() => { gameState.current.keys['a'] = true; }}
              onTouchEnd={() => { gameState.current.keys['a'] = false; }}
              className="w-12 h-12 bg-slate-800/80 hover:bg-slate-700 text-white font-black text-lg rounded-xl border border-slate-600 flex items-center justify-center active:bg-cyan-600"
            >
              ←
            </button>
            <button
              onMouseDown={() => { gameState.current.keys['d'] = true; }}
              onMouseUp={() => { gameState.current.keys['d'] = false; }}
              onTouchStart={() => { gameState.current.keys['d'] = true; }}
              onTouchEnd={() => { gameState.current.keys['d'] = false; }}
              className="w-12 h-12 bg-slate-800/80 hover:bg-slate-700 text-white font-black text-lg rounded-xl border border-slate-600 flex items-center justify-center active:bg-cyan-600"
            >
              →
            </button>
          </div>
          <button
            onMouseDown={() => { gameState.current.keys[' '] = true; }}
            onMouseUp={() => { gameState.current.keys[' '] = false; }}
            onTouchStart={() => { gameState.current.keys[' '] = true; }}
            onTouchEnd={() => { gameState.current.keys[' '] = false; }}
            className="px-5 h-12 bg-cyan-500/80 hover:bg-cyan-400 text-black font-black text-xs uppercase rounded-xl border border-cyan-300 flex items-center gap-1.5 active:bg-cyan-300 shadow-lg"
          >
            <Zap className="w-4 h-4 fill-black" /> Nitro Boost
          </button>
        </div>

        {crashed && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-20">
            <Flame className="w-12 h-12 text-rose-500 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Crash Occurred!</h3>
            <p className="text-xs text-slate-400 mb-4">Traveled {distance} Meters • Earned {score} Coins</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/30 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Restart Drive
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Steer: <strong className="text-slate-200">A/D or ←/→</strong></span>
        <span>Nitro Boost: <strong className="text-cyan-300">SPACE or W</strong></span>
      </div>
    </div>
  );
};
