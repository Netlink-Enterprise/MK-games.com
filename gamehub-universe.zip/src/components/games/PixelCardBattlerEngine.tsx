import React, { useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Heart, Zap, Shield, Sparkles } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelCardBattlerEngine: React.FC<Props> = () => {
  const [playerHp, setPlayerHp] = useState<number>(60);
  const [playerBlock, setPlayerBlock] = useState<number>(0);
  const [bossHp, setBossHp] = useState<number>(100);
  const [energy, setEnergy] = useState<number>(3);
  const [turn, setTurn] = useState<number>(1);
  const [log, setLog] = useState<string>('Battle started against Pixel Behemoth!');

  const playCard = (type: 'strike' | 'defend' | 'fireball') => {
    if (energy <= 0) return;

    soundManager.play('click');
    setEnergy(e => e - 1);

    if (type === 'strike') {
      soundManager.play('score');
      setBossHp(h => Math.max(0, h - 14));
      setLog('⚔️ Played Strike! Dealt 14 damage.');
    } else if (type === 'defend') {
      soundManager.play('click');
      setPlayerBlock(b => b + 10);
      setLog('🛡️ Played Defend! Gained 10 Block.');
    } else if (type === 'fireball') {
      soundManager.play('score');
      setBossHp(h => Math.max(0, h - 25));
      setLog('🔥 Cast Fireball! Dealt 25 heavy magic damage.');
    }
  };

  const endTurn = () => {
    soundManager.play('move');
    // Boss turn
    const bossDamage = 16;
    const remainingDmg = Math.max(0, bossDamage - playerBlock);
    setPlayerBlock(0);
    setPlayerHp(h => Math.max(0, h - remainingDmg));
    setEnergy(3);
    setTurn(t => t + 1);
    setLog(`👹 Boss attacked for ${bossDamage}! (${remainingDmg} bypassed block)`);
  };

  const resetGame = () => {
    soundManager.play('click');
    setPlayerHp(60);
    setPlayerBlock(0);
    setBossHp(100);
    setEnergy(3);
    setTurn(1);
    setLog('Battle reset! Draw your hand.');
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Hero HP: {playerHp}/60</div>
          <div className="text-xs text-indigo-400 font-bold">Block: 🛡️ {playerBlock}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">CARD ROGUELITE</div>
          <div className="text-xs font-bold text-slate-300">Energy: ⚡ {energy}/3</div>
        </div>
        <button onClick={resetGame} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      <div className="w-full bg-slate-950 p-6 rounded-2xl border-2 border-indigo-500/40 text-center mb-4">
        <div className="text-6xl mb-2 animate-pulse">👾</div>
        <div className="text-lg font-black text-white mb-2">Pixel Behemoth</div>
        <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden border border-slate-700">
          <div className="bg-rose-500 h-full transition-all duration-300" style={{ width: `${(bossHp / 100) * 100}%` }} />
        </div>
        <div className="text-xs text-slate-400 mt-1">{bossHp} / 100 HP</div>
      </div>

      <div className="grid grid-cols-3 gap-2 w-full mb-4">
        <button
          onClick={() => playCard('strike')}
          disabled={energy < 1}
          className="p-3 bg-rose-600/30 border border-rose-500 hover:bg-rose-600/40 disabled:opacity-40 font-bold rounded-xl text-xs text-rose-300 text-center active:scale-95 transition-all"
        >
          ⚔️ STRIKE
          <div className="text-[10px] text-slate-400">14 Dmg (1⚡)</div>
        </button>
        <button
          onClick={() => playCard('defend')}
          disabled={energy < 1}
          className="p-3 bg-indigo-600/30 border border-indigo-500 hover:bg-indigo-600/40 disabled:opacity-40 font-bold rounded-xl text-xs text-indigo-300 text-center active:scale-95 transition-all"
        >
          🛡️ DEFEND
          <div className="text-[10px] text-slate-400">10 Block (1⚡)</div>
        </button>
        <button
          onClick={() => playCard('fireball')}
          disabled={energy < 1}
          className="p-3 bg-amber-600/30 border border-amber-500 hover:bg-amber-600/40 disabled:opacity-40 font-bold rounded-xl text-xs text-amber-300 text-center active:scale-95 transition-all"
        >
          🔥 FIREBALL
          <div className="text-[10px] text-slate-400">25 Dmg (1⚡)</div>
        </button>
      </div>

      <button
        onClick={endTurn}
        className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 font-black rounded-xl text-xs mb-3 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
      >
        END TURN ➔
      </button>

      <div className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-300 font-mono text-center">
        {log}
      </div>
    </div>
  );
};
