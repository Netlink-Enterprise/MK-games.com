import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RotateCcw, Trophy, Play, Zap, Shield, Heart, Sparkles, Flame } from 'lucide-react';

interface Props {
  gameId: string;
  gameTitle: string;
  category: string;
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const UniversalArcadeEngine: React.FC<Props> = ({ gameId, gameTitle, category, mode }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [hp, setHp] = useState(3);
  const [gameOver, setGameOver] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [perk, setPerk] = useState<'shield' | 'laser' | 'speed'>('shield');

  // Engine state
  const state = useRef({
    // Generic Arcade Hero / Vehicle / Ship
    player: { x: 200, y: 260, vx: 0, vy: 0, size: 24, speed: 4, hp: 3, invincibleTimer: 0 },
    bullets: [] as { x: number; y: number; vx: number; vy: number; radius: number }[],
    enemies: [] as { x: number; y: number; vx: number; vy: number; radius: number; color: string }[],
    collectibles: [] as { x: number; y: number; radius: number; type: string }[],
    particles: [] as { x: number; y: number; vx: number; vy: number; color: string; life: number }[],
    keys: {} as Record<string, boolean>,
    score: 0,
    frameCount: 0
  });

  const startGame = () => {
    soundManager.play('powerup');
    const startHp = perk === 'shield' ? 4 : 3;
    const startSpeed = perk === 'speed' ? 5.5 : 4;

    state.current.player = {
      x: 200,
      y: 260,
      vx: 0,
      vy: 0,
      size: 24,
      speed: startSpeed,
      hp: startHp,
      invincibleTimer: 120 // 2 seconds spawn invincibility
    };
    state.current.bullets = [];
    state.current.enemies = [];
    state.current.collectibles = [];
    state.current.particles = [];
    state.current.score = 0;
    state.current.frameCount = 0;

    setHp(startHp);
    setScore(0);
    setGameOver(false);
    setGameStarted(true);
  };

  const resetEngine = () => {
    startGame();
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      state.current.keys[k] = true;
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) {
        e.preventDefault();
      }
      if (k === ' ' || k === 'j') {
        shootBullet();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      state.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameStarted, gameOver]);

  const shootBullet = () => {
    if (gameOver || !gameStarted) return;
    const p = state.current.player;
    soundManager.play('laser');

    if (perk === 'laser') {
      // Twin laser stream
      state.current.bullets.push(
        { x: p.x - 8, y: p.y - 15, vx: -0.5, vy: -11, radius: 4 },
        { x: p.x + 8, y: p.y - 15, vx: 0.5, vy: -11, radius: 4 }
      );
    } else {
      state.current.bullets.push({
        x: p.x,
        y: p.y - 15,
        vx: 0,
        vy: -10,
        radius: 4
      });
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const gameLoop = () => {
      const st = state.current;
      st.frameCount++;

      if (!gameOver && gameStarted) {
        const p = st.player;
        if (p.invincibleTimer > 0) {
          p.invincibleTimer--;
        }

        // Controls
        if (st.keys['arrowleft'] || st.keys['a']) p.x -= p.speed;
        if (st.keys['arrowright'] || st.keys['d']) p.x += p.speed;
        if (st.keys['arrowup'] || st.keys['w']) p.y -= p.speed;
        if (st.keys['arrowdown'] || st.keys['s']) p.y += p.speed;

        // Boundaries
        p.x = Math.max(p.size, Math.min(canvas.width - p.size, p.x));
        p.y = Math.max(p.size, Math.min(canvas.height - p.size, p.y));

        // Spawn Hazards / Enemies (slower spawn rate at start for fair gameplay)
        const spawnInterval = Math.max(25, 50 - Math.floor(st.score / 100));
        if (st.frameCount % spawnInterval === 0) {
          const colors = ['#f43f5e', '#a855f7', '#38bdf8', '#f59e0b'];
          st.enemies.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -20,
            vx: (Math.random() - 0.5) * 1.5,
            vy: 1.5 + Math.random() * 2,
            radius: 12 + Math.random() * 8,
            color: colors[Math.floor(Math.random() * colors.length)]
          });
        }

        // Spawn Collectibles (Coins & Hearts)
        if (st.frameCount % 100 === 0) {
          const isHeart = Math.random() < 0.25;
          st.collectibles.push({
            x: Math.random() * (canvas.width - 40) + 20,
            y: -15,
            radius: 9,
            type: isHeart ? 'heart' : 'coin'
          });
        }

        // Update Bullets
        st.bullets.forEach(b => {
          b.x += b.vx;
          b.y += b.vy;
        });
        st.bullets = st.bullets.filter(b => b.y > -10);

        // Update Enemies
        st.enemies.forEach(e => {
          e.x += e.vx;
          e.y += e.vy;

          // Bullet vs Enemy
          st.bullets.forEach(b => {
            if (Math.hypot(b.x - e.x, b.y - e.y) < b.radius + e.radius) {
              e.y = canvas.height + 100; // destroy
              b.y = -100;
              st.score += 20;
              setScore(st.score);
              soundManager.play('score');

              // Particles
              for (let i = 0; i < 8; i++) {
                st.particles.push({
                  x: e.x,
                  y: e.y,
                  vx: (Math.random() - 0.5) * 6,
                  vy: (Math.random() - 0.5) * 6,
                  color: e.color,
                  life: 15
                });
              }
            }
          });

          // Player vs Enemy Collision
          if (Math.hypot(p.x - e.x, p.y - e.y) < p.size + e.radius - 6) {
            if (p.invincibleTimer === 0) {
              e.y = canvas.height + 100; // destroy enemy
              p.hp -= 1;
              p.invincibleTimer = 90; // 1.5 sec invincibility grace period
              setHp(p.hp);
              soundManager.play('explosion');

              // Explosion FX
              for (let i = 0; i < 15; i++) {
                st.particles.push({
                  x: p.x,
                  y: p.y,
                  vx: (Math.random() - 0.5) * 8,
                  vy: (Math.random() - 0.5) * 8,
                  color: '#f43f5e',
                  life: 20
                });
              }

              if (p.hp <= 0) {
                soundManager.play('lose');
                setGameOver(true);
                setHighScore(prev => Math.max(prev, st.score));
              }
            }
          }
        });
        st.enemies = st.enemies.filter(e => e.y < canvas.height + 50);

        // Update Collectibles
        st.collectibles.forEach(c => {
          c.y += 2;
          if (Math.hypot(p.x - c.x, p.y - c.y) < p.size + c.radius) {
            c.y = canvas.height + 100;
            if (c.type === 'heart') {
              p.hp = Math.min(5, p.hp + 1);
              setHp(p.hp);
              soundManager.play('powerup');
            } else {
              st.score += 50;
              setScore(st.score);
              soundManager.play('score');
            }
          }
        });
        st.collectibles = st.collectibles.filter(c => c.y < canvas.height + 20);

        // Particles
        st.particles.forEach(pt => {
          pt.x += pt.vx;
          pt.y += pt.vy;
          pt.life--;
        });
        st.particles = st.particles.filter(pt => pt.life > 0);
      }

      // Render themed background
      if (gameId.includes('zombie') || gameId.includes('word')) {
        ctx.fillStyle = '#0f1712'; // Graveyard dark green
      } else if (gameId.includes('crossy') || gameId.includes('road')) {
        ctx.fillStyle = '#1e293b'; // Road asphalt
      } else if (gameId.includes('pinball')) {
        ctx.fillStyle = '#1e1b4b'; // Pinball arcade purple
      } else if (gameId.includes('flappy') || gameId.includes('bird')) {
        ctx.fillStyle = '#0284c7'; // Sky blue
      } else {
        ctx.fillStyle = '#090d16'; // Deep space
      }
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Background Accents
      if (gameId.includes('crossy') || gameId.includes('road')) {
        ctx.strokeStyle = '#e2e8f0';
        ctx.setLineDash([15, 15]);
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(canvas.width / 2, 0);
        ctx.lineTo(canvas.width / 2, canvas.height);
        ctx.stroke();
        ctx.setLineDash([]);
      } else if (gameId.includes('flappy') || gameId.includes('bird')) {
        ctx.fillStyle = '#ffffff22';
        ctx.beginPath();
        ctx.arc(80 + (st.frameCount % 500), 60, 30, 0, Math.PI * 2);
        ctx.arc(300 - (st.frameCount % 400), 120, 40, 0, Math.PI * 2);
        ctx.fill();
      } else {
        ctx.fillStyle = '#334155';
        for (let i = 0; i < 20; i++) {
          const sx = (i * 37 + st.frameCount) % canvas.width;
          const sy = (i * 97 + st.frameCount * 2) % canvas.height;
          ctx.fillRect(sx, sy, 2, 2);
        }
      }

      // Collectibles
      st.collectibles.forEach(c => {
        if (c.type === 'heart') {
          ctx.fillStyle = '#f43f5e';
          ctx.beginPath();
          ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.font = '10px sans-serif';
          ctx.fillText('❤️', c.x - 5, c.y + 3);
        } else {
          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.arc(c.x, c.y, c.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(c.x - 2, c.y - 4, 4, 8);
        }
      });

      // Bullets
      st.bullets.forEach(b => {
        if (gameId.includes('zombie') || gameId.includes('word')) {
          ctx.fillStyle = '#f59e0b';
          ctx.beginPath();
          ctx.arc(b.x, b.y, b.radius + 2, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(b.x - 2, b.y - 6, 4, 12);
        }
      });

      // Enemies
      st.enemies.forEach(e => {
        if (gameId.includes('zombie') || gameId.includes('word')) {
          ctx.fillStyle = '#22c55e';
          ctx.fillRect(e.x - e.radius, e.y - e.radius, e.radius * 2, e.radius * 2);
          ctx.fillStyle = '#000';
          ctx.fillRect(e.x - 4, e.y - 4, 3, 3);
          ctx.fillRect(e.x + 2, e.y - 4, 3, 3);
        } else if (gameId.includes('crossy') || gameId.includes('road')) {
          ctx.fillStyle = e.color;
          ctx.fillRect(e.x - 16, e.y - 10, 32, 20);
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(e.x - 8, e.y - 6, 16, 12);
        } else {
          ctx.fillStyle = e.color;
          ctx.beginPath();
          ctx.arc(e.x, e.y, e.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff33';
          ctx.beginPath();
          ctx.arc(e.x - 3, e.y - 3, e.radius / 2, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Particles
      st.particles.forEach(pt => {
        ctx.fillStyle = pt.color;
        ctx.fillRect(pt.x, pt.y, 3, 3);
      });

      // Player Sprite (with invincibility flash)
      if (!gameOver && gameStarted) {
        const p = st.player;
        const isInvincible = p.invincibleTimer > 0;
        const visible = !isInvincible || Math.floor(st.frameCount / 4) % 2 === 0;

        if (visible) {
          if (gameId.includes('flappy') || gameId.includes('bird')) {
            ctx.fillStyle = isInvincible ? '#38bdf8' : '#facc15';
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#000';
            ctx.beginPath();
            ctx.arc(p.x + 6, p.y - 4, 3, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = '#f97316';
            ctx.beginPath();
            ctx.moveTo(p.x + 12, p.y);
            ctx.lineTo(p.x + 20, p.y + 4);
            ctx.lineTo(p.x + 12, p.y + 8);
            ctx.fill();
          } else if (gameId.includes('crossy') || gameId.includes('road')) {
            ctx.fillStyle = isInvincible ? '#38bdf8' : '#4ade80';
            ctx.fillRect(p.x - p.size, p.y - p.size, p.size * 2, p.size * 2);
            ctx.fillStyle = '#000';
            ctx.fillRect(p.x - 6, p.y - 8, 4, 4);
            ctx.fillRect(p.x + 2, p.y - 8, 4, 4);
          } else {
            ctx.fillStyle = isInvincible ? '#38bdf8' : '#6366f1';
            ctx.beginPath();
            ctx.moveTo(p.x, p.y - p.size);
            ctx.lineTo(p.x + p.size, p.y + p.size);
            ctx.lineTo(p.x - p.size, p.y + p.size);
            ctx.closePath();
            ctx.fill();

            // Thruster
            ctx.fillStyle = '#f43f5e';
            const thruster = Math.sin(st.frameCount) * 4;
            ctx.fillRect(p.x - 4, p.y + p.size, 8, 8 + thruster);
          }

          // Shield Aura Ring when invincible
          if (isInvincible) {
            ctx.strokeStyle = '#38bdf8';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size + 8, 0, Math.PI * 2);
            ctx.stroke();
          }
        }
      }

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [gameOver, gameStarted]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg bg-[#0f172a] border border-slate-800 rounded-3xl p-4 shadow-2xl relative">
      {/* Game Header Bar */}
      <div className="flex items-center justify-between w-full mb-3 bg-slate-900 px-4 py-2.5 rounded-xl border border-slate-800">
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-400">{category} Arena</div>
          <div className="text-sm font-black text-white flex items-center gap-2">
            {gameTitle}
          </div>
        </div>

        {/* Lives / Hearts Display */}
        <div className="flex items-center gap-1 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold mr-1">HP:</span>
          {Array.from({ length: 5 }).map((_, i) => (
            <Heart
              key={i}
              className={`w-3.5 h-3.5 transition-all ${
                i < hp ? 'text-rose-500 fill-rose-500 scale-100' : 'text-slate-700 opacity-40 scale-90'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <div className="text-[10px] text-slate-400">Score</div>
            <div className="text-sm font-black text-amber-400">{score}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400">High</div>
            <div className="text-sm font-black text-indigo-400">{highScore}</div>
          </div>
        </div>
      </div>

      {/* Canvas Viewport & Overlays */}
      <div className="relative w-full aspect-[4/3] bg-[#090d16] rounded-2xl border-2 border-slate-800 overflow-hidden flex items-center justify-center shadow-inner">
        <canvas ref={canvasRef} width={420} height={315} className="w-full h-full object-contain" />

        {/* START MENU OVERLAY SCREEN */}
        {!gameStarted && (
          <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-between p-6 text-center z-30">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-[10px] font-bold uppercase rounded-full mb-3">
                <Sparkles className="w-3 h-3 text-amber-400" /> Official Game Menu
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight mb-1">{gameTitle}</h2>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Survive the arcade hazard wave! Collect coins & hearts to stay alive!
              </p>
            </div>

            {/* Perk / Shield Selector */}
            <div className="w-full max-w-xs my-2">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                Choose Starting Perk
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => setPerk('shield')}
                  className={`p-2 rounded-xl border text-center transition-all ${
                    perk === 'shield'
                      ? 'bg-rose-500/20 border-rose-500 text-rose-300 ring-2 ring-rose-500/50'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Shield className="w-4 h-4 mx-auto mb-1 text-rose-400" />
                  <div className="text-[10px] font-bold">+1 Heart</div>
                </button>

                <button
                  onClick={() => setPerk('laser')}
                  className={`p-2 rounded-xl border text-center transition-all ${
                    perk === 'laser'
                      ? 'bg-sky-500/20 border-sky-500 text-sky-300 ring-2 ring-sky-500/50'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Zap className="w-4 h-4 mx-auto mb-1 text-sky-400" />
                  <div className="text-[10px] font-bold">Dual Laser</div>
                </button>

                <button
                  onClick={() => setPerk('speed')}
                  className={`p-2 rounded-xl border text-center transition-all ${
                    perk === 'speed'
                      ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/50'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <Flame className="w-4 h-4 mx-auto mb-1 text-amber-400" />
                  <div className="text-[10px] font-bold">Turbo Speed</div>
                </button>
              </div>
            </div>

            {/* Controls Cheat-Sheet */}
            <div className="bg-slate-900/80 border border-slate-800 p-2.5 rounded-xl w-full max-w-xs text-[11px] text-slate-300 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">Movement:</span>
                <span className="font-bold text-white">WASD / Arrow Keys</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Action:</span>
                <span className="font-bold text-rose-400">Spacebar (Fire Laser)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Shield Protection:</span>
                <span className="font-bold text-emerald-400">2s Spawn Invincibility</span>
              </div>
            </div>

            {/* Play Button */}
            <button
              onClick={startGame}
              className="w-full max-w-xs py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" /> START GAME NOW
            </button>
          </div>
        )}

        {/* GAME OVER SCREEN */}
        {gameOver && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-30 animate-in fade-in">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Game Over!</h3>
            <p className="text-xs text-slate-400 mb-4">
              Final Score: <strong className="text-amber-400">{score} pts</strong> • High Score: {highScore} pts
            </p>

            <div className="flex gap-3">
              <button
                onClick={resetEngine}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 active:scale-95 transition-all shadow-lg shadow-indigo-600/30"
              >
                <RotateCcw className="w-4 h-4" /> Play Again
              </button>
              <button
                onClick={() => setGameStarted(false)}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition-all"
              >
                Main Menu
              </button>
            </div>
          </div>
        )}
      </div>

      {/* On-screen Controls Bar */}
      <div className="flex items-center justify-between w-full mt-3 gap-2">
        <div className="flex gap-1.5">
          <button
            onMouseDown={() => { state.current.keys['a'] = true; }}
            onMouseUp={() => { state.current.keys['a'] = false; }}
            onTouchStart={() => { state.current.keys['a'] = true; }}
            onTouchEnd={() => { state.current.keys['a'] = false; }}
            className="w-10 h-10 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-700 flex items-center justify-center active:bg-indigo-600"
          >
            ←
          </button>
          <button
            onMouseDown={() => { state.current.keys['d'] = true; }}
            onMouseUp={() => { state.current.keys['d'] = false; }}
            onTouchStart={() => { state.current.keys['d'] = true; }}
            onTouchEnd={() => { state.current.keys['d'] = false; }}
            className="w-10 h-10 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-700 flex items-center justify-center active:bg-indigo-600"
          >
            →
          </button>
        </div>

        <button
          onClick={shootBullet}
          className="px-5 h-10 bg-rose-600 hover:bg-rose-500 text-white font-black text-xs uppercase rounded-xl border border-rose-400 flex items-center justify-center gap-1 active:scale-95 shadow-md"
        >
          🚀 Fire Laser (Space)
        </button>
      </div>
    </div>
  );
};

