import React, { useRef, useEffect, useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Crosshair, Shield, Zap, Flame } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  isEnemy?: boolean;
}

interface Enemy {
  x: number;
  y: number;
  hp: number;
  type: number;
  speed: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  life: number;
}

export const Shooter2DEngine: React.FC<Props> = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [health, setHealth] = useState<number>(100);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [wave, setWave] = useState<number>(1);

  const gameState = useRef({
    player: { x: 300, y: 350, vx: 0, vy: 0, radius: 16, cooldown: 0 },
    keys: {} as Record<string, boolean>,
    bullets: [] as Bullet[],
    enemies: [] as Enemy[],
    particles: [] as Particle[],
    score: 0,
    health: 100,
    wave: 1,
    spawnTimer: 0
  });

  const resetGame = () => {
    soundManager.play('click');
    gameState.current = {
      player: { x: 300, y: 350, vx: 0, vy: 0, radius: 16, cooldown: 0 },
      keys: {},
      bullets: [],
      enemies: [],
      particles: [],
      score: 0,
      health: 100,
      wave: 1,
      spawnTimer: 0
    };
    setScore(0);
    setHealth(100);
    setWave(1);
    setGameOver(false);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = true;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let animationFrameId: number;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const spawnEnemy = () => {
      const state = gameState.current;
      const side = Math.floor(Math.random() * 4);
      let x = 0, y = 0;
      if (side === 0) { x = Math.random() * canvas.width; y = -20; }
      else if (side === 1) { x = canvas.width + 20; y = Math.random() * canvas.height; }
      else if (side === 2) { x = Math.random() * canvas.width; y = canvas.height + 20; }
      else { x = -20; y = Math.random() * canvas.height; }

      const enemyType = Math.random() > 0.7 ? 2 : 1;
      state.enemies.push({
        x,
        y,
        hp: enemyType === 2 ? 3 : 1,
        type: enemyType,
        speed: enemyType === 2 ? 1.2 : 2.2
      });
    };

    const spawnExplosion = (x: number, y: number, color: string) => {
      for (let i = 0; i < 12; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 4 + 1;
        gameState.current.particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color,
          life: 20 + Math.random() * 15
        });
      }
    };

    const update = () => {
      const state = gameState.current;
      if (state.health <= 0) {
        setGameOver(true);
        return;
      }

      // Movement
      const speed = 4.5;
      let dx = 0, dy = 0;
      if (state.keys['w'] || state.keys['arrowup']) dy -= 1;
      if (state.keys['s'] || state.keys['arrowdown']) dy += 1;
      if (state.keys['a'] || state.keys['arrowleft']) dx -= 1;
      if (state.keys['d'] || state.keys['arrowright']) dx += 1;

      if (dx !== 0 && dy !== 0) {
        dx *= 0.707;
        dy *= 0.707;
      }

      state.player.x += dx * speed;
      state.player.y += dy * speed;

      // Bound player inside canvas
      state.player.x = Math.max(16, Math.min(canvas.width - 16, state.player.x));
      state.player.y = Math.max(16, Math.min(canvas.height - 16, state.player.y));

      // Shooting cooldown
      if (state.player.cooldown > 0) state.player.cooldown--;

      if ((state.keys[' '] || state.keys['j']) && state.player.cooldown <= 0) {
        soundManager.play('click');
        state.player.cooldown = 8;
        // Shoot 3-way bullets or forward bullet
        state.bullets.push({
          x: state.player.x,
          y: state.player.y - 12,
          vx: 0,
          vy: -10
        });
        if (state.score > 15) {
          state.bullets.push({ x: state.player.x, y: state.player.y - 12, vx: -2, vy: -9 });
          state.bullets.push({ x: state.player.x, y: state.player.y - 12, vx: 2, vy: -9 });
        }
      }

      // Update Bullets
      state.bullets.forEach(b => {
        b.x += b.vx;
        b.y += b.vy;
      });
      state.bullets = state.bullets.filter(b => b.x >= 0 && b.x <= canvas.width && b.y >= 0 && b.y <= canvas.height);

      // Enemy Spawning
      state.spawnTimer++;
      if (state.spawnTimer > Math.max(15, 60 - state.wave * 5)) {
        state.spawnTimer = 0;
        spawnEnemy();
      }

      // Update Enemies
      state.enemies.forEach(e => {
        const angle = Math.atan2(state.player.y - e.y, state.player.x - e.x);
        e.x += Math.cos(angle) * e.speed;
        e.y += Math.sin(angle) * e.speed;

        // Check collision with player
        const dist = Math.hypot(state.player.x - e.x, state.player.y - e.y);
        if (dist < state.player.radius + 12) {
          soundManager.play('move');
          state.health -= 15;
          setHealth(Math.max(0, state.health));
          e.hp = 0;
          spawnExplosion(e.x, e.y, '#f43f5e');
        }
      });

      // Check Bullet-Enemy collisions
      state.bullets.forEach(b => {
        state.enemies.forEach(e => {
          if (e.hp > 0) {
            const dist = Math.hypot(b.x - e.x, b.y - e.y);
            if (dist < 18) {
              b.y = -999; // destroy bullet
              e.hp--;
              spawnExplosion(b.x, b.y, '#38bdf8');
              if (e.hp <= 0) {
                soundManager.play('score');
                state.score += e.type === 2 ? 30 : 10;
                setScore(state.score);
                if (state.score % 100 === 0) {
                  state.wave++;
                  setWave(state.wave);
                }
                spawnExplosion(e.x, e.y, '#f59e0b');
              }
            }
          }
        });
      });

      state.enemies = state.enemies.filter(e => e.hp > 0);

      // Update Particles
      state.particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life--;
      });
      state.particles = state.particles.filter(p => p.life > 0);
    };

    const render = () => {
      ctx.fillStyle = '#0a0a0f';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Grid background effect
      ctx.strokeStyle = '#1e1b4b';
      ctx.lineWidth = 1;
      const gridSize = 40;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      const state = gameState.current;

      // Draw Particles
      state.particles.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, Math.max(1, p.life / 5), 0, Math.PI * 2);
        ctx.fill();
      });

      // Draw Bullets
      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = '#0284c7';
      ctx.shadowBlur = 8;
      state.bullets.forEach(b => {
        ctx.fillRect(b.x - 2, b.y - 6, 4, 12);
      });
      ctx.shadowBlur = 0;

      // Draw Enemies
      state.enemies.forEach(e => {
        ctx.save();
        ctx.translate(e.x, e.y);
        ctx.fillStyle = e.type === 2 ? '#e11d48' : '#f59e0b';
        ctx.beginPath();
        ctx.arc(0, 0, e.type === 2 ? 16 : 12, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.restore();
      });

      // Draw Player Ship
      if (state.health > 0) {
        ctx.save();
        ctx.translate(state.player.x, state.player.y);

        // Ship wings
        ctx.fillStyle = '#6366f1';
        ctx.beginPath();
        ctx.moveTo(0, -18);
        ctx.lineTo(16, 14);
        ctx.lineTo(0, 8);
        ctx.lineTo(-16, 14);
        ctx.closePath();
        ctx.fill();

        // Cockpit
        ctx.fillStyle = '#38bdf8';
        ctx.beginPath();
        ctx.arc(0, -4, 5, 0, Math.PI * 2);
        ctx.fill();

        // Thruster flame
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.moveTo(-6, 10);
        ctx.lineTo(0, 18 + Math.random() * 6);
        ctx.lineTo(6, 10);
        ctx.fill();

        ctx.restore();
      }
    };

    const loop = () => {
      update();
      render();
      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-lg mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-400">Hull Shield</div>
          <div className="w-24 bg-slate-800 h-3 rounded-full overflow-hidden border border-slate-700">
            <div
              className={`h-full transition-all duration-300 ${health > 50 ? 'bg-emerald-500' : health > 25 ? 'bg-amber-500' : 'bg-rose-500 animate-pulse'}`}
              style={{ width: `${health}%` }}
            />
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-cyan-400 uppercase tracking-widest">Cyber Storm 2D</div>
          <div className="text-xs font-bold text-slate-300">Wave {wave}</div>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-slate-400">Score</div>
          <div className="text-xl font-black text-amber-400">{score}</div>
        </div>
      </div>

      <div className="relative w-full aspect-[4/3] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4">
        <canvas ref={canvasRef} width={500} height={375} className="w-full h-full object-cover" />

        {gameOver && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Flame className="w-12 h-12 text-rose-500 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Ship Destroyed!</h3>
            <p className="text-xs text-slate-400 mb-4">Final Score: {score} • Reached Wave {wave}</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/30 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Deploy Again
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Controls: <strong className="text-slate-200">WASD / Arrows</strong> to fly</span>
        <span>Fire Laser: <strong className="text-slate-200">SPACE or J</strong></span>
      </div>
    </div>
  );
};
