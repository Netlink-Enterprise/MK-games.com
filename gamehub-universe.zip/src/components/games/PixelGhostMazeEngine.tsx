import React, { useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const PixelGhostMazeEngine: React.FC<Props> = () => {
  const [player, setPlayer] = useState({ x: 1, y: 1 });
  const [score, setScore] = useState<number>(0);
  const [dots, setDots] = useState(() => {
    const d = [];
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        if (r !== 1 || c !== 1) d.push({ x: c, y: r, eaten: false });
      }
    }
    return d;
  });

  const movePlayer = (dx: number, dy: number) => {
    const nx = Math.max(0, Math.min(6, player.x + dx));
    const ny = Math.max(0, Math.min(6, player.y + dy));

    soundManager.play('click');
    setPlayer({ x: nx, y: ny });

    const dot = dots.find(d => d.x === nx && d.y === ny && !d.eaten);
    if (dot) {
      soundManager.play('score');
      dot.eaten = true;
      setDots([...dots]);
      setScore(s => s + 10);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-indigo-400 font-bold">PIXEL GHOST MAZE</div>
        </div>
        <div>
          <div className="text-xs text-amber-400 font-bold">Score: 🟡 {score}</div>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1.5 w-full aspect-square p-3 bg-slate-950 rounded-2xl border-2 border-indigo-500/40 mb-4">
        {Array.from({ length: 49 }).map((_, idx) => {
          const x = idx % 7;
          const y = Math.floor(idx / 7);
          const isPlayer = player.x === x && player.y === y;
          const dot = dots.find(d => d.x === x && d.y === y && !d.eaten);

          return (
            <div
              key={idx}
              className="flex items-center justify-center bg-slate-900 border border-slate-800/80 rounded-xl text-xl select-none"
            >
              {isPlayer ? '🟡' : dot ? '✨' : ''}
            </div>
          );
        })}
      </div>

      <div className="flex flex-col items-center gap-1">
        <button onClick={() => movePlayer(0, -1)} className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95">
          ▲ UP
        </button>
        <div className="flex gap-2">
          <button onClick={() => movePlayer(-1, 0)} className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95">
            ◀ LEFT
          </button>
          <button onClick={() => movePlayer(0, 1)} className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95">
            ▼ DOWN
          </button>
          <button onClick={() => movePlayer(1, 0)} className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95">
            RIGHT ▶
          </button>
        </div>
      </div>
    </div>
  );
};
