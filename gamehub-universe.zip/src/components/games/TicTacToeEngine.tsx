import React, { useState } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, Sparkles, Cpu, Grid } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
  onlineData?: any;
  onSendMove?: (moveData: any) => void;
}

export const TicTacToeEngine: React.FC<Props> = ({ mode }) => {
  const [size, setSize] = useState<3 | 4 | 5>(3);
  const [board, setBoard] = useState<(string | null)[]>(() => Array(9).fill(null));
  const [turn, setTurn] = useState<'X' | 'O'>('X');
  const [winner, setWinner] = useState<string | null>(null);
  const [scores, setScores] = useState({ x: 0, o: 0 });

  const getTargetInRow = (s: number) => (s === 3 ? 3 : 4);

  const checkWinner = (b: (string | null)[], currentSize: number) => {
    const target = getTargetInRow(currentSize);

    // Generate win lines
    const lines: number[][] = [];

    // Rows & Cols
    for (let r = 0; r < currentSize; r++) {
      for (let c = 0; c <= currentSize - target; c++) {
        const rowLine = [];
        const colLine = [];
        for (let i = 0; i < target; i++) {
          rowLine.push(r * currentSize + (c + i));
          colLine.push((c + i) * currentSize + r);
        }
        lines.push(rowLine, colLine);
      }
    }

    // Diagonals
    for (let r = 0; r <= currentSize - target; r++) {
      for (let c = 0; c <= currentSize - target; c++) {
        const diag1 = [];
        const diag2 = [];
        for (let i = 0; i < target; i++) {
          diag1.push((r + i) * currentSize + (c + i));
          diag2.push((r + i) * currentSize + (c + target - 1 - i));
        }
        lines.push(diag1, diag2);
      }
    }

    for (const line of lines) {
      const first = b[line[0]];
      if (first && line.every(idx => b[idx] === first)) {
        return first;
      }
    }

    if (b.every(cell => cell !== null)) return 'Draw';
    return null;
  };

  const changeGridSize = (newSize: 3 | 4 | 5) => {
    soundManager.play('click');
    setSize(newSize);
    setBoard(Array(newSize * newSize).fill(null));
    setTurn('X');
    setWinner(null);
  };

  const handleClick = (index: number) => {
    if (board[index] || winner) return;

    soundManager.play('click');
    const newB = [...board];
    newB[index] = turn;
    setBoard(newB);

    const win = checkWinner(newB, size);
    if (win) {
      setWinner(win);
      if (win === 'X') {
        soundManager.play('win');
        setScores(prev => ({ ...prev, x: prev.x + 1 }));
      } else if (win === 'O') {
        soundManager.play(mode === 'vs_bot' ? 'lose' : 'win');
        setScores(prev => ({ ...prev, o: prev.o + 1 }));
      } else {
        soundManager.play('move');
      }
    } else {
      const nextTurn = turn === 'X' ? 'O' : 'X';
      setTurn(nextTurn);

      if (mode === 'vs_bot' && nextTurn === 'O') {
        setTimeout(() => makeBotMove(newB), 350);
      }
    }
  };

  const makeBotMove = (currentBoard: (string | null)[]) => {
    const emptyIndices = currentBoard
      .map((val, idx) => (val === null ? idx : null))
      .filter((val): val is number => val !== null);

    if (emptyIndices.length === 0) return;

    // 1. Check if bot can win immediately
    for (const idx of emptyIndices) {
      const testB = [...currentBoard];
      testB[idx] = 'O';
      if (checkWinner(testB, size) === 'O') {
        handleClick(idx);
        return;
      }
    }

    // 2. Check if bot needs to block X
    for (const idx of emptyIndices) {
      const testB = [...currentBoard];
      testB[idx] = 'X';
      if (checkWinner(testB, size) === 'X') {
        handleClick(idx);
        return;
      }
    }

    // 3. Prefer center or near center
    const centerIdx = Math.floor((size * size) / 2);
    if (emptyIndices.includes(centerIdx)) {
      handleClick(centerIdx);
      return;
    }

    const rand = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
    handleClick(rand);
  };

  const resetGame = () => {
    soundManager.play('click');
    setBoard(Array(size * size).fill(null));
    setTurn('X');
    setWinner(null);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* Header */}
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div className="text-center">
          <div className="text-xs text-slate-400 font-bold">Player X</div>
          <div className="text-xl font-black text-cyan-400">{scores.x} Wins</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Tic-Tac-Toe</div>
          {winner ? (
            <div className="text-sm font-black text-amber-400 animate-bounce">
              {winner === 'Draw' ? 'Draw Game!' : `${winner} Wins! 🎉`}
            </div>
          ) : (
            <div className="text-xs font-bold text-slate-300">Turn: {turn}</div>
          )}
        </div>
        <div className="text-center">
          <div className="text-xs text-slate-400 font-bold">{mode === 'vs_bot' ? 'Bot (O)' : 'Player O'}</div>
          <div className="text-xl font-black text-purple-400">{scores.o} Wins</div>
        </div>
      </div>

      {/* Grid Mode Selector */}
      <div className="flex items-center gap-2 mb-4 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-bold w-full justify-center">
        <span className="text-slate-400 flex items-center gap-1">
          <Grid className="w-3.5 h-3.5 text-cyan-400" /> Grid Level:
        </span>
        {([3, 4, 5] as const).map(s => (
          <button
            key={s}
            onClick={() => changeGridSize(s)}
            className={`px-3 py-1 rounded-lg transition-all ${
              size === s ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            {s}x{s} ({getTargetInRow(s)}-in-a-row)
          </button>
        ))}
      </div>

      {/* Grid */}
      <div
        className={`grid gap-2 w-full aspect-square p-3 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-4`}
        style={{ gridTemplateColumns: `repeat(${size}, minmax(0, 1fr))` }}
      >
        {board.map((cell, idx) => (
          <button
            key={idx}
            onClick={() => handleClick(idx)}
            className={`flex items-center justify-center font-black rounded-xl transition-all duration-150 shadow-md ${
              size === 3 ? 'text-4xl' : size === 4 ? 'text-2xl' : 'text-xl'
            } ${
              cell === 'X'
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 shadow-cyan-500/10'
                : cell === 'O'
                ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40 shadow-purple-500/10'
                : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-transparent'
            }`}
          >
            {cell}
          </button>
        ))}
      </div>

      {/* Reset */}
      <button
        onClick={resetGame}
        className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-cyan-400" />
        New Match
      </button>
    </div>
  );
};
