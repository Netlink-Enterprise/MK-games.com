import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Shield, Trophy, Cpu } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const CheckersEngine: React.FC<Props> = ({ mode }) => {
  const [board, setBoard] = useState<(number | null)[][]>(() => {
    const b = Array(8).fill(null).map(() => Array(8).fill(null));
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 8; c++) {
        if ((r + c) % 2 === 1) b[r][c] = 2; // P2 / Bot
      }
    }
    for (let r = 5; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if ((r + c) % 2 === 1) b[r][c] = 1; // P1
      }
    }
    return b;
  });

  const [selectedPos, setSelectedPos] = useState<[number, number] | null>(null);
  const [turn, setTurn] = useState<number>(1);
  const [scores, setScores] = useState({ p1: 12, p2: 12 });

  useEffect(() => {
    if (mode === 'vs_bot' && turn === 2) {
      const timer = setTimeout(() => makeBotMove(), 500);
      return () => clearTimeout(timer);
    }
  }, [turn, mode, board]);

  const makeBotMove = () => {
    // Collect all valid jumps and normal moves for player 2 (Black)
    const jumps: { sr: number; sc: number; er: number; ec: number; mr: number; mc: number }[] = [];
    const steps: { sr: number; sc: number; er: number; ec: number }[] = [];

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if (board[r][c] === 2) {
          // Check forward jumps
          const jumpDirections = [[2, -2], [2, 2]];
          for (const [dr, dc] of jumpDirections) {
            const er = r + dr;
            const ec = c + dc;
            const mr = r + dr / 2;
            const mc = c + dc / 2;
            if (er >= 0 && er < 8 && ec >= 0 && ec < 8) {
              if (board[er][ec] === null && board[mr][mc] === 1) {
                jumps.push({ sr: r, sc: c, er, ec, mr, mc });
              }
            }
          }

          // Check forward normal steps
          const stepDirections = [[1, -1], [1, 1]];
          for (const [dr, dc] of stepDirections) {
            const er = r + dr;
            const ec = c + dc;
            if (er >= 0 && er < 8 && ec >= 0 && ec < 8) {
              if (board[er][ec] === null) {
                steps.push({ sr: r, sc: c, er, ec });
              }
            }
          }
        }
      }
    }

    if (jumps.length > 0) {
      // Execute jump
      const j = jumps[Math.floor(Math.random() * jumps.length)];
      soundManager.play('score');
      const nextB = board.map(row => [...row]);
      nextB[j.er][j.ec] = 2;
      nextB[j.sr][j.sc] = null;
      nextB[j.mr][j.mc] = null;
      setBoard(nextB);
      setScores(prev => ({ ...prev, p1: prev.p1 - 1 }));
      setTurn(1);
    } else if (steps.length > 0) {
      // Execute step
      const s = steps[Math.floor(Math.random() * steps.length)];
      soundManager.play('move');
      const nextB = board.map(row => [...row]);
      nextB[s.er][s.ec] = 2;
      nextB[s.sr][s.sc] = null;
      setBoard(nextB);
      setTurn(1);
    } else {
      // Pass if trapped
      setTurn(1);
    }
  };

  const handleCellClick = (r: number, c: number) => {
    if ((r + c) % 2 === 0) return; // Only playable dark tiles

    if (selectedPos) {
      const [sr, sc] = selectedPos;
      if (sr === r && sc === c) {
        setSelectedPos(null);
        return;
      }

      // Simple checker move or jump validation
      const rowDiff = r - sr;
      const colDiff = Math.abs(c - sc);

      if (board[r][c] === null) {
        // Normal step
        if ((turn === 1 && rowDiff === -1 && colDiff === 1) || (turn === 2 && rowDiff === 1 && colDiff === 1)) {
          soundManager.play('move');
          const nextB = board.map(row => [...row]);
          nextB[r][c] = turn;
          nextB[sr][sc] = null;
          setBoard(nextB);
          setSelectedPos(null);
          setTurn(turn === 1 ? 2 : 1);
          return;
        }

        // Jump capture
        if (colDiff === 2 && Math.abs(rowDiff) === 2) {
          const midR = (sr + r) / 2;
          const midC = (sc + c) / 2;
          const capturedPiece = board[midR][midC];

          if (capturedPiece !== null && capturedPiece !== turn) {
            soundManager.play('score');
            const nextB = board.map(row => [...row]);
            nextB[r][c] = turn;
            nextB[sr][sc] = null;
            nextB[midR][midC] = null; // Remove captured
            setBoard(nextB);
            setSelectedPos(null);

            setScores(prev => ({
              ...prev,
              [turn === 1 ? 'p2' : 'p1']: prev[turn === 1 ? 'p2' : 'p1'] - 1
            }));

            setTurn(turn === 1 ? 2 : 1);
            return;
          }
        }
      }
    }

    // Select piece
    if (board[r][c] === turn) {
      soundManager.play('click');
      setSelectedPos([r, c]);
    }
  };

  const resetGame = () => {
    soundManager.play('click');
    const b = Array(8).fill(null).map(() => Array(8).fill(null));
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 8; c++) {
        if ((r + c) % 2 === 1) b[r][c] = 2;
      }
    }
    for (let r = 5; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        if ((r + c) % 2 === 1) b[r][c] = 1;
      }
    }
    setBoard(b);
    setSelectedPos(null);
    setTurn(1);
    setScores({ p1: 12, p2: 12 });
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-6 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">Player 1 (Red)</div>
          <div className="text-xl font-black text-rose-400">{scores.p1} Pieces</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Checkers Tactics</div>
          <div className="text-xs font-bold text-slate-300">Turn: {turn === 1 ? 'Red' : 'Black'}</div>
        </div>
        <div>
          <div className="text-xs text-slate-400 font-bold">Player 2 (Black)</div>
          <div className="text-xl font-black text-slate-300">{scores.p2} Pieces</div>
        </div>
      </div>

      <div className="grid grid-cols-8 gap-0.5 w-full aspect-square p-2 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-6">
        {board.map((row, rIdx) =>
          row.map((cell, cIdx) => {
            const isDark = (rIdx + cIdx) % 2 === 1;
            const isSelected = selectedPos?.[0] === rIdx && selectedPos?.[1] === cIdx;

            return (
              <button
                key={`${rIdx}-${cIdx}`}
                onClick={() => handleCellClick(rIdx, cIdx)}
                className={`flex items-center justify-center transition-all ${
                  isDark ? 'bg-slate-900 hover:bg-slate-800' : 'bg-slate-800/40'
                } ${isSelected ? 'ring-2 ring-amber-400' : ''}`}
              >
                {cell === 1 && (
                  <div className="w-3/4 h-3/4 rounded-full bg-rose-500 border-2 border-rose-300 shadow-md shadow-rose-500/30" />
                )}
                {cell === 2 && (
                  <div className="w-3/4 h-3/4 rounded-full bg-slate-700 border-2 border-slate-500 shadow-md" />
                )}
              </button>
            );
          })
        )}
      </div>

      <button
        onClick={resetGame}
        className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-cyan-400" />
        Reset Board
      </button>
    </div>
  );
};
