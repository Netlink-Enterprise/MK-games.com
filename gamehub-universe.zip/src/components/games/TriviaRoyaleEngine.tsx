import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { HelpCircle, Sparkles, Trophy, Clock, RefreshCw } from 'lucide-react';

interface Question {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const DEFAULT_QUESTIONS: Question[] = [
  {
    question: 'Which legendary game introduced the iconic character Mario?',
    options: ['Donkey Kong (1981)', 'Super Mario Bros (1985)', 'Pac-Man (1980)', 'Galaga (1981)'],
    correctIndex: 0,
    explanation: 'Mario debuted as "Jumpman" in Nintendo\'s arcade hit Donkey Kong!'
  },
  {
    question: 'What is the highest-selling video game of all time?',
    options: ['Tetris', 'Grand Theft Auto V', 'Minecraft', 'Wii Sports'],
    correctIndex: 2,
    explanation: 'Minecraft has sold over 300 million copies worldwide!'
  },
  {
    question: 'In Esports, what does FPS stand for?',
    options: ['First Person Shooter', 'Frames Per Second', 'Fast Player Speed', 'Final Point Score'],
    correctIndex: 0,
    explanation: 'FPS stands for First Person Shooter (though it also means Frames Per Second in graphics!).'
  },
  {
    question: 'Which studio created the Witcher game series and Cyberpunk 2077?',
    options: ['CD Projekt Red', 'Bethesda Softworks', 'BioWare', 'Ubisoft'],
    correctIndex: 0,
    explanation: 'CD Projekt Red is based in Warsaw, Poland.'
  }
];

export const TriviaRoyaleEngine: React.FC = () => {
  const [questions, setQuestions] = useState<Question[]>(DEFAULT_QUESTIONS);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [score, setScore] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [timer, setTimer] = useState<number>(15);
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);
  const [topicInput, setTopicInput] = useState<string>('');

  useEffect(() => {
    if (isAnswered || currentIndex >= questions.length) return;

    const interval = setInterval(() => {
      setTimer(prev => {
        if (prev <= 1) {
          handleSelectOption(-1); // Timeout
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentIndex, isAnswered, questions]);

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;

    setSelectedOption(index);
    setIsAnswered(true);

    const q = questions[currentIndex];
    if (index === q.correctIndex) {
      soundManager.play('win');
      setScore(prev => prev + 100 + timer * 10);
    } else {
      soundManager.play('lose');
    }
  };

  const nextQuestion = () => {
    soundManager.play('click');
    setSelectedOption(null);
    setIsAnswered(false);
    setTimer(15);
    setCurrentIndex(prev => prev + 1);
  };

  const fetchAiTrivia = async () => {
    try {
      setIsLoadingAi(true);
      soundManager.play('click');
      const res = await fetch('/api/gemini/ai-game-master', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'generate_trivia',
          prompt: topicInput || 'Retro Arcade Games & Gaming Culture'
        })
      });
      const data = await res.json();
      if (data.gameData?.questions && data.gameData.questions.length > 0) {
        setQuestions(data.gameData.questions);
        setCurrentIndex(0);
        setScore(0);
        setSelectedOption(null);
        setIsAnswered(false);
        setTimer(15);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingAi(false);
    }
  };

  const restartQuiz = () => {
    soundManager.play('click');
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setTimer(15);
  };

  const q = questions[currentIndex];
  const isFinished = currentIndex >= questions.length;

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* AI Topic Prompt Bar */}
      <div className="flex items-center gap-2 w-full mb-6 bg-slate-950 p-2 rounded-xl border border-slate-800">
        <input
          type="text"
          placeholder="Type any AI topic (e.g. Pokemon, Esports, Anime)..."
          value={topicInput}
          onChange={e => setTopicInput(e.target.value)}
          className="flex-1 bg-transparent px-3 py-2 text-sm text-slate-200 outline-none"
        />
        <button
          onClick={fetchAiTrivia}
          disabled={isLoadingAi}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-lg shadow-md active:scale-95 disabled:opacity-50"
        >
          <Sparkles className="w-3.5 h-3.5" />
          {isLoadingAi ? 'Generating AI...' : 'AI Generate'}
        </button>
      </div>

      {!isFinished && q ? (
        <div className="w-full">
          {/* Header */}
          <div className="flex items-center justify-between mb-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <span className="text-xs font-bold text-slate-400">Question {currentIndex + 1} of {questions.length}</span>
            <div className="flex items-center gap-1.5 text-amber-400 font-black text-sm">
              <Clock className="w-4 h-4" />
              {timer}s
            </div>
            <span className="text-sm font-black text-emerald-400">{score} Points</span>
          </div>

          {/* Question Box */}
          <div className="bg-slate-950 p-6 rounded-2xl border-2 border-slate-800 mb-6 text-center">
            <h3 className="text-lg font-bold text-slate-100">{q.question}</h3>
          </div>

          {/* Options */}
          <div className="grid grid-cols-1 gap-3 mb-6">
            {q.options.map((opt, idx) => {
              let btnClass = 'bg-slate-950 hover:bg-slate-800 border-slate-800 text-slate-200';
              if (isAnswered) {
                if (idx === q.correctIndex) btnClass = 'bg-emerald-600 text-white border-emerald-500 font-bold';
                else if (idx === selectedOption) btnClass = 'bg-rose-600 text-white border-rose-500';
              }
              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`p-4 text-left rounded-xl border-2 transition-all font-semibold text-sm ${btnClass}`}
                >
                  <span className="inline-block w-6 font-bold opacity-60">{String.fromCharCode(65 + idx)}.</span>
                  {opt}
                </button>
              );
            })}
          </div>

          {/* Explanation Banner */}
          {isAnswered && (
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 mb-6 text-center">
              <p className="text-xs text-slate-300">{q.explanation}</p>
              <button
                onClick={nextQuestion}
                className="mt-3 px-6 py-2 bg-cyan-500 text-slate-950 font-black text-xs rounded-lg hover:bg-cyan-400 shadow-md"
              >
                Next Question →
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center p-8 bg-slate-950 rounded-2xl border border-slate-800 w-full">
          <Trophy className="w-16 h-16 text-amber-400 mx-auto mb-4 animate-bounce" />
          <h2 className="text-2xl font-black text-slate-100 mb-2">Quiz Complete!</h2>
          <p className="text-lg font-bold text-emerald-400 mb-6">Final Score: {score} Points</p>
          <button
            onClick={restartQuiz}
            className="flex items-center gap-2 mx-auto px-6 py-3 bg-cyan-500 text-slate-950 font-black text-sm rounded-xl shadow-lg active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            Play Again
          </button>
        </div>
      )}
    </div>
  );
};
