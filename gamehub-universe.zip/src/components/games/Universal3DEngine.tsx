import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, Zap, Shield, Heart, Sparkles, Play, ArrowLeft, ArrowRight, ArrowUp, ArrowDown } from 'lucide-react';

interface Props {
  gameId: string;
  gameTitle: string;
  category: string;
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const Universal3DEngine: React.FC<Props> = ({ gameId, gameTitle, category, mode }) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [highScore, setHighScore] = useState<number>(0);
  const [hp, setHp] = useState<number>(3);
  const [speed, setSpeed] = useState<number>(60);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [gameStarted, setGameStarted] = useState<boolean>(false);
  const [level, setLevel] = useState<number>(1);

  const gameState = useRef({
    score: 0,
    speed: 60,
    level: 1,
    hp: 3,
    invincibleTimer: 0,
    gameOver: false,
    playerPos: { x: 0, y: 0, z: 0 },
    keys: {} as Record<string, boolean>,
    objects: [] as THREE.Mesh[],
    particles: [] as { mesh: THREE.Mesh; vx: number; vy: number; vz: number; life: number }[],
    frameCount: 0
  });

  const start3DGame = () => {
    soundManager.play('powerup');
    gameState.current.score = 0;
    gameState.current.speed = 60;
    gameState.current.level = 1;
    gameState.current.hp = 3;
    gameState.current.invincibleTimer = 120; // 2s spawn protection
    gameState.current.gameOver = false;
    gameState.current.playerPos = { x: 0, y: 0, z: 0 };
    setHp(3);
    setScore(0);
    setSpeed(60);
    setLevel(1);
    setGameOver(false);
    setGameStarted(true);
  };

  const reset3DGame = () => {
    start3DGame();
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // --- THREE.JS SCENE SETUP ---
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(
      gameId.includes('dungeon') ? 0x05050a : gameId.includes('space') || gameId.includes('hover') ? 0x020208 : 0x0a0e1a
    );
    scene.fog = new THREE.FogExp2(scene.background, 0.015);

    const camera = new THREE.PerspectiveCamera(70, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 3, 8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x606080, 1.8);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x6366f1, 2.5);
    dirLight.position.set(10, 20, 15);
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0x38bdf8, 4, 30);
    pointLight.position.set(0, 4, 2);
    scene.add(pointLight);

    // --- GAME SPECIFIC SCENE CONTENT ---
    let playerMesh: THREE.Mesh | THREE.Group;

    if (gameId === 'cyber_3d_racer') {
      // 3D Cyber Road Grid
      const roadGeo = new THREE.PlaneGeometry(16, 200);
      const roadMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1, metalness: 0.8 });
      const road = new THREE.Mesh(roadGeo, roadMat);
      road.rotation.x = -Math.PI / 2;
      road.position.z = -80;
      scene.add(road);

      const gridHelper = new THREE.GridHelper(200, 40, 0x38bdf8, 0x1e1b4b);
      gridHelper.position.y = 0.05;
      gridHelper.position.z = -80;
      scene.add(gridHelper);

      // Cyber Sports Car
      const carGroup = new THREE.Group();
      const carGeo = new THREE.BoxGeometry(1.4, 0.6, 2.6);
      const carMat = new THREE.MeshStandardMaterial({ color: 0x6366f1, emissive: 0x1e1b4b, roughness: 0.2 });
      const carBody = new THREE.Mesh(carGeo, carMat);
      carGroup.add(carBody);

      // Neon spoiler
      const spoilerGeo = new THREE.BoxGeometry(1.6, 0.2, 0.4);
      const spoilerMat = new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0x881337 });
      const spoiler = new THREE.Mesh(spoilerGeo, spoilerMat);
      spoiler.position.set(0, 0.5, 1.1);
      carGroup.add(spoiler);

      playerMesh = carGroup;
      playerMesh.position.set(0, 0.4, 3);
      scene.add(playerMesh);
    } else if (gameId === 'space_3d_dogfight') {
      // Starfield
      const starsGeo = new THREE.BufferGeometry();
      const count = 600;
      const positions = new Float32Array(count * 3);
      for (let i = 0; i < count * 3; i++) {
        positions[i] = (Math.random() - 0.5) * 200;
      }
      starsGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      const starField = new THREE.Points(starsGeo, new THREE.PointsMaterial({ color: 0x38bdf8, size: 0.9 }));
      scene.add(starField);

      // Starfighter Jet
      const jetGroup = new THREE.Group();
      const bodyGeo = new THREE.ConeGeometry(0.8, 2.8, 5);
      bodyGeo.rotateX(Math.PI / 2);
      const body = new THREE.Mesh(bodyGeo, new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.9 }));
      jetGroup.add(body);

      const wingGeo = new THREE.BoxGeometry(3.2, 0.1, 0.9);
      const wing = new THREE.Mesh(wingGeo, new THREE.MeshStandardMaterial({ color: 0xf43f5e }));
      jetGroup.add(wing);

      playerMesh = jetGroup;
      playerMesh.position.set(0, 2, 2);
      scene.add(playerMesh);
    } else if (gameId === 'dungeon_3d_crawler') {
      // Dark Stone Floor & Walls
      const floorGeo = new THREE.PlaneGeometry(20, 100);
      const floorMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.9 });
      const floor = new THREE.Mesh(floorGeo, floorMat);
      floor.rotation.x = -Math.PI / 2;
      floor.position.z = -40;
      scene.add(floor);

      // Left and Right Stone Pillars
      for (let z = 0; z > -80; z -= 8) {
        const pillarGeo = new THREE.BoxGeometry(1.5, 6, 1.5);
        const pillarMat = new THREE.MeshStandardMaterial({ color: 0x292524 });
        const leftP = new THREE.Mesh(pillarGeo, pillarMat);
        leftP.position.set(-6, 3, z);
        const rightP = new THREE.Mesh(pillarGeo, pillarMat);
        rightP.position.set(6, 3, z);
        scene.add(leftP);
        scene.add(rightP);
      }

      // Paladin Hero Sphere Shield
      const heroGroup = new THREE.Group();
      const shield = new THREE.Mesh(
        new THREE.SphereGeometry(0.8, 16, 16),
        new THREE.MeshStandardMaterial({ color: 0xf59e0b, emissive: 0x78350f, roughness: 0.2 })
      );
      heroGroup.add(shield);

      playerMesh = heroGroup;
      playerMesh.position.set(0, 1, 3);
      scene.add(playerMesh);
    } else if (gameId === 'bowling_3d') {
      // Polished Wooden Bowling Lane
      const laneGeo = new THREE.BoxGeometry(4.5, 0.2, 35);
      const laneMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.05, metalness: 0.2 });
      const lane = new THREE.Mesh(laneGeo, laneMat);
      lane.position.set(0, 0, -12);
      scene.add(lane);

      // Bowling Gutters
      [-2.5, 2.5].forEach(gx => {
        const g = new THREE.Mesh(
          new THREE.BoxGeometry(0.5, 0.1, 35),
          new THREE.MeshStandardMaterial({ color: 0x1e293b })
        );
        g.position.set(gx, -0.05, -12);
        scene.add(g);
      });

      // Marble Bowling Ball
      const ballGeo = new THREE.SphereGeometry(0.6, 32, 32);
      const ballMat = new THREE.MeshStandardMaterial({ color: 0xd946ef, metalness: 0.9, roughness: 0.1 });
      playerMesh = new THREE.Mesh(ballGeo, ballMat);
      playerMesh.position.set(0, 0.7, 4);
      scene.add(playerMesh);
    } else if (gameId === 'flight_3d_sim') {
      // Sky & Ocean Blue Floor
      const oceanGeo = new THREE.PlaneGeometry(120, 200);
      const oceanMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, roughness: 0.2 });
      const ocean = new THREE.Mesh(oceanGeo, oceanMat);
      ocean.rotation.x = -Math.PI / 2;
      ocean.position.y = -5;
      scene.add(ocean);

      // Stunt Propeller Aircraft
      const planeGroup = new THREE.Group();
      const body = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.3, 3, 16),
        new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.5 })
      );
      body.rotation.x = Math.PI / 2;
      planeGroup.add(body);

      const wing = new THREE.Mesh(
        new THREE.BoxGeometry(4, 0.08, 0.8),
        new THREE.MeshStandardMaterial({ color: 0xd97706 })
      );
      planeGroup.add(wing);

      playerMesh = planeGroup;
      playerMesh.position.set(0, 2, 2);
      scene.add(playerMesh);
    } else if (gameId === 'block_3d_craft') {
      // Voxel Grass Ground
      for (let x = -10; x <= 10; x += 2) {
        for (let z = -10; z >= -40; z -= 2) {
          const block = new THREE.Mesh(
            new THREE.BoxGeometry(1.9, 1.9, 1.9),
            new THREE.MeshStandardMaterial({ color: Math.random() > 0.2 ? 0x15803d : 0x047857 })
          );
          block.position.set(x, -1, z);
          scene.add(block);
        }
      }

      // Voxel Builder Avatar
      playerMesh = new THREE.Mesh(
        new THREE.BoxGeometry(1.2, 1.8, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x0284c7 })
      );
      playerMesh.position.set(0, 1, 2);
      scene.add(playerMesh);
    } else if (gameId === 'parkour_3d_run') {
      // Rooftops
      for (let z = 0; z > -100; z -= 12) {
        const roof = new THREE.Mesh(
          new THREE.BoxGeometry(12, 10, 10),
          new THREE.MeshStandardMaterial({ color: 0x334155, roughness: 0.8 })
        );
        roof.position.set((Math.random() - 0.5) * 4, -5, z);
        scene.add(roof);
      }

      // Parkour Runner Capsule
      playerMesh = new THREE.Mesh(
        new THREE.CapsuleGeometry(0.5, 1, 8, 16),
        new THREE.MeshStandardMaterial({ color: 0xf43f5e, emissive: 0x881337 })
      );
      playerMesh.position.set(0, 1.2, 3);
      scene.add(playerMesh);
    } else if (gameId === 'mini_golf_3d') {
      // Mini Golf Green Felt
      const course = new THREE.Mesh(
        new THREE.BoxGeometry(5, 0.2, 30),
        new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.4 })
      );
      course.position.set(0, 0, -10);
      scene.add(course);

      // Golf Ball
      playerMesh = new THREE.Mesh(
        new THREE.SphereGeometry(0.35, 32, 32),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.1 })
      );
      playerMesh.position.set(0, 0.45, 3);
      scene.add(playerMesh);
    } else if (gameId === 'hover_3d_arena') {
      // Cyber Arena Platform
      const platform = new THREE.Mesh(
        new THREE.CylinderGeometry(20, 20, 0.5, 32),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.1 })
      );
      platform.position.set(0, 0, -10);
      scene.add(platform);

      // Hover Tank
      const tankGroup = new THREE.Group();
      const base = new THREE.Mesh(
        new THREE.BoxGeometry(2, 0.6, 2.5),
        new THREE.MeshStandardMaterial({ color: 0x7c3aed, metalness: 0.8 })
      );
      tankGroup.add(base);

      const turret = new THREE.Mesh(
        new THREE.CylinderGeometry(0.5, 0.5, 0.6, 16),
        new THREE.MeshStandardMaterial({ color: 0xc084fc })
      );
      turret.position.y = 0.5;
      tankGroup.add(turret);

      playerMesh = tankGroup;
      playerMesh.position.set(0, 0.5, 2);
      scene.add(playerMesh);
    } else {
      // Roller Coaster Thrill Train
      const train = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 1, 3),
        new THREE.MeshStandardMaterial({ color: 0xeab308, metalness: 0.6 })
      );
      playerMesh = train;
      playerMesh.position.set(0, 1, 2);
      scene.add(playerMesh);
    }

    // Spawn 3D Hazards / Collectibles
    const spawnHazards = () => {
      const hazardGeo = new THREE.IcosahedronGeometry(0.8, 1);
      const hazardMat = new THREE.MeshStandardMaterial({ color: 0xef4444, emissive: 0x450a0a });

      for (let i = 0; i < 12; i++) {
        const hazard = new THREE.Mesh(hazardGeo, hazardMat);
        hazard.position.set(
          (Math.random() - 0.5) * 12,
          0.8 + Math.random() * 2,
          -15 - Math.random() * 80
        );
        scene.add(hazard);
        gameState.current.objects.push(hazard);
      }
    };

    spawnHazards();

    // Controls
    const handleKeyDown = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      gameState.current.keys[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    // Animation Loop
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const st = gameState.current;
      st.frameCount++;

      if (!st.gameOver && gameStarted) {
        if (st.invincibleTimer > 0) {
          st.invincibleTimer--;
        }

        // Player Controls
        const speedX = 0.2;
        if (st.keys['arrowleft'] || st.keys['a']) playerMesh.position.x -= speedX;
        if (st.keys['arrowright'] || st.keys['d']) playerMesh.position.x += speedX;
        if (st.keys['arrowup'] || st.keys['w']) {
          if (gameId === 'bowling_3d' || gameId === 'mini_golf_3d') {
            playerMesh.position.z -= 0.4;
          } else {
            playerMesh.position.y += 0.15;
          }
        }
        if (st.keys['arrowdown'] || st.keys['s']) {
          if (gameId === 'bowling_3d' || gameId === 'mini_golf_3d') {
            playerMesh.position.z += 0.4;
          } else {
            playerMesh.position.y = Math.max(0.4, playerMesh.position.y - 0.15);
          }
        }

        // Keep player in boundary
        playerMesh.position.x = Math.max(-7, Math.min(7, playerMesh.position.x));

        // Move 3D World Hazards forward
        st.objects.forEach(obj => {
          if (gameId === 'cyber_3d_racer' || gameId === 'parkour_3d_run' || gameId === 'space_3d_dogfight') {
            obj.position.z += 0.6 + st.speed * 0.005;
            obj.rotation.x += 0.03;
            obj.rotation.y += 0.04;

            // Collision check
            if (obj.position.distanceTo(playerMesh.position) < 1.4) {
              if (st.invincibleTimer === 0) {
                soundManager.play('explosion');
                st.hp -= 1;
                st.invincibleTimer = 90; // 1.5s invincibility grace
                setHp(st.hp);

                // Respawn obstacle far back
                obj.position.z = -90 - Math.random() * 20;
                obj.position.x = (Math.random() - 0.5) * 12;

                if (st.hp <= 0) {
                  soundManager.play('lose');
                  st.gameOver = true;
                  setGameOver(true);
                  setHighScore(prev => Math.max(prev, st.score));
                }
              }
            }

            // Loop back hazard
            if (obj.position.z > 8) {
              obj.position.z = -90 - Math.random() * 20;
              obj.position.x = (Math.random() - 0.5) * 12;
              st.score += 15;
              setScore(st.score);
              if (st.score % 150 === 0) {
                soundManager.play('win');
                st.speed += 10;
                st.level++;
                setSpeed(st.speed);
                setLevel(st.level);
              }
            }
          } else {
            obj.rotation.y += 0.02;
          }
        });

        // Player mesh flashing during invincibility
        if (st.invincibleTimer > 0) {
          playerMesh.visible = Math.floor(st.frameCount / 4) % 2 === 0;
        } else {
          playerMesh.visible = true;
        }

        // Rotate player
        playerMesh.rotation.y += 0.01;

        // Camera follow
        camera.position.x = playerMesh.position.x * 0.5;
        camera.lookAt(playerMesh.position.x * 0.2, playerMesh.position.y, playerMesh.position.z - 5);
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [gameId, gameOver]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-2xl text-slate-100">
      {/* 3D Header Bar */}
      <div className="flex items-center justify-between w-full mb-3 bg-slate-950 px-4 py-2.5 rounded-xl border border-slate-800">
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-400">3D {category} Engine</div>
          <div className="text-sm font-black text-indigo-400">{gameTitle}</div>
        </div>

        {/* Lives / Hearts Display */}
        <div className="flex items-center gap-1 bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold mr-1">HP:</span>
          {Array.from({ length: 3 }).map((_, i) => (
            <Heart
              key={i}
              className={`w-3.5 h-3.5 transition-all ${
                i < hp ? 'text-rose-500 fill-rose-500 scale-100' : 'text-slate-700 opacity-40 scale-90'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-[10px] text-slate-400">Level</div>
            <div className="text-sm font-black text-cyan-400">LVL {level}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-slate-400">3D Score</div>
            <div className="text-base font-black text-amber-400">{score}</div>
          </div>
        </div>
      </div>

      {/* 3D Viewport */}
      <div className="relative w-full aspect-[16/9] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl">
        <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

        {/* Speedometer overlay */}
        <div className="absolute top-3 left-3 bg-slate-950/80 border border-slate-800 px-3 py-1 rounded-full text-[10px] font-mono text-cyan-300 flex items-center gap-1.5 backdrop-blur-sm">
          <Zap className="w-3 h-3 text-amber-400 animate-pulse" />
          <span>{speed} KM/H</span>
        </div>

        {/* 3D START MENU OVERLAY SCREEN */}
        {!gameStarted && (
          <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-between p-6 text-center z-30">
            <div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-[10px] font-bold uppercase rounded-full mb-3">
                <Sparkles className="w-3 h-3 text-amber-400" /> 3D Real-Time World
              </div>
              <h2 className="text-2xl font-black text-white tracking-tight mb-1">{gameTitle}</h2>
              <p className="text-xs text-slate-400 max-w-xs mx-auto">
                Steer through 3D obstacle hazards! Maintain 3 Hearts HP & high speeds!
              </p>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 p-3 rounded-xl w-full max-w-xs text-[11px] text-slate-300 space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Steering:</span>
                <span className="font-bold text-white">A / D or Left/Right</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Altitude / Thrust:</span>
                <span className="font-bold text-cyan-400">W / S</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Shield Protection:</span>
                <span className="font-bold text-emerald-400">3 HP Hearts + Spawn Invincibility</span>
              </div>
            </div>

            <button
              onClick={start3DGame}
              className="w-full max-w-xs py-3 bg-gradient-to-r from-indigo-600 to-cyan-600 hover:from-indigo-500 hover:to-cyan-500 text-white font-black rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" /> START 3D GAME NOW
            </button>
          </div>
        )}

        {/* GAME OVER SCREEN */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-30">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">3D Run Crash!</h3>
            <p className="text-xs text-slate-400 mb-4">Final Score: <strong className="text-amber-400">{score} pts</strong> • Level Reached: {level}</p>
            <div className="flex gap-3">
              <button
                onClick={reset3DGame}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-indigo-600/30 active:scale-95 transition-all"
              >
                <RefreshCw className="w-4 h-4" /> Restart 3D Challenge
              </button>
              <button
                onClick={() => setGameStarted(false)}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs active:scale-95 transition-all"
              >
                Menu Screen
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Touch / Keyboard Controls Bar */}
      <div className="flex items-center justify-between w-full mt-3 gap-2">
        <div className="flex items-center gap-1.5">
          <span className="text-[11px] text-slate-400 font-medium">Steer:</span>
          <button
            onMouseDown={() => { gameState.current.keys['a'] = true; }}
            onMouseUp={() => { gameState.current.keys['a'] = false; }}
            onTouchStart={() => { gameState.current.keys['a'] = true; }}
            onTouchEnd={() => { gameState.current.keys['a'] = false; }}
            className="w-10 h-10 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-700 flex items-center justify-center active:bg-indigo-600"
          >
            ←
          </button>
          <button
            onMouseDown={() => { gameState.current.keys['d'] = true; }}
            onMouseUp={() => { gameState.current.keys['d'] = false; }}
            onTouchStart={() => { gameState.current.keys['d'] = true; }}
            onTouchEnd={() => { gameState.current.keys['d'] = false; }}
            className="w-10 h-10 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl border border-slate-700 flex items-center justify-center active:bg-indigo-600"
          >
            →
          </button>
        </div>

        <div className="text-[11px] text-slate-400 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
          Keyboard: <strong className="text-slate-200">A / D or Left/Right</strong> to steer • <strong className="text-amber-300">W / S</strong> for altitude/thrust
        </div>
      </div>
    </div>
  );
};
