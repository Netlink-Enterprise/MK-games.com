import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { Shield, Sparkles, Trophy, RefreshCw, Heart, Zap, Flame, Crosshair } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

const MAP_SIZE = 9;

export const PixelDungeonEngine: React.FC<Props> = ({ mode }) => {
  const [player, setPlayer] = useState({ x: 1, y: 1, hp: 100, maxHp: 100, mp: 40, maxMp: 40, atk: 18, lvl: 1, xp: 0 });
  const [log, setLog] = useState<string[]>(['Welcome to Pixel Dungeon! Arrow keys/WASD to roam, fight monsters & cast magic!']);
  const [monsters, setMonsters] = useState([
    { id: 1, x: 3, y: 2, name: 'Goblin Scout', hp: 30, maxHp: 30, atk: 8, symbol: '👹' },
    { id: 2, x: 6, y: 5, name: 'Orc Warrior', hp: 55, maxHp: 55, atk: 14, symbol: '👺' },
    { id: 3, x: 7, y: 7, name: 'Shadow Dragon', hp: 100, maxHp: 100, atk: 22, symbol: '🐲' },
    { id: 4, x: 2, y: 7, name: 'Skeleton Archer', hp: 40, maxHp: 40, atk: 12, symbol: '💀' }
  ]);
  const [chests, setChests] = useState([
    { x: 4, y: 1, opened: false },
    { x: 2, y: 6, opened: false },
    { x: 8, y: 3, opened: false }
  ]);

  const addLog = (msg: string) => {
    setLog(prev => [msg, ...prev.slice(0, 4)]);
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (['arrowup', 'w'].includes(k)) { movePlayer(0, -1); e.preventDefault(); }
      else if (['arrowdown', 's'].includes(k)) { movePlayer(0, 1); e.preventDefault(); }
      else if (['arrowleft', 'a'].includes(k)) { movePlayer(-1, 0); e.preventDefault(); }
      else if (['arrowright', 'd'].includes(k)) { movePlayer(1, 0); e.preventDefault(); }
      else if (k === 'f') { castFireball(); e.preventDefault(); }
      else if (k === 'h') { castHeal(); e.preventDefault(); }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [player, monsters, chests]);

  // Monster AI turn logic: move closer to player if within range
  const updateMonsterPositions = (currentPx: number, currentPy: number, currentHp: number) => {
    setMonsters(prevMonsters => {
      let playerHurtDmg = 0;
      const updated = prevMonsters.map(m => {
        if (m.hp <= 0) return m;

        const dist = Math.abs(m.x - currentPx) + Math.abs(m.y - currentPy);
        if (dist === 1) {
          // Adjacent -> Attack player
          playerHurtDmg += m.atk;
          addLog(`💥 ${m.name} strikes you for ${m.atk} dmg!`);
          return m;
        } else if (dist <= 4) {
          // Chase player
          let dx = Math.sign(currentPx - m.x);
          let dy = Math.sign(currentPy - m.y);

          // Pick one axis to move
          let nx = m.x + (dx !== 0 ? dx : 0);
          let ny = m.y + (dx === 0 && dy !== 0 ? dy : 0);

          // Avoid stepping into player or other monsters
          if (nx === currentPx && ny === currentPy) return m;
          return { ...m, x: nx, y: ny };
        }
        return m;
      });

      if (playerHurtDmg > 0) {
        soundManager.play('move');
        setPlayer(p => ({ ...p, hp: Math.max(0, p.hp - playerHurtDmg) }));
      }

      return updated;
    });
  };

  const castFireball = () => {
    if (player.mp < 15 || player.hp <= 0) return;
    soundManager.play('laser');
    setPlayer(p => ({ ...p, mp: p.mp - 15 }));

    // Find closest monster
    let target = monsters.filter(m => m.hp > 0).sort((a, b) => {
      const dA = Math.hypot(a.x - player.x, a.y - player.y);
      const dB = Math.hypot(b.x - player.x, b.y - player.y);
      return dA - dB;
    })[0];

    if (target) {
      const dmg = 35 + Math.floor(Math.random() * 10);
      target.hp -= dmg;
      addLog(`🔥 FIREBALL hit ${target.name} for ${dmg} magic damage!`);
      if (target.hp <= 0) {
        soundManager.play('win');
        addLog(`🎉 Defeated ${target.name}! +50 XP`);
        gainXp(50);
      }
      setMonsters([...monsters]);
    } else {
      addLog(`🔥 Fireball exploded in empty hallway!`);
    }
  };

  const castHeal = () => {
    if (player.mp < 20 || player.hp <= 0) return;
    soundManager.play('score');
    setPlayer(p => ({ ...p, mp: p.mp - 20, hp: Math.min(p.maxHp, p.hp + 40) }));
    addLog(`✨ Cast Holy Heal! Restored 40 HP!`);
  };

  const gainXp = (amount: number) => {
    setPlayer(p => {
      const nextXp = p.xp + amount;
      if (nextXp >= 100) {
        addLog(`✨ LEVEL UP! Reached Level ${p.lvl + 1}! Max HP/MP increased!`);
        return { ...p, lvl: p.lvl + 1, hp: p.maxHp + 25, maxHp: p.maxHp + 25, mp: p.maxMp + 15, maxMp: p.maxMp + 15, atk: p.atk + 6, xp: 0 };
      }
      return { ...p, xp: nextXp };
    });
  };

  const movePlayer = (dx: number, dy: number) => {
    if (player.hp <= 0) return;

    const nx = player.x + dx;
    const ny = player.y + dy;

    if (nx < 0 || nx >= MAP_SIZE || ny < 0 || ny >= MAP_SIZE) return;

    // Check monster collision -> Melee Attack
    const targetMonster = monsters.find(m => m.x === nx && m.y === ny && m.hp > 0);
    if (targetMonster) {
      soundManager.play('score');
      const dmg = player.atk + Math.floor(Math.random() * 6);
      targetMonster.hp -= dmg;
      addLog(`⚔️ Slashed ${targetMonster.name} for ${dmg} damage!`);

      if (targetMonster.hp <= 0) {
        soundManager.play('win');
        addLog(`🎉 Defeated ${targetMonster.name}! +40 XP`);
        gainXp(40);
      }
      setMonsters([...monsters]);
      updateMonsterPositions(player.x, player.y, player.hp);
      return;
    }

    // Check chest
    const chest = chests.find(c => c.x === nx && c.y === ny && !c.opened);
    if (chest) {
      soundManager.play('win');
      chest.opened = true;
      setChests([...chests]);
      setPlayer(p => ({ ...p, hp: Math.min(p.maxHp, p.hp + 30), mp: Math.min(p.maxMp, p.mp + 20), atk: p.atk + 4 }));
      addLog(`🎁 Opened Chest! +30 HP, +20 MP, +4 Weapon ATK!`);
    }

    soundManager.play('click');
    setPlayer(p => ({ ...p, x: nx, y: ny, mp: Math.min(p.maxMp, p.mp + 1) }));
    updateMonsterPositions(nx, ny, player.hp);
  };

  const resetGame = () => {
    soundManager.play('click');
    setPlayer({ x: 1, y: 1, hp: 100, maxHp: 100, mp: 40, maxMp: 40, atk: 18, lvl: 1, xp: 0 });
    setMonsters([
      { id: 1, x: 3, y: 2, name: 'Goblin Scout', hp: 30, maxHp: 30, atk: 8, symbol: '👹' },
      { id: 2, x: 6, y: 5, name: 'Orc Warrior', hp: 55, maxHp: 55, atk: 14, symbol: '👺' },
      { id: 3, x: 7, y: 7, name: 'Shadow Dragon', hp: 100, maxHp: 100, atk: 22, symbol: '🐲' },
      { id: 4, x: 2, y: 7, name: 'Skeleton Archer', hp: 40, maxHp: 40, atk: 12, symbol: '💀' }
    ]);
    setChests([
      { x: 4, y: 1, opened: false },
      { x: 2, y: 6, opened: false },
      { x: 8, y: 3, opened: false }
    ]);
    setLog(['Dungeon reset! Explore and fight again.']);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold flex items-center gap-1">
            <Heart className="w-3.5 h-3.5 fill-current" /> HP: {player.hp} / {player.maxHp}
          </div>
          <div className="text-xs text-cyan-400 font-bold flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 fill-current" /> MP: {player.mp} / {player.maxMp}
          </div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">PIXEL DUNGEON RPG</div>
          <div className="text-xs font-bold text-slate-300">Level {player.lvl} (XP: {player.xp}/100)</div>
        </div>
        <button
          onClick={resetGame}
          className="p-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-slate-300 active:scale-95 transition-all"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* Grid Map */}
      <div className="grid grid-cols-9 gap-1 w-full aspect-square p-2 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-3">
        {Array.from({ length: MAP_SIZE * MAP_SIZE }).map((_, idx) => {
          const x = idx % MAP_SIZE;
          const y = Math.floor(idx / MAP_SIZE);

          const isPlayer = player.x === x && player.y === y;
          const monster = monsters.find(m => m.x === x && m.y === y && m.hp > 0);
          const chest = chests.find(c => c.x === x && c.y === y);

          return (
            <div
              key={idx}
              className={`flex items-center justify-center rounded-lg text-lg font-bold select-none transition-all ${
                isPlayer
                  ? 'bg-indigo-600/30 border border-indigo-400 shadow-lg'
                  : monster
                  ? 'bg-rose-950/40 border border-rose-800'
                  : 'bg-slate-900/90 border border-slate-800'
              }`}
            >
              {isPlayer ? (
                <span className="text-xl animate-bounce">🧙‍♂️</span>
              ) : monster ? (
                <span>{monster.symbol}</span>
              ) : chest ? (
                <span>{chest.opened ? '🧰' : '🎁'}</span>
              ) : (
                <span className="text-slate-800 text-xs">•</span>
              )}
            </div>
          );
        })}
      </div>

      {/* Spell & Action Buttons */}
      <div className="grid grid-cols-2 gap-2 w-full mb-3">
        <button
          onClick={castFireball}
          disabled={player.mp < 15 || player.hp <= 0}
          className="py-2.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <Flame className="w-4 h-4 fill-current" /> Fireball (15 MP)
        </button>
        <button
          onClick={castHeal}
          disabled={player.mp < 20 || player.hp <= 0}
          className="py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
        >
          <Sparkles className="w-4 h-4" /> Holy Heal (20 MP)
        </button>
      </div>

      {/* D-Pad Controls */}
      <div className="flex flex-col items-center gap-1 mb-3">
        <button
          onClick={() => movePlayer(0, -1)}
          className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
        >
          ▲ UP
        </button>
        <div className="flex gap-2">
          <button
            onClick={() => movePlayer(-1, 0)}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
          >
            ◀ LEFT
          </button>
          <button
            onClick={() => movePlayer(0, 1)}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
          >
            ▼ DOWN
          </button>
          <button
            onClick={() => movePlayer(1, 0)}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
          >
            RIGHT ▶
          </button>
        </div>
      </div>

      {/* Combat Log */}
      <div className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] font-mono space-y-1 h-20 overflow-y-auto">
        {log.map((line, idx) => (
          <div key={idx} className="text-slate-300">{line}</div>
        ))}
      </div>
    </div>
  );
};

