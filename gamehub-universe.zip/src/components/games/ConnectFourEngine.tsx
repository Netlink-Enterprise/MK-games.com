import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Trophy, User, Cpu, Users, Globe } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
  onlineData?: any;
  onSendMove?: (moveData: any) => void;
  playerNames?: { p1: string; p2: string };
}

const ROWS = 6;
const COLS = 7;

export const ConnectFourEngine: React.FC<Props> = ({
  mode,
  onlineData,
  onSendMove,
  playerNames = { p1: 'Player 1 (Red)', p2: 'Player 2 (Yellow)' }
}) => {
  const [board, setBoard] = useState<(number | null)[][]>(() => 
    Array(ROWS).fill(null).map(() => Array(COLS).fill(null))
  );
  const [currentPlayer, setCurrentPlayer] = useState<number>(1); // 1 = Red, 2 = Yellow
  const [winner, setWinner] = useState<number | null>(null); // 1 or 2 or 0 (draw)
  const [winningCells, setWinningCells] = useState<[number, number][]>([]);
  const [dropHoverCol, setDropHoverCol] = useState<number | null>(null);
  const [scores, setScores] = useState({ p1: 0, p2: 0 });

  // Sync online game state if mode is online
  useEffect(() => {
    if (mode === 'online' && onlineData?.gameState) {
      if (onlineData.gameState.board) {
        setBoard(onlineData.gameState.board);
      }
      if (onlineData.gameState.turnIndex !== undefined) {
        setCurrentPlayer(onlineData.gameState.turnIndex === 0 ? 1 : 2);
      }
      if (onlineData.gameState.winner !== undefined) {
        setWinner(onlineData.gameState.winner);
      }
    }
  }, [onlineData, mode]);

  // Handle Bot Turn in vs_bot mode
  useEffect(() => {
    if (mode === 'vs_bot' && currentPlayer === 2 && !winner) {
      const timer = setTimeout(() => {
        makeBotMove();
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, winner, mode, board]);

  const checkWin = (b: (number | null)[][]) => {
    // Horizontal, Vertical, Diagonal checks
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const val = b[r][c];
        if (!val) continue;

        // Horizontal (right)
        if (c + 3 < COLS && val === b[r][c+1] && val === b[r][c+2] && val === b[r][c+3]) {
          return { winner: val, cells: [[r,c], [r,c+1], [r,c+2], [r,c+3]] as [number, number][] };
        }
        // Vertical (down)
        if (r + 3 < ROWS && val === b[r+1][c] && val === b[r+2][c] && val === b[r+3][c]) {
          return { winner: val, cells: [[r,c], [r+1,c], [r+2,c], [r+3,c]] as [number, number][] };
        }
        // Diagonal Down-Right
        if (r + 3 < ROWS && c + 3 < COLS && val === b[r+1][c+1] && val === b[r+2][c+2] && val === b[r+3][c+3]) {
          return { winner: val, cells: [[r,c], [r+1,c+1], [r+2,c+2], [r+3,c+3]] as [number, number][] };
        }
        // Diagonal Down-Left
        if (r + 3 < ROWS && c - 3 >= 0 && val === b[r+1][c-1] && val === b[r+2][c-2] && val === b[r+3][c-3]) {
          return { winner: val, cells: [[r,c], [r+1,c-1], [r+2,c-2], [r+3,c-3]] as [number, number][] };
        }
      }
    }

    // Check Draw
    const isFull = b.every(row => row.every(cell => cell !== null));
    if (isFull) return { winner: 0, cells: [] };

    return null;
  };

  const handleColumnClick = (colIndex: number) => {
    if (winner) return;

    // In online mode, verify if it's player's turn
    if (mode === 'online') {
      const myTurnIndex = onlineData?.myPlayerIndex ?? 0; // 0 or 1
      const activeTurnIndex = currentPlayer - 1;
      if (myTurnIndex !== activeTurnIndex) return;
    }

    // Find lowest empty row in column
    let targetRow = -1;
    for (let r = ROWS - 1; r >= 0; r--) {
      if (board[r][colIndex] === null) {
        targetRow = r;
        break;
      }
    }

    if (targetRow === -1) return; // Column full

    soundManager.play('drop');

    const newBoard = board.map(row => [...row]);
    newBoard[targetRow][colIndex] = currentPlayer;
    setBoard(newBoard);

    const winResult = checkWin(newBoard);

    if (winResult) {
      setWinner(winResult.winner);
      setWinningCells(winResult.cells);
      if (winResult.winner === 1) {
        soundManager.play('win');
        setScores(prev => ({ ...prev, p1: prev.p1 + 1 }));
      } else if (winResult.winner === 2) {
        soundManager.play(mode === 'vs_bot' ? 'lose' : 'win');
        setScores(prev => ({ ...prev, p2: prev.p2 + 1 }));
      }
    } else {
      const nextP = currentPlayer === 1 ? 2 : 1;
      setCurrentPlayer(nextP);
    }

    if (mode === 'online' && onSendMove) {
      onSendMove({
        board: newBoard,
        turnNext: !winResult,
        winnerId: winResult ? (winResult.winner === 1 ? onlineData?.players[0]?.id : onlineData?.players[1]?.id) : null
      });
    }
  };

  const makeBotMove = () => {
    const validCols: number[] = [];
    for (let c = 0; c < COLS; c++) {
      if (board[0][c] === null) validCols.push(c);
    }
    if (validCols.length === 0) return;

    // 1. Check if bot can win immediately
    for (const c of validCols) {
      let r = -1;
      for (let row = ROWS - 1; row >= 0; row--) {
        if (board[row][c] === null) { r = row; break; }
      }
      const testB = board.map(row => [...row]);
      testB[r][c] = 2;
      if (checkWin(testB)?.winner === 2) {
        handleColumnClick(c);
        return;
      }
    }

    // 2. Check if bot needs to block Player 1
    for (const c of validCols) {
      let r = -1;
      for (let row = ROWS - 1; row >= 0; row--) {
        if (board[row][c] === null) { r = row; break; }
      }
      const testB = board.map(row => [...row]);
      testB[r][c] = 1;
      if (checkWin(testB)?.winner === 1) {
        handleColumnClick(c);
        return;
      }
    }

    // 3. Smart lookahead: Filter out columns that allow player to win immediately on top
    const safeCols = validCols.filter(c => {
      let r = -1;
      for (let row = ROWS - 1; row >= 0; row--) {
        if (board[row][c] === null) { r = row; break; }
      }
      const testB = board.map(row => [...row]);
      testB[r][c] = 2;

      // If there is still space above in column c, test if player wins if they play there
      if (r - 1 >= 0) {
        testB[r - 1][c] = 1;
        if (checkWin(testB)?.winner === 1) return false;
      }
      return true;
    });

    const candidateCols = safeCols.length > 0 ? safeCols : validCols;

    // Prefer center column (col 3) > adjacent (col 2, 4) > (col 1, 5) > (col 0, 6)
    const colWeights = [1, 3, 5, 8, 5, 3, 1];
    candidateCols.sort((a, b) => colWeights[b] - colWeights[a]);

    handleColumnClick(candidateCols[0]);
  };

  const resetGame = () => {
    soundManager.play('click');
    setBoard(Array(ROWS).fill(null).map(() => Array(COLS).fill(null)));
    setCurrentPlayer(1);
    setWinner(null);
    setWinningCells([]);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      {/* Header Status Bar */}
      <div className="flex items-center justify-between w-full mb-6 bg-slate-950 p-4 rounded-xl border border-slate-800">
        {/* Player 1 Card */}
        <div className={`flex items-center gap-3 px-3 py-2 rounded-lg border transition-all ${currentPlayer === 1 && !winner ? 'bg-red-500/20 border-red-500 shadow-lg shadow-red-500/20' : 'border-transparent'}`}>
          <div className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center text-white font-bold shadow-md">1</div>
          <div>
            <div className="text-xs text-slate-400 font-medium">{playerNames.p1}</div>
            <div className="text-lg font-black text-red-400">{scores.p1} Wins</div>
          </div>
        </div>

        <div className="text-center">
          <div className="text-xs font-bold uppercase tracking-widest text-slate-500 flex items-center justify-center gap-1">
            {mode === 'online' && <Globe className="w-3 h-3 text-cyan-400" />}
            {mode === 'vs_bot' && <Cpu className="w-3 h-3 text-purple-400" />}
            {mode === 'offline_pass_play' && <Users className="w-3 h-3 text-emerald-400" />}
            Connect Four
          </div>
          {winner ? (
            <div className="text-sm font-extrabold text-amber-400 animate-bounce mt-1">
              {winner === 0 ? 'Game Draw!' : winner === 1 ? `${playerNames.p1} Wins! 🎉` : `${playerNames.p2} Wins! 🎉`}
            </div>
          ) : (
            <div className="text-xs font-semibold text-slate-300 mt-1">
              Turn: <span className={currentPlayer === 1 ? 'text-red-400 font-bold' : 'text-yellow-400 font-bold'}>{currentPlayer === 1 ? 'Red' : 'Yellow'}</span>
            </div>
          )}
        </div>

        {/* Player 2 Card */}
        <div className={`flex items-center gap-3 px-3 py-2 rounded-lg border transition-all ${currentPlayer === 2 && !winner ? 'bg-yellow-500/20 border-yellow-500 shadow-lg shadow-yellow-500/20' : 'border-transparent'}`}>
          <div>
            <div className="text-xs text-slate-400 font-medium text-right">{mode === 'vs_bot' ? 'Gemini AI Bot' : playerNames.p2}</div>
            <div className="text-lg font-black text-yellow-400 text-right">{scores.p2} Wins</div>
          </div>
          <div className="w-8 h-8 rounded-full bg-yellow-400 flex items-center justify-center text-slate-900 font-bold shadow-md">2</div>
        </div>
      </div>

      {/* Interactive Drop Preview Row */}
      <div className="grid grid-cols-7 gap-2.5 w-full max-w-md px-4 mb-2">
        {Array(COLS).fill(null).map((_, cIndex) => (
          <div
            key={cIndex}
            className="h-8 flex items-center justify-center cursor-pointer"
            onMouseEnter={() => setDropHoverCol(cIndex)}
            onMouseLeave={() => setDropHoverCol(null)}
            onClick={() => handleColumnClick(cIndex)}
          >
            {dropHoverCol === cIndex && !winner && (
              <div className={`w-6 h-6 rounded-full transition-all duration-150 transform scale-110 shadow-md ${currentPlayer === 1 ? 'bg-red-500/80 shadow-red-500/50' : 'bg-yellow-400/80 shadow-yellow-400/50'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Main Connect 4 Board Grid */}
      <div className="bg-blue-700 p-4 rounded-2xl shadow-2xl border-4 border-blue-800 w-full max-w-md">
        <div className="grid grid-cols-7 gap-2.5">
          {board.map((row, rIdx) =>
            row.map((cell, cIdx) => {
              const isWinning = winningCells.some(([wr, wc]) => wr === rIdx && wc === cIdx);
              return (
                <button
                  key={`${rIdx}-${cIdx}`}
                  onClick={() => handleColumnClick(cIdx)}
                  onMouseEnter={() => setDropHoverCol(cIdx)}
                  className={`aspect-square rounded-full flex items-center justify-center transition-all duration-300 shadow-inner ${
                    cell === 1
                      ? 'bg-gradient-to-br from-red-400 to-red-600 shadow-red-900'
                      : cell === 2
                      ? 'bg-gradient-to-br from-yellow-300 to-yellow-500 shadow-yellow-900'
                      : 'bg-slate-950/80 border border-blue-600/40 hover:bg-slate-900/90'
                  } ${isWinning ? 'ring-4 ring-amber-300 animate-pulse scale-105' : ''}`}
                  disabled={!!winner}
                >
                  {cell !== null && (
                    <div className="w-3/4 h-3/4 rounded-full border border-white/20 shadow-inner" />
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4 mt-6">
        <button
          onClick={resetGame}
          className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg hover:shadow-cyan-500/10 active:scale-95 border border-slate-700"
        >
          <RefreshCw className="w-4 h-4 text-cyan-400" />
          Reset Board
        </button>
      </div>
    </div>
  );
};
