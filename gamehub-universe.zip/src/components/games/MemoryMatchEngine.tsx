import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Layers, Trophy } from 'lucide-react';

interface Props {
  mode: 'offline_pass_play' | 'vs_bot' | 'online';
}

const SYMBOLS = ['🎮', '⚡', '🔥', '🚀', '👑', '💎'];

export const MemoryMatchEngine: React.FC<Props> = ({ mode }) => {
  const [cards, setCards] = useState<{ id: number; symbol: string; flipped: boolean; matched: boolean }[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [moves, setMoves] = useState<number>(0);
  const [matches, setMatches] = useState<number>(0);

  useEffect(() => {
    initCards();
  }, []);

  const initCards = () => {
    const deck = [...SYMBOLS, ...SYMBOLS]
      .sort(() => Math.random() - 0.5)
      .map((symbol, idx) => ({ id: idx, symbol, flipped: false, matched: false }));
    setCards(deck);
    setFlippedIndices([]);
    setMoves(0);
    setMatches(0);
  };

  const handleCardClick = (index: number) => {
    if (cards[index].flipped || cards[index].matched || flippedIndices.length >= 2) return;

    soundManager.play('click');
    const newCards = [...cards];
    newCards[index].flipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMoves(prev => prev + 1);
      const [first, second] = newFlipped;
      if (cards[first].symbol === cards[second].symbol) {
        soundManager.play('score');
        setTimeout(() => {
          setCards(prev =>
            prev.map((c, i) => (i === first || i === second ? { ...c, matched: true } : c))
          );
          setMatches(m => {
            const nextM = m + 1;
            if (nextM === SYMBOLS.length) soundManager.play('win');
            return nextM;
          });
          setFlippedIndices([]);
        }, 300);
      } else {
        setTimeout(() => {
          setCards(prev =>
            prev.map((c, i) => (i === first || i === second ? { ...c, flipped: false } : c))
          );
          setFlippedIndices([]);
        }, 800);
      }
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-6 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-slate-400 font-bold">Total Moves</div>
          <div className="text-xl font-black text-cyan-400">{moves}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black uppercase text-slate-500">Memory Match</div>
          {matches === SYMBOLS.length ? (
            <div className="text-sm font-black text-amber-400 animate-bounce">All Matched! 🎉</div>
          ) : (
            <div className="text-xs font-bold text-slate-300">Pairs: {matches} / {SYMBOLS.length}</div>
          )}
        </div>
        <div>
          <div className="text-xs text-slate-400 font-bold">Accuracy</div>
          <div className="text-xl font-black text-purple-400">{moves > 0 ? `${Math.round((matches / moves) * 100)}%` : '100%'}</div>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-3 w-full aspect-square p-3 bg-slate-950 rounded-2xl border-2 border-slate-800 mb-6">
        {cards.map((card, idx) => (
          <button
            key={idx}
            onClick={() => handleCardClick(idx)}
            className={`flex items-center justify-center font-black text-3xl rounded-xl transition-all duration-200 shadow-md ${
              card.flipped || card.matched
                ? 'bg-indigo-600 text-white border-2 border-indigo-400 shadow-indigo-500/20'
                : 'bg-slate-900 hover:bg-slate-800 border border-slate-800 text-transparent'
            }`}
          >
            {card.flipped || card.matched ? card.symbol : '?'}
          </button>
        ))}
      </div>

      <button
        onClick={() => { soundManager.play('click'); initCards(); }}
        className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition-all shadow-lg active:scale-95"
      >
        <RefreshCw className="w-4 h-4 text-cyan-400" />
        Shuffle Deck
      </button>
    </div>
  );
};
