import React, { useState, useEffect } from 'react';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Heart, Zap, Sparkles, Shield, Flame, Compass, Home } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

const MAP_W = 7;
const MAP_H = 7;

export const PixelQuestEngine: React.FC<Props> = () => {
  const [inBattle, setInBattle] = useState<boolean>(false);
  const [player, setPlayer] = useState({ x: 3, y: 3, hp: 90, maxHp: 90, mp: 30, maxMp: 30, gold: 50, lvl: 1, xp: 0 });
  const [enemy, setEnemy] = useState({ name: 'Forest Slime', hp: 40, maxHp: 40, atk: 8, symbol: '👾' });
  const [log, setLog] = useState<string>('Use WASD or D-pad to walk around the Overworld Kingdom!');

  // Overworld tiles
  const [mapTiles] = useState(() => [
    ['🏰', '🌲', '🌲', '🌲', '🏔️', '🏔️', '🌋'],
    ['🌲', '🌿', '🌿', '🌉', '🌿', '🌲', '🌋'],
    ['🌲', '🌿', '🛖', '🌊', '🌿', '🌲', '🌋'],
    ['🌲', '🌉', '🌊', '🏰', '🌉', '🌲', '🌋'],
    ['🌲', '🌿', '🌿', '🌉', '🌿', '🌲', '🌋'],
    ['🌲', '🌲', '🛖', '🌿', '🌿', '🌲', '🌋'],
    ['🏰', '🌲', '🌲', '🌲', '🌋', '🌋', '👹']
  ]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (inBattle) return;
      const k = e.key.toLowerCase();
      if (['arrowup', 'w'].includes(k)) { moveHero(0, -1); e.preventDefault(); }
      else if (['arrowdown', 's'].includes(k)) { moveHero(0, 1); e.preventDefault(); }
      else if (['arrowleft', 'a'].includes(k)) { moveHero(-1, 0); e.preventDefault(); }
      else if (['arrowright', 'd'].includes(k)) { moveHero(1, 0); e.preventDefault(); }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [player, inBattle]);

  const moveHero = (dx: number, dy: number) => {
    if (inBattle) return;

    const nx = Math.max(0, Math.min(MAP_W - 1, player.x + dx));
    const ny = Math.max(0, Math.min(MAP_H - 1, player.y + dy));

    if (nx === player.x && ny === player.y) return;

    soundManager.play('click');
    setPlayer(p => ({ ...p, x: nx, y: ny }));

    const tile = mapTiles[ny][nx];

    // Village / Town visit -> Rest & Heal
    if (tile === '🛖' || tile === '🏰') {
      soundManager.play('win');
      setPlayer(p => ({ ...p, hp: p.maxHp, mp: p.maxMp }));
      setLog('🏰 Visited Kingdom Castle! HP & MP fully restored!');
      return;
    }

    // Random monster encounter chance in wilderness
    const chance = Math.random();
    if (chance < 0.35) {
      soundManager.play('score');
      if (tile === '🌋' || tile === '👹') {
        setEnemy({ name: 'Elder Archdemon', hp: 120, maxHp: 120, atk: 22, symbol: '👹' });
        setLog('🌋 A terrifying Archdemon ambushed you!');
      } else if (tile === '🌲') {
        setEnemy({ name: 'Forest Slime', hp: 40, maxHp: 40, atk: 8, symbol: '👾' });
        setLog('🌲 A wild Forest Slime jumped out from the trees!');
      } else {
        setEnemy({ name: 'Corrupted Knight', hp: 75, maxHp: 75, atk: 15, symbol: '🛡️' });
        setLog('🏰 Encountered a Rogue Corrupted Knight!');
      }
      setInBattle(true);
    } else {
      setLog(`Walked to ${tile} zone... clear for now.`);
    }
  };

  const handleAttack = () => {
    soundManager.play('click');
    const dmg = 15 + Math.floor(Math.random() * 8);
    const newEnemyHp = Math.max(0, enemy.hp - dmg);
    setEnemy(e => ({ ...e, hp: newEnemyHp }));

    if (newEnemyHp <= 0) {
      soundManager.play('win');
      setLog(`🎉 You defeated ${enemy.name}! +40 Gold & +50 XP!`);
      setPlayer(p => {
        const nextXp = p.xp + 50;
        const nextGold = p.gold + 40;
        if (nextXp >= 100) {
          return { ...p, gold: nextGold, lvl: p.lvl + 1, maxHp: p.maxHp + 20, hp: p.maxHp + 20, maxMp: p.maxMp + 10, mp: p.maxMp + 10, xp: 0 };
        }
        return { ...p, gold: nextGold, xp: nextXp };
      });
      setTimeout(() => {
        setInBattle(false);
      }, 1200);
      return;
    }

    // Enemy turn
    setTimeout(() => {
      soundManager.play('move');
      const eDmg = enemy.atk + Math.floor(Math.random() * 4);
      setPlayer(p => ({ ...p, hp: Math.max(0, p.hp - eDmg) }));
      setLog(`⚔️ Slashed for ${dmg} dmg! ${enemy.name} hit back for ${eDmg} dmg!`);
    }, 400);
  };

  const handleMagic = () => {
    if (player.mp < 10) return;
    soundManager.play('laser');
    const dmg = 32;
    setPlayer(p => ({ ...p, mp: p.mp - 10 }));
    const newEnemyHp = Math.max(0, enemy.hp - dmg);
    setEnemy(e => ({ ...e, hp: newEnemyHp }));

    if (newEnemyHp <= 0) {
      soundManager.play('win');
      setLog(`🔥 FIREBALL BLAST! Defeated ${enemy.name}! +50 XP!`);
      setTimeout(() => setInBattle(false), 1200);
      return;
    }

    setLog(`🔥 Cast Fireball for ${dmg} magic dmg!`);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-md mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-xs text-rose-400 font-bold">HP: {player.hp} / {player.maxHp}</div>
          <div className="text-xs text-cyan-400 font-bold">MP: {player.mp} / {player.maxMp}</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-amber-400 uppercase tracking-widest">RETRO QUEST OVERWORLD</div>
          <div className="text-xs font-bold text-slate-300">Level {player.lvl} Hero (XP: {player.xp}/100)</div>
        </div>
        <div>
          <div className="text-xs text-amber-400 font-bold">💰 {player.gold} Gold</div>
        </div>
      </div>

      {inBattle ? (
        <div className="w-full bg-slate-950 p-6 rounded-2xl border-2 border-indigo-500/40 text-center mb-4">
          <div className="text-6xl mb-4 animate-bounce">{enemy.symbol}</div>
          <div className="text-lg font-black text-white mb-2">{enemy.name}</div>

          {/* Enemy HP Bar */}
          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden mb-6 border border-slate-700">
            <div
              className="bg-rose-500 h-full transition-all duration-300"
              style={{ width: `${(enemy.hp / enemy.maxHp) * 100}%` }}
            />
          </div>

          <div className="grid grid-cols-2 gap-3 mb-2">
            <button
              onClick={handleAttack}
              className="py-3 bg-indigo-600 hover:bg-indigo-500 font-black rounded-xl text-xs active:scale-95 transition-all shadow-md"
            >
              ⚔️ SWORD ATTACK
            </button>
            <button
              onClick={handleMagic}
              disabled={player.mp < 10}
              className="py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 font-black rounded-xl text-xs active:scale-95 transition-all shadow-md"
            >
              🔥 FIREBALL (10 MP)
            </button>
          </div>
        </div>
      ) : (
        <div className="w-full bg-slate-950 p-3 rounded-2xl border-2 border-slate-800 mb-4 flex flex-col items-center">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
            <Compass className="w-3.5 h-3.5 text-amber-400" /> Overworld Realm Map
          </div>

          {/* Overworld Grid */}
          <div className="grid grid-cols-7 gap-1 w-full aspect-square bg-slate-900 p-2 rounded-xl border border-slate-800 mb-3">
            {mapTiles.map((row, r) =>
              row.map((tile, c) => {
                const isHero = player.x === c && player.y === r;
                return (
                  <div
                    key={`${r}-${c}`}
                    className={`flex items-center justify-center rounded-lg text-base font-bold transition-all ${
                      isHero
                        ? 'bg-indigo-600/40 border border-indigo-400 shadow-lg scale-105'
                        : 'bg-slate-950/80 border border-slate-800'
                    }`}
                  >
                    {isHero ? '🧙‍♂️' : tile}
                  </div>
                );
              })
            )}
          </div>

          {/* D-Pad Controls for Overworld Roaming */}
          <div className="flex flex-col items-center gap-1">
            <button
              onClick={() => moveHero(0, -1)}
              className="px-5 py-1.5 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
            >
              ▲ NORTH
            </button>
            <div className="flex gap-2">
              <button
                onClick={() => moveHero(-1, 0)}
                className="px-5 py-1.5 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
              >
                ◀ WEST
              </button>
              <button
                onClick={() => moveHero(0, 1)}
                className="px-5 py-1.5 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
              >
                ▼ SOUTH
              </button>
              <button
                onClick={() => moveHero(1, 0)}
                className="px-5 py-1.5 bg-slate-800 hover:bg-slate-700 font-bold rounded-xl text-xs active:scale-95 border border-slate-700"
              >
                EAST ▶
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="w-full bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs text-slate-300 font-mono text-center">
        {log}
      </div>
    </div>
  );
};

