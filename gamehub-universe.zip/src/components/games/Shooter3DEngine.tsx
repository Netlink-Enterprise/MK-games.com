import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { soundManager } from '../../lib/sound';
import { RefreshCw, Crosshair, Zap, Shield, Trophy } from 'lucide-react';

interface Props {
  mode?: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const Shooter3DEngine: React.FC<Props> = () => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [score, setScore] = useState<number>(0);
  const [health, setHealth] = useState<number>(100);
  const [ammo, setAmmo] = useState<number>(30);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [kills, setKills] = useState<number>(0);

  const gameState = useRef({
    score: 0,
    health: 100,
    ammo: 30,
    kills: 0,
    targets: [] as { mesh: THREE.Mesh; speedX: number; speedY: number; hp: number }[],
    lasers: [] as { mesh: THREE.Mesh; direction: THREE.Vector3; life: number }[]
  });

  const resetGame = () => {
    soundManager.play('click');
    gameState.current.score = 0;
    gameState.current.health = 100;
    gameState.current.ammo = 30;
    gameState.current.kills = 0;
    setScore(0);
    setHealth(100);
    setAmmo(30);
    setKills(0);
    setGameOver(false);
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a12);
    scene.fog = new THREE.FogExp2(0x0a0a12, 0.02);

    const camera = new THREE.PerspectiveCamera(75, container.clientWidth / container.clientHeight, 0.1, 1000);
    camera.position.set(0, 1.6, 5);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Lights
    const ambientLight = new THREE.AmbientLight(0x404060, 1.5);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x6366f1, 2);
    dirLight.position.set(5, 10, 7);
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0x38bdf8, 3, 20);
    pointLight.position.set(0, 2, 0);
    scene.add(pointLight);

    // Grid Floor
    const gridHelper = new THREE.GridHelper(40, 40, 0x6366f1, 0x1e1b4b);
    gridHelper.position.y = 0;
    scene.add(gridHelper);

    // Arena Pillars
    const pillarGeo = new THREE.BoxGeometry(1, 6, 1);
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.3, metalness: 0.8 });

    for (let x = -12; x <= 12; x += 6) {
      for (let z = -15; z <= 0; z += 5) {
        if (Math.abs(x) > 2) {
          const pillar = new THREE.Mesh(pillarGeo, pillarMat);
          pillar.position.set(x, 3, z);
          scene.add(pillar);
        }
      }
    }

    // Target Spawning
    const targetGeo = new THREE.IcosahedronGeometry(0.8, 1);
    const createTarget = () => {
      const targetMat = new THREE.MeshStandardMaterial({
        color: Math.random() > 0.5 ? 0xf43f5e : 0xf59e0b,
        emissive: 0x220011,
        roughness: 0.2
      });
      const mesh = new THREE.Mesh(targetGeo, targetMat);
      mesh.position.set(
        (Math.random() - 0.5) * 16,
        1 + Math.random() * 4,
        -5 - Math.random() * 12
      );
      scene.add(mesh);
      gameState.current.targets.push({
        mesh,
        speedX: (Math.random() - 0.5) * 0.04,
        speedY: (Math.random() - 0.5) * 0.03,
        hp: 2
      });
    };

    for (let i = 0; i < 6; i++) createTarget();

    // Laser firing
    const laserGeo = new THREE.CylinderGeometry(0.05, 0.05, 0.8);
    laserGeo.rotateX(Math.PI / 2);
    const laserMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });

    const shootLaser = () => {
      if (gameState.current.ammo <= 0 || gameState.current.health <= 0) {
        soundManager.play('move');
        return;
      }

      soundManager.play('click');
      gameState.current.ammo--;
      setAmmo(gameState.current.ammo);

      const laser = new THREE.Mesh(laserGeo, laserMat);
      laser.position.copy(camera.position);
      laser.position.y -= 0.2; // Weapon height

      const dir = new THREE.Vector3(0, 0, -1).unproject(camera).sub(camera.position).normalize();
      laser.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, -1), dir);

      scene.add(laser);
      gameState.current.lasers.push({ mesh: laser, direction: dir, life: 60 });
    };

    const handlePointerDown = () => {
      shootLaser();
    };

    container.addEventListener('pointerdown', handlePointerDown);

    // Animation Loop
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (gameState.current.health > 0) {
        // Move Targets
        gameState.current.targets.forEach((t, idx) => {
          t.mesh.position.x += t.speedX;
          t.mesh.position.y += t.speedY;
          t.mesh.rotation.x += 0.02;
          t.mesh.rotation.y += 0.03;

          // Bounce bounds
          if (Math.abs(t.mesh.position.x) > 9) t.speedX *= -1;
          if (t.mesh.position.y < 1 || t.mesh.position.y > 6) t.speedY *= -1;
        });

        // Move Lasers
        gameState.current.lasers.forEach((l, lIdx) => {
          l.mesh.position.addScaledVector(l.direction, 0.8);
          l.life--;

          // Check hit
          gameState.current.targets.forEach((t, tIdx) => {
            if (l.mesh.position.distanceTo(t.mesh.position) < 1.2) {
              soundManager.play('score');
              scene.remove(l.mesh);
              scene.remove(t.mesh);

              gameState.current.score += 20;
              gameState.current.kills++;
              gameState.current.ammo = Math.min(30, gameState.current.ammo + 5);
              setScore(gameState.current.score);
              setKills(gameState.current.kills);
              setAmmo(gameState.current.ammo);

              // Respawn
              gameState.current.targets.splice(tIdx, 1);
              createTarget();
            }
          });
        });

        // Clean up dead lasers
        gameState.current.lasers = gameState.current.lasers.filter(l => {
          if (l.life <= 0) {
            scene.remove(l.mesh);
            return false;
          }
          return true;
        });
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      container.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('resize', handleResize);
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div className="flex flex-col items-center justify-center p-4 w-full max-w-xl mx-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100">
      <div className="flex items-center justify-between w-full mb-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        <div>
          <div className="text-[10px] uppercase font-bold text-slate-400">Cyber Ammo</div>
          <div className="text-xl font-black text-cyan-400">{ammo} / 30</div>
        </div>
        <div className="text-center">
          <div className="text-xs font-black text-indigo-400 uppercase tracking-widest">DOOM 3D ARENA</div>
          <div className="text-xs font-bold text-slate-300">Drones Destroyed: {kills}</div>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase font-bold text-slate-400">Score</div>
          <div className="text-xl font-black text-amber-400">{score}</div>
        </div>
      </div>

      <div className="relative w-full aspect-[16/9] bg-black rounded-2xl border-2 border-indigo-500/40 overflow-hidden shadow-2xl mb-4 cursor-crosshair">
        <div ref={mountRef} className="w-full h-full" />

        {/* Center Crosshair Overlay */}
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
          <div className="w-6 h-6 border-2 border-cyan-400/80 rounded-full flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <div className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
          </div>
        </div>

        {gameOver && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            <Trophy className="w-12 h-12 text-amber-400 mb-2 animate-bounce" />
            <h3 className="text-2xl font-black text-white mb-1">Mission Completed!</h3>
            <p className="text-xs text-slate-400 mb-4">Final Score: {score} • Targets Eliminated: {kills}</p>
            <button
              onClick={resetGame}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-lg shadow-indigo-500/30 active:scale-95 transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Restart Arena
            </button>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between w-full text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
        <span>Click inside 3D Canvas to <strong className="text-cyan-300">Shoot Plasma Lasers</strong></span>
        <span>Destroy floating target cores to refill ammo!</span>
      </div>
    </div>
  );
};
