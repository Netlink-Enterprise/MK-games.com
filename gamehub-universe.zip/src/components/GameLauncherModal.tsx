import React, { useState } from 'react';
import { GameItem, OnlineRoomData } from '../types/game';
import { soundManager } from '../lib/sound';
import { ConnectFourEngine } from './games/ConnectFourEngine';
import { SnakeDuelEngine } from './games/SnakeDuelEngine';
import { PongEngine } from './games/PongEngine';
import { TicTacToeEngine } from './games/TicTacToeEngine';
import { DotsAndBoxesEngine } from './games/DotsAndBoxesEngine';
import { BattleshipEngine } from './games/BattleshipEngine';
import { TriviaRoyaleEngine } from './games/TriviaRoyaleEngine';
import { Shooter2DEngine } from './games/Shooter2DEngine';
import { Shooter3DEngine } from './games/Shooter3DEngine';
import { CarDriveEngine } from './games/CarDriveEngine';
import { PixelDungeonEngine } from './games/PixelDungeonEngine';
import { PixelQuestEngine } from './games/PixelQuestEngine';
import { PixelKnightEngine } from './games/PixelKnightEngine';
import { PixelTowerEngine } from './games/PixelTowerEngine';
import { BrickBreakerEngine } from './games/BrickBreakerEngine';
import { SpaceInvadersEngine } from './games/SpaceInvadersEngine';
import { PixelMinerEngine } from './games/PixelMinerEngine';
import { PixelAviatorEngine } from './games/PixelAviatorEngine';
import { PixelGhostMazeEngine } from './games/PixelGhostMazeEngine';
import { PixelCardBattlerEngine } from './games/PixelCardBattlerEngine';
import { CheckersEngine } from './games/CheckersEngine';
import { MemoryMatchEngine } from './games/MemoryMatchEngine';
import { TypeSpeedEngine } from './games/TypeSpeedEngine';
import { UniversalArcadeEngine } from './games/UniversalArcadeEngine';
import { Universal3DEngine } from './games/Universal3DEngine';
import { GameChatAndVoicePanel } from './GameChatAndVoicePanel';
import { X, Volume2, VolumeX, Sparkles, Users, Cpu, Globe, Trophy, Play, RotateCcw } from 'lucide-react';

interface Props {
  game: GameItem;
  onClose: () => void;
  onLaunchOnlineLobby: () => void;
  onlineRoomData?: OnlineRoomData | null;
  onlineSocket?: WebSocket | null;
}

export const GameLauncherModal: React.FC<Props> = ({
  game,
  onClose,
  onLaunchOnlineLobby,
  onlineRoomData,
  onlineSocket
}) => {
  const [playMode, setPlayMode] = useState<'offline_pass_play' | 'vs_bot' | 'online'>(
    onlineRoomData ? 'online' : 'offline_pass_play'
  );
  const [soundEnabled, setSoundEnabled] = useState(soundManager.isEnabled());
  const [aiTips, setAiTips] = useState<string | null>(null);
  const [loadingAiTips, setLoadingAiTips] = useState(false);

  // Procedural Fallback Engine state for non-flagship games
  const [proceduralScore, setProceduralScore] = useState({ p1: 0, p2: 0 });
  const [proceduralRound, setProceduralRound] = useState(1);
  const [proceduralActivePlayer, setProceduralActivePlayer] = useState<1 | 2>(1);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    soundManager.setEnabled(next);
  };

  const fetchStrategyTips = async () => {
    try {
      setLoadingAiTips(true);
      soundManager.play('click');
      const res = await fetch('/api/gemini/ai-game-master', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'game_strategy_tips',
          prompt: game.title
        })
      });
      const data = await res.json();
      if (data.tips) setAiTips(data.tips);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAiTips(false);
    }
  };

  const handleSendOnlineMove = (movePayload: any) => {
    if (onlineSocket && onlineSocket.readyState === WebSocket.OPEN) {
      onlineSocket.send(JSON.stringify({
        type: 'GAME_MOVE',
        payload: movePayload
      }));
    }
  };

  const handleProceduralAction = (scorePoints: number) => {
    soundManager.play('score');
    if (proceduralActivePlayer === 1) {
      setProceduralScore(prev => ({ ...prev, p1: prev.p1 + scorePoints }));
      if (playMode === 'vs_bot') {
        // Bot automatically takes turn after delay
        setProceduralActivePlayer(2);
        setTimeout(() => {
          soundManager.play('move');
          setProceduralScore(prev => ({ ...prev, p2: prev.p2 + Math.floor(Math.random() * 20) + 10 }));
          setProceduralActivePlayer(1);
          setProceduralRound(r => r + 1);
        }, 600);
      } else {
        setProceduralActivePlayer(2);
      }
    } else {
      setProceduralScore(prev => ({ ...prev, p2: prev.p2 + scorePoints }));
      setProceduralActivePlayer(1);
      setProceduralRound(r => r + 1);
    }
  };

  const renderGameEngine = () => {
    switch (game.builtInEngine) {
      case 'connect4':
        return <ConnectFourEngine mode={playMode} onlineData={onlineRoomData} onSendMove={handleSendOnlineMove} />;
      case 'snake':
        return <SnakeDuelEngine mode={playMode} onlineData={onlineRoomData} onSendMove={handleSendOnlineMove} />;
      case 'pong':
        return <PongEngine mode={playMode} onlineData={onlineRoomData} onSendMove={handleSendOnlineMove} />;
      case 'tictactoe':
        return <TicTacToeEngine mode={playMode} onlineData={onlineRoomData} onSendMove={handleSendOnlineMove} />;
      case 'dotsboxes':
        return <DotsAndBoxesEngine mode={playMode} />;
      case 'battleship':
        return <BattleshipEngine mode={playMode} />;
      case 'trivia':
        return <TriviaRoyaleEngine />;
      case 'shooter2d':
        return <Shooter2DEngine mode={playMode} />;
      case 'shooter3d':
        return <Shooter3DEngine mode={playMode} />;
      case 'cardrive3d':
        return <CarDriveEngine mode={playMode} />;
      case 'pixel_dungeon':
        return <PixelDungeonEngine mode={playMode} />;
      case 'pixel_quest':
        return <PixelQuestEngine mode={playMode} />;
      case 'pixel_knight':
        return <PixelKnightEngine mode={playMode} />;
      case 'pixel_tower':
        return <PixelTowerEngine mode={playMode} />;
      case 'brick_breaker':
        return <BrickBreakerEngine mode={playMode} />;
      case 'space_invaders':
        return <SpaceInvadersEngine mode={playMode} />;
      case 'pixel_miner':
        return <PixelMinerEngine mode={playMode} />;
      case 'pixel_bird':
        return <PixelAviatorEngine mode={playMode} />;
      case 'pixel_pac':
        return <PixelGhostMazeEngine mode={playMode} />;
      case 'pixel_cards':
        return <PixelCardBattlerEngine mode={playMode} />;
      case 'checkers':
        return <CheckersEngine mode={playMode} />;
      case 'memorymatch':
      case 'memory':
        return <MemoryMatchEngine mode={playMode} />;
      case 'speedtyping':
      case 'typing':
        return <TypeSpeedEngine mode={playMode} />;
      case 'cyber_3d_racer':
      case 'space_3d_dogfight':
      case 'dungeon_3d_crawler':
      case 'bowling_3d':
      case 'flight_3d_sim':
      case 'block_3d_craft':
      case 'parkour_3d_run':
      case 'mini_golf_3d':
      case 'hover_3d_arena':
      case 'roller_3d_coaster':
        return (
          <Universal3DEngine
            gameId={game.id}
            gameTitle={game.title}
            category={game.category}
            mode={playMode}
          />
        );
      default:
        // Universal Real Arcade Game Engine with Physics Canvas & Controls
        return (
          <UniversalArcadeEngine
            gameId={game.id}
            gameTitle={game.title}
            category={game.category}
            mode={playMode}
          />
        );
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-lg flex flex-col items-center justify-center p-4 overflow-y-auto">
      {/* Top Modal Navigation Header */}
      <div className="w-full max-w-5xl flex items-center justify-between mb-4 px-2">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${game.thumbnailGradient} flex items-center justify-center text-white font-bold shadow-lg`}>
            🎮
          </div>
          <div>
            <h2 className="text-xl font-black text-white">{game.title}</h2>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="px-2 py-0.5 bg-white/10 rounded font-semibold text-slate-300">{game.category}</span>
              <span>•</span>
              <span>★ {game.rating} ({game.playsCount.toLocaleString()} plays)</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className="p-2.5 bg-[#1a1a1e] hover:bg-[#222226] border border-white/10 text-slate-300 hover:text-white rounded-xl transition-colors"
            title={soundEnabled ? 'Mute Sound' : 'Enable Sound'}
          >
            {soundEnabled ? <Volume2 className="w-5 h-5 text-indigo-400" /> : <VolumeX className="w-5 h-5 text-slate-500" />}
          </button>

          {/* AI Strategy Tips Button */}
          <button
            onClick={fetchStrategyTips}
            disabled={loadingAiTips}
            className="flex items-center gap-2 px-3.5 py-2 bg-indigo-600/20 hover:bg-indigo-600/30 border border-indigo-500/40 text-indigo-300 rounded-xl text-xs font-bold transition-all active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-indigo-400" />
            {loadingAiTips ? 'Analyzing...' : 'AI Tips'}
          </button>

          {/* Close Modal */}
          <button
            onClick={onClose}
            className="p-2.5 bg-[#1a1a1e] hover:bg-rose-500/20 hover:text-rose-400 border border-white/10 text-slate-400 rounded-xl transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Mode Selector Header Bar */}
      <div className="w-full max-w-5xl bg-[#121214] border border-white/10 p-2 rounded-2xl mb-6 flex items-center justify-center gap-2">
        <button
          onClick={() => setPlayMode('offline_pass_play')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition-all ${
            playMode === 'offline_pass_play'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          Pass & Play (Local 2P)
        </button>

        <button
          onClick={() => setPlayMode('vs_bot')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition-all ${
            playMode === 'vs_bot'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Cpu className="w-4 h-4" />
          Vs Gemini AI Bot
        </button>

        <button
          onClick={() => {
            setPlayMode('online');
            onLaunchOnlineLobby();
          }}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold transition-all ${
            playMode === 'online'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Globe className="w-4 h-4" />
          Online Lobby
        </button>
      </div>

      {/* AI Strategy Tips Banner (if loaded) */}
      {aiTips && (
        <div className="w-full max-w-5xl bg-indigo-950/40 border border-indigo-500/30 p-4 rounded-2xl mb-6 text-xs text-indigo-200 leading-relaxed shadow-lg">
          <div className="flex items-center justify-between font-bold text-indigo-300 mb-1">
            <span className="flex items-center gap-1.5"><Sparkles className="w-4 h-4 text-amber-300" /> Gemini Pro AI Strategy Guide</span>
            <button onClick={() => setAiTips(null)} className="text-slate-400 hover:text-white">✕</button>
          </div>
          <p className="whitespace-pre-line">{aiTips}</p>
        </div>
      )}

      {/* Main Game Stage + Live Chat & Voice Panel */}
      <div className="w-full max-w-5xl flex flex-col md:flex-row items-stretch justify-center gap-6 min-h-[420px]">
        <div className="flex-1 flex items-center justify-center">
          {renderGameEngine()}
        </div>
        <GameChatAndVoicePanel gameTitle={game.title} playMode={playMode} />
      </div>
    </div>
  );
};
