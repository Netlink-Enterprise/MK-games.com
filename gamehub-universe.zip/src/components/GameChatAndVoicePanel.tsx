import React, { useState, useEffect, useRef } from 'react';
import { soundManager } from '../lib/sound';
import { Mic, MicOff, Volume2, VolumeX, Send, MessageSquare, Radio, Users, Sparkles, Smile, RadioReceiver } from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: string;
  avatar: string;
  text: string;
  time: string;
  isBot?: boolean;
  isSystem?: boolean;
}

interface Props {
  gameTitle: string;
  playMode: 'offline_pass_play' | 'vs_bot' | 'online';
}

export const GameChatAndVoicePanel: React.FC<Props> = ({ gameTitle, playMode }) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'voice'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'System',
      avatar: '🎮',
      text: `Connected to ${gameTitle} Match Room!`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isSystem: true
    },
    {
      id: '2',
      sender: playMode === 'vs_bot' ? 'Gemini AI Bot' : 'Player 2',
      avatar: playMode === 'vs_bot' ? '🤖' : '👤',
      text: playMode === 'vs_bot' ? 'Good luck! I analyzed 10,000 matches.' : 'Ready to play! GLHF!',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isBot: playMode === 'vs_bot'
    }
  ]);

  const [inputMsg, setInputMsg] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Voice chat states
  const [isMicOn, setIsMicOn] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [voiceVolume, setVoiceVolume] = useState(80);
  const [activeSpeakers, setActiveSpeakers] = useState<Record<string, boolean>>({
    'CyberPlayer (You)': false,
    [playMode === 'vs_bot' ? 'Gemini AI Bot' : 'Player 2']: false
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Auto scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Audio Visualizer canvas for Voice Chat
  useEffect(() => {
    if (!isMicOn || activeTab !== 'voice') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let step = 0;

    const drawVisualizer = () => {
      step += 0.08;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Background
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw sound wave frequencies
      const bars = 24;
      const barWidth = canvas.width / bars;

      for (let i = 0; i < bars; i++) {
        const height = Math.abs(Math.sin(step + i * 0.3)) * 35 + 8;
        const x = i * barWidth;
        const y = (canvas.height - height) / 2;

        const grad = ctx.createLinearGradient(0, y, 0, y + height);
        grad.addColorStop(0, '#818cf8');
        grad.addColorStop(1, '#f43f5e');

        ctx.fillStyle = grad;
        ctx.fillRect(x + 2, y, barWidth - 4, height);
      }

      animId = requestAnimationFrame(drawVisualizer);
    };

    drawVisualizer();
    return () => cancelAnimationFrame(animId);
  }, [isMicOn, activeTab]);

  const handleSendMessage = (textToSend?: string) => {
    const text = textToSend || inputMsg;
    if (!text.trim()) return;

    soundManager.play('click');
    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'CyberPlayer (You)',
      avatar: '🧙‍♂️',
      text: text.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputMsg('');

    // Simulate bot response if vs_bot
    if (playMode === 'vs_bot') {
      setTimeout(() => {
        soundManager.play('move');
        const botReplies = [
          'Nice move! Watch out for my counter strategy!',
          'Impressive combo! Let us see if you can sustain it.',
          'GG! Fun match so far!',
          'Haha, strategic mind detected!',
          'Calculating victory probabilities... 94%!'
        ];
        const randomReply = botReplies[Math.floor(Math.random() * botReplies.length)];

        // Speak aloud if sound enabled
        soundManager.speak(randomReply);

        setMessages(prev => [
          ...prev,
          {
            id: (Date.now() + 1).toString(),
            sender: 'Gemini AI Bot',
            avatar: '🤖',
            text: randomReply,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            isBot: true
          }
        ]);
      }, 900);
    }
  };

  const toggleMic = () => {
    soundManager.play('click');
    const next = !isMicOn;
    setIsMicOn(next);
    setActiveSpeakers(prev => ({ ...prev, 'CyberPlayer (You)': next }));
  };

  const toggleDeafen = () => {
    soundManager.play('click');
    setIsDeafened(!isDeafened);
  };

  return (
    <div className="w-80 bg-[#121215] border border-white/10 rounded-2xl flex flex-col h-[420px] shadow-2xl overflow-hidden shrink-0">
      {/* Header Tabs: Text Chat & Voice Chat */}
      <div className="flex items-center justify-between bg-[#18181c] border-b border-white/10 p-1.5">
        <button
          onClick={() => { soundManager.play('click'); setActiveTab('chat'); }}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'chat'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          Text Chat
        </button>

        <button
          onClick={() => { soundManager.play('click'); setActiveTab('voice'); }}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
            activeTab === 'voice'
              ? 'bg-rose-600 text-white shadow-md'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          Voice Chat
          {isMicOn && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />}
        </button>
      </div>

      {/* TEXT CHAT TAB */}
      {activeTab === 'chat' ? (
        <div className="flex-1 flex flex-col justify-between p-3 overflow-hidden">
          {/* Messages feed */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 mb-2 scrollbar-thin scrollbar-thumb-slate-800">
            {messages.map(m => (
              <div key={m.id} className={`flex items-start gap-2 text-xs ${m.isSystem ? 'justify-center' : ''}`}>
                {m.isSystem ? (
                  <div className="bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 px-2.5 py-1 rounded-full text-[10px] font-mono">
                    {m.text}
                  </div>
                ) : (
                  <>
                    <span className="text-base select-none">{m.avatar}</span>
                    <div className="flex-1 bg-[#1a1a20] border border-white/5 p-2 rounded-xl">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className={`font-bold text-[10px] ${m.isBot ? 'text-amber-400' : 'text-indigo-300'}`}>
                          {m.sender}
                        </span>
                        <span className="text-[9px] text-slate-500">{m.time}</span>
                      </div>
                      <p className="text-slate-200 text-xs leading-relaxed">{m.text}</p>
                    </div>
                  </>
                )}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Chat Reaction Pills */}
          <div className="flex items-center gap-1 mb-2 overflow-x-auto pb-1 scrollbar-none">
            {['🔥 GG!', '👍 Nice shot!', '😂 LOL', '🎯 Target down!', '🚀 Let\'s go!'].map((phrase, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(phrase)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-[10px] rounded-lg shrink-0 border border-slate-700 active:scale-95 transition-all"
              >
                {phrase}
              </button>
            ))}
          </div>

          {/* Message Input */}
          <div className="flex items-center gap-1.5 bg-[#18181c] border border-white/10 p-1.5 rounded-xl">
            <input
              type="text"
              value={inputMsg}
              onChange={e => setInputMsg(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type message or quick chat..."
              className="flex-1 bg-transparent text-xs text-white placeholder-slate-500 outline-none px-2"
            />
            <button
              onClick={() => handleSendMessage()}
              className="p-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg active:scale-95 transition-all"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        /* VOICE CHAT TAB */
        <div className="flex-1 flex flex-col justify-between p-4 bg-[#0d0d10] overflow-y-auto">
          <div>
            {/* Status Header */}
            <div className="flex items-center justify-between mb-3 bg-[#18181f] p-3 rounded-xl border border-white/5">
              <div className="flex items-center gap-2">
                <RadioReceiver className={`w-4 h-4 ${isMicOn ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
                <div>
                  <div className="text-xs font-bold text-white">Voice Room #4820</div>
                  <div className="text-[10px] text-slate-400">
                    {isMicOn ? 'Status: Transmitting Audio' : 'Status: Microphone Muted'}
                  </div>
                </div>
              </div>
              <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${isMicOn ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                {isMicOn ? 'LIVE' : 'IDLE'}
              </span>
            </div>

            {/* Audio Oscilloscope Visualizer Canvas */}
            <div className="w-full h-20 bg-slate-950 rounded-xl border border-slate-800 mb-4 overflow-hidden flex items-center justify-center relative">
              {isMicOn ? (
                <canvas ref={canvasRef} width={280} height={80} className="w-full h-full" />
              ) : (
                <div className="text-center text-xs text-slate-500">
                  🎙️ Turn on Microphone to start voice broadcast
                </div>
              )}
            </div>

            {/* Live Soundboard FX */}
            <div className="mb-3">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Soundboard Clips</span>
                <span className="text-amber-400 text-[9px]">Tap to Broadcast</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                <button
                  onClick={() => soundManager.play('airhorn')}
                  className="py-1.5 px-2 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 rounded-lg text-[10px] font-bold active:scale-95 transition-all text-center"
                >
                  🎺 Airhorn
                </button>
                <button
                  onClick={() => soundManager.play('win')}
                  className="py-1.5 px-2 bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300 rounded-lg text-[10px] font-bold active:scale-95 transition-all text-center"
                >
                  🎉 Fanfare
                </button>
                <button
                  onClick={() => soundManager.play('laser')}
                  className="py-1.5 px-2 bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 rounded-lg text-[10px] font-bold active:scale-95 transition-all text-center"
                >
                  ⚡ Laser
                </button>
                <button
                  onClick={() => soundManager.play('explosion')}
                  className="py-1.5 px-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 rounded-lg text-[10px] font-bold active:scale-95 transition-all text-center"
                >
                  💥 Boom
                </button>
              </div>
            </div>

            {/* Active Voice Participants */}
            <div className="space-y-2 mb-4">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Voice Lobby (2 Users)
              </div>

              <div className={`p-2.5 rounded-xl border flex items-center justify-between transition-all ${isMicOn ? 'bg-emerald-950/30 border-emerald-500/40' : 'bg-[#18181c] border-white/5'}`}>
                <div className="flex items-center gap-2.5">
                  <div className={`w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-xs text-white font-bold ${isMicOn ? 'ring-2 ring-emerald-400 ring-offset-2 ring-offset-slate-950' : ''}`}>
                    🧙‍♂️
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">CyberPlayer (You)</div>
                    <div className="text-[9px] text-slate-400">{isMicOn ? 'Speaking...' : 'Muted'}</div>
                  </div>
                </div>
                {isMicOn ? <Mic className="w-4 h-4 text-emerald-400 animate-pulse" /> : <MicOff className="w-4 h-4 text-slate-500" />}
              </div>

              <div className="p-2.5 rounded-xl bg-[#18181c] border border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-purple-600 flex items-center justify-center text-xs text-white font-bold">
                    {playMode === 'vs_bot' ? '🤖' : '👤'}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{playMode === 'vs_bot' ? 'Gemini AI Bot' : 'Player 2'}</div>
                    <div className="text-[9px] text-slate-400">Listening</div>
                  </div>
                </div>
                <Volume2 className="w-4 h-4 text-indigo-400" />
              </div>
            </div>
          </div>

          {/* Control Action Buttons */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={toggleMic}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md ${
                  isMicOn
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }`}
              >
                {isMicOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-rose-400" />}
                {isMicOn ? 'Mic On' : 'Unmute Mic'}
              </button>

              <button
                onClick={toggleDeafen}
                className={`py-2.5 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md ${
                  isDeafened
                    ? 'bg-rose-600 hover:bg-rose-500 text-white'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
                }`}
              >
                {isDeafened ? <VolumeX className="w-4 h-4 text-rose-200" /> : <Volume2 className="w-4 h-4" />}
                {isDeafened ? 'Deafened' : 'Audio On'}
              </button>
            </div>

            {/* Volume slider */}
            <div className="flex items-center gap-2 bg-[#18181c] p-2 rounded-xl border border-white/5">
              <Volume2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <input
                type="range"
                min={0}
                max={100}
                value={isDeafened ? 0 : voiceVolume}
                onChange={e => setVoiceVolume(Number(e.target.value))}
                className="w-full accent-indigo-500 h-1 bg-slate-800 rounded-lg cursor-pointer"
              />
              <span className="text-[10px] text-slate-400 font-mono w-6 text-right">{isDeafened ? '0%' : `${voiceVolume}%`}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
