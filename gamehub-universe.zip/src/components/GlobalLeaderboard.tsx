import React, { useState, useEffect } from 'react';
import { soundManager } from '../lib/sound';
import { Trophy, Medal, Sparkles, RefreshCw, Flame, Crown } from 'lucide-react';

export interface LeaderboardPlayer {
  id: string;
  name: string;
  avatar: string;
  xp: number;
  level: number;
  badge: string;
  isUser?: boolean;
}

interface Props {
  currentPlayerXp: number;
}

const DEFAULT_LEADERBOARD: LeaderboardPlayer[] = [
  { id: '1', name: 'VortexMaster', avatar: '👑', xp: 4850, level: 17, badge: 'Grandmaster' },
  { id: '2', name: 'ShadowNinja', avatar: '🥷', xp: 3920, level: 14, badge: 'Pro Duo' },
  { id: '3', name: 'CyberPlayer', avatar: '🧙‍♂️', xp: 2850, level: 10, badge: 'Rising Star', isUser: true },
  { id: '4', name: 'NovaQueen', avatar: '👸', xp: 2410, level: 9, badge: '3D Ace' },
  { id: '5', name: 'ApexLegend', avatar: '🦅', xp: 1980, level: 7, badge: 'Arcade Hero' },
  { id: '6', name: 'PixelKing', avatar: '👾', xp: 1650, level: 6, badge: 'Challenger' }
];

export const GlobalLeaderboard: React.FC<Props> = ({ currentPlayerXp }) => {
  const [players, setPlayers] = useState<LeaderboardPlayer[]>(() => {
    try {
      const stored = localStorage.getItem('gh_leaderboard');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Failed to parse leaderboard from localStorage', e);
    }
    return DEFAULT_LEADERBOARD;
  });

  // Sync current user's XP into the leaderboard
  useEffect(() => {
    setPlayers(prev => {
      const updated = prev.map(p => {
        if (p.isUser || p.name === 'CyberPlayer') {
          const userLevel = Math.floor(currentPlayerXp / 300) + 1;
          return {
            ...p,
            xp: currentPlayerXp,
            level: userLevel
          };
        }
        return p;
      });

      // Sort descending by XP
      updated.sort((a, b) => b.xp - a.xp);

      try {
        localStorage.setItem('gh_leaderboard', JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save leaderboard', err);
      }

      return updated;
    });
  }, [currentPlayerXp]);

  const refreshLeaderboard = () => {
    soundManager.play('click');
    setPlayers(prev => {
      const sorted = [...prev].sort((a, b) => b.xp - a.xp);
      return sorted;
    });
  };

  const top5 = players.slice(0, 5);

  const getRankBadge = (index: number) => {
    switch (index) {
      case 0:
        return <Crown className="w-4 h-4 text-amber-400 drop-shadow-md animate-bounce" />;
      case 1:
        return <Medal className="w-4 h-4 text-slate-300 drop-shadow-md" />;
      case 2:
        return <Medal className="w-4 h-4 text-amber-600 drop-shadow-md" />;
      default:
        return <span className="text-xs font-black text-slate-500 font-mono">#{index + 1}</span>;
    }
  };

  const getRankBg = (index: number, isUser?: boolean) => {
    if (isUser) return 'bg-amber-500/15 border-amber-500/40 ring-1 ring-amber-500/30';
    if (index === 0) return 'bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent border-amber-500/30';
    if (index === 1) return 'bg-gradient-to-r from-slate-400/10 via-slate-400/5 to-transparent border-slate-700';
    if (index === 2) return 'bg-gradient-to-r from-amber-700/10 via-amber-700/5 to-transparent border-amber-800/40';
    return 'bg-[#18181c] border-white/5 hover:border-white/10';
  };

  return (
    <div className="bg-[#121214] border border-white/5 rounded-2xl p-5 shadow-xl transition-all">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-amber-500/20 border border-amber-500/30 rounded-xl text-amber-400">
            <Trophy className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              Global Leaderboard
            </h3>
            <p className="text-[10px] text-slate-400">Top 5 Players by Total XP</p>
          </div>
        </div>

        <button
          onClick={refreshLeaderboard}
          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg transition-all active:scale-95"
          title="Refresh Standings"
        >
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Leaderboard List */}
      <div className="space-y-2">
        {top5.map((player, index) => (
          <div
            key={player.id}
            className={`flex items-center justify-between p-2.5 rounded-xl border transition-all ${getRankBg(index, player.isUser)}`}
          >
            <div className="flex items-center space-x-3 min-w-0">
              <div className="w-6 flex justify-center shrink-0">
                {getRankBadge(index)}
              </div>

              <div className="text-base select-none shrink-0">{player.avatar}</div>

              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className={`text-xs font-bold truncate ${player.isUser ? 'text-amber-300' : 'text-white'}`}>
                    {player.name}
                  </p>
                  {player.isUser && (
                    <span className="px-1.5 py-0.2 bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[9px] font-black rounded-full uppercase">
                      YOU
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
                  <span className="text-slate-400">Lvl {player.level}</span>
                  <span>•</span>
                  <span className="text-indigo-400 font-medium">{player.badge}</span>
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-xs font-black text-amber-400 font-mono">
                {player.xp.toLocaleString()} <span className="text-[9px] text-slate-500">XP</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Summary Bar */}
      <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-500">
        <span className="flex items-center gap-1">
          <Flame className="w-3 h-3 text-orange-400" /> Season 4 Active
        </span>
        <span className="text-indigo-400 font-bold hover:underline cursor-pointer" onClick={refreshLeaderboard}>
          Live Local Sync
        </span>
      </div>
    </div>
  );
};
