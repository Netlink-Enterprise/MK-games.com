import React, { useState, useMemo } from 'react';
import { GAMES_CATALOG } from './data/gamesCatalog';
import { GameItem, GameCategory, OnlineRoomData } from './types/game';
import { GameLauncherModal } from './components/GameLauncherModal';
import { OnlineLobbyModal } from './components/OnlineLobbyModal';
import { GlobalLeaderboard } from './components/GlobalLeaderboard';
import { soundManager } from './lib/sound';
import {
  Gamepad2,
  Search,
  Globe,
  Users,
  Sparkles,
  Trophy,
  Star,
  Zap,
  Grid,
  Filter,
  Play,
  Flame,
  MessageSquare,
  Shield,
  HelpCircle,
  TrendingUp,
  Cpu,
  Bookmark,
  Volume2,
  VolumeX,
  X
} from 'lucide-react';

export default function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedModeFilter, setSelectedModeFilter] = useState<'all' | 'online' | 'local' | 'favorites'>('all');
  const [activeNavTab, setActiveNavTab] = useState<'hub' | 'online' | 'local' | 'ai_quest' | 'profile'>('hub');
  
  // Selected Game for Modal
  const [activeGame, setActiveGame] = useState<GameItem | null>(null);
  const [onlineLobbyGame, setOnlineLobbyGame] = useState<GameItem | null>(null);
  
  // Active Online Match state
  const [activeRoomData, setActiveRoomData] = useState<OnlineRoomData | null>(null);
  const [activeSocket, setActiveSocket] = useState<WebSocket | null>(null);

  // Favorites
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('gh_favorites') || '["connect4", "snakeduel", "pongduel"]');
    } catch {
      return ["connect4", "snakeduel", "pongduel"];
    }
  });

  // Global Player XP State
  const [playerXp, setPlayerXp] = useState<number>(() => {
    try {
      return parseInt(localStorage.getItem('gh_player_xp') || '2850', 10);
    } catch {
      return 2850;
    }
  });

  const [claimedQuests, setClaimedQuests] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(localStorage.getItem('gh_claimed_quests') || '{}');
    } catch {
      return {};
    }
  });

  const addXp = (amount: number) => {
    soundManager.play('win');
    setPlayerXp(prev => {
      const next = prev + amount;
      localStorage.setItem('gh_player_xp', next.toString());
      return next;
    });
  };

  const claimQuest = (questId: string, xpReward: number) => {
    if (claimedQuests[questId]) return;
    const nextClaimed = { ...claimedQuests, [questId]: true };
    setClaimedQuests(nextClaimed);
    localStorage.setItem('gh_claimed_quests', JSON.stringify(nextClaimed));
    addXp(xpReward);
  };

  const currentLevel = Math.floor(playerXp / 300) + 1;
  const xpInLevel = playerXp % 300;

  // AI Game Master Prompt Modal State
  const [showAiQuestModal, setShowAiQuestModal] = useState(false);
  const [aiPromptInput, setAiPromptInput] = useState('');
  const [aiCustomGameData, setAiCustomGameData] = useState<any | null>(null);
  const [loadingAiQuest, setLoadingAiQuest] = useState(false);

  const toggleFavorite = (gameId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    soundManager.play('click');
    const updated = favorites.includes(gameId)
      ? favorites.filter(id => id !== gameId)
      : [...favorites, gameId];
    setFavorites(updated);
    localStorage.setItem('gh_favorites', JSON.stringify(updated));
  };

  // Filtered 100 Games Collection
  const filteredGames = useMemo(() => {
    return GAMES_CATALOG.filter(game => {
      // Search term filter
      const matchesSearch =
        game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        game.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      // Category filter
      const matchesCategory = selectedCategory === 'All' || game.category === selectedCategory;

      // Mode filter
      let matchesMode = true;
      if (selectedModeFilter === 'online') {
        matchesMode = game.modes.includes('online');
      } else if (selectedModeFilter === 'local') {
        matchesMode = game.modes.includes('offline');
      } else if (selectedModeFilter === 'favorites') {
        matchesMode = favorites.includes(game.id);
      }

      return matchesSearch && matchesCategory && matchesMode;
    });
  }, [searchQuery, selectedCategory, selectedModeFilter, favorites]);

  // Featured Game (Flagship)
  const featuredGame = GAMES_CATALOG[0]; // Connect Four Grand Prix

  const handleLaunchGame = (game: GameItem) => {
    soundManager.play('click');
    setActiveGame(game);
  };

  const handleStartOnlineGame = (room: OnlineRoomData, ws: WebSocket) => {
    setActiveRoomData(room);
    setActiveSocket(ws);

    // Find corresponding game in catalog
    const target = GAMES_CATALOG.find(g => g.id === room.gameId) || featuredGame;
    setOnlineLobbyGame(null);
    setActiveGame(target);
  };

  const handleGenerateAiQuest = async () => {
    try {
      setLoadingAiQuest(true);
      soundManager.play('click');
      const res = await fetch('/api/gemini/ai-game-master', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: aiPromptInput || 'Cyberpunk Ninja Hack Duel'
        })
      });
      const data = await res.json();
      if (data.gameData) {
        setAiCustomGameData(data.gameData);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAiQuest(false);
    }
  };

  return (
    <div className="flex h-screen w-screen bg-[#09090b] text-slate-200 font-sans overflow-hidden select-none">
      {/* 1. LEFT NAVIGATION RAIL (80px width) */}
      <nav className="w-20 bg-[#121214] border-r border-white/5 flex flex-col items-center py-6 space-y-8 z-20">
        {/* Brand Logo */}
        <div
          onClick={() => {
            soundManager.play('click');
            setActiveNavTab('hub');
            setSelectedModeFilter('all');
            setSelectedCategory('All');
          }}
          className="w-12 h-12 bg-gradient-to-tr from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 cursor-pointer hover:scale-105 transition-transform"
        >
          <span className="font-black text-2xl tracking-tighter text-white">GH</span>
        </div>

        {/* Nav Rail Buttons */}
        <div className="flex flex-col space-y-5">
          <button
            onClick={() => {
              soundManager.play('click');
              setActiveNavTab('hub');
              setSelectedModeFilter('all');
            }}
            title="All Games Catalog"
            className={`p-3 rounded-xl transition-all ${
              activeNavTab === 'hub' && selectedModeFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'hover:bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Gamepad2 className="w-6 h-6" />
          </button>

          <button
            onClick={() => {
              soundManager.play('click');
              setActiveNavTab('online');
              setSelectedModeFilter('online');
            }}
            title="Online Multiplayer Lobbies"
            className={`p-3 rounded-xl transition-all ${
              selectedModeFilter === 'online'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'hover:bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-6 h-6" />
          </button>

          <button
            onClick={() => {
              soundManager.play('click');
              setActiveNavTab('local');
              setSelectedModeFilter('local');
            }}
            title="Pass & Play / Local Co-op"
            className={`p-3 rounded-xl transition-all ${
              selectedModeFilter === 'local'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'hover:bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-6 h-6" />
          </button>

          <button
            onClick={() => {
              soundManager.play('click');
              setShowAiQuestModal(true);
            }}
            title="AI Game Master Studio"
            className="p-3 hover:bg-white/5 rounded-xl text-amber-400 transition-colors relative"
          >
            <Sparkles className="w-6 h-6 animate-pulse" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-amber-400" />
          </button>

          <button
            onClick={() => {
              soundManager.play('click');
              setSelectedModeFilter('favorites');
            }}
            title="Saved Favorite Games"
            className={`p-3 rounded-xl transition-all ${
              selectedModeFilter === 'favorites'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/30'
                : 'hover:bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            <Bookmark className="w-6 h-6" />
          </button>
        </div>

        {/* User Profile Avatar at bottom */}
        <div className="mt-auto mb-2">
          <div
            onClick={() => {
              soundManager.play('click');
              setActiveNavTab('profile');
            }}
            className={`w-11 h-11 rounded-xl border-2 p-0.5 flex items-center justify-center cursor-pointer transition-all ${
              activeNavTab === 'profile'
                ? 'border-amber-400 bg-amber-500/20 shadow-lg shadow-amber-500/20'
                : 'border-indigo-500/50 bg-[#18181b] hover:border-indigo-400'
            }`}
            title="User Profile & XP Hub"
          >
            <span className="font-bold text-xs text-amber-400">LV{currentLevel}</span>
          </div>
        </div>
      </nav>

      {/* MAIN LAYOUT WRAPPER */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* 2. TOP HEADER BAR */}
        <header className="h-20 px-8 flex items-center justify-between border-b border-white/5 bg-[#09090b]">
          {/* Search Bar Input */}
          <div className="relative flex-1 max-w-md">
            <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-slate-500 pointer-events-none">
              <Search className="h-4 h-4 text-slate-400" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="block w-full pl-10 pr-4 py-2 border border-white/10 rounded-xl bg-[#1a1a1e] text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Search 100+ titles (Connect 4, Snake, Pong...)"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Quick Filter Tabs & Store Button */}
          <div className="flex items-center space-x-6">
            <div className="flex space-x-5 text-sm font-semibold text-slate-400">
              <span
                onClick={() => {
                  soundManager.play('click');
                  setSelectedModeFilter('all');
                }}
                className={`cursor-pointer transition-colors pb-7 pt-7 border-b-2 ${
                  selectedModeFilter === 'all'
                    ? 'text-indigo-400 border-indigo-400 font-bold'
                    : 'border-transparent hover:text-white'
                }`}
              >
                All 100 Games
              </span>
              <span
                onClick={() => {
                  soundManager.play('click');
                  setSelectedModeFilter('online');
                }}
                className={`cursor-pointer transition-colors pb-7 pt-7 border-b-2 ${
                  selectedModeFilter === 'online'
                    ? 'text-indigo-400 border-indigo-400 font-bold'
                    : 'border-transparent hover:text-white'
                }`}
              >
                Online
              </span>
              <span
                onClick={() => {
                  soundManager.play('click');
                  setSelectedModeFilter('local');
                }}
                className={`cursor-pointer transition-colors pb-7 pt-7 border-b-2 ${
                  selectedModeFilter === 'local'
                    ? 'text-indigo-400 border-indigo-400 font-bold'
                    : 'border-transparent hover:text-white'
                }`}
              >
                Local Co-op
              </span>
            </div>

            <div className="h-6 w-px bg-white/10 mx-2" />

            <button
              onClick={() => {
                soundManager.play('click');
                setShowAiQuestModal(true);
              }}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-bold hover:bg-indigo-500 shadow-md shadow-indigo-600/20 active:scale-95 transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              AI Game Master
            </button>
          </div>
        </header>

        {/* Category Pill Filter Carousel */}
        <div className="px-8 py-3 bg-[#0e0e11] border-b border-white/5 flex items-center gap-2 overflow-x-auto no-scrollbar">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Category:
          </span>
          {['All', 'Action', 'RPG', 'Board', 'Arcade', 'Puzzle', 'Card', 'Party', 'Strategy', 'Sports', 'Retro', 'Casual'].map(cat => (
            <button
              key={cat}
              onClick={() => {
                soundManager.play('click');
                setSelectedCategory(cat);
              }}
              className={`px-3.5 py-1 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-white text-slate-950 shadow-md'
                  : 'bg-[#18181b] hover:bg-[#222226] text-slate-400 hover:text-white border border-white/5'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* CONTENT AREA: 12-Column Grid or Profile Hub */}
        {activeNavTab === 'profile' ? (
          <div className="flex-1 p-8 overflow-y-auto space-y-8 max-w-6xl mx-auto w-full">
            {/* Profile Header Banner */}
            <div className="bg-gradient-to-r from-indigo-950 via-purple-950 to-slate-900 border border-indigo-500/30 rounded-3xl p-8 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-6 z-10">
                <div className="w-20 h-20 rounded-2xl bg-indigo-600 border-2 border-amber-400 flex items-center justify-center font-black text-white text-3xl shadow-xl shadow-indigo-600/30">
                  LV{currentLevel}
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-2xl font-black text-white">CyberPlayer</h2>
                    <span className="px-3 py-0.5 bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-xs rounded-full">
                      Grandmaster Arcade Hero
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mb-3">Level {currentLevel} • Total Score: {playerXp.toLocaleString()} XP</p>
                  
                  {/* XP Bar */}
                  <div className="w-64 md:w-80 bg-slate-900 h-3 rounded-full overflow-hidden border border-slate-700">
                    <div
                      className="bg-gradient-to-r from-amber-500 to-indigo-500 h-full rounded-full transition-all duration-500"
                      style={{ width: `${(xpInLevel / 300) * 100}%` }}
                    />
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {xpInLevel} / 300 XP in Level {currentLevel} ({300 - xpInLevel} XP to Level {currentLevel + 1})
                  </div>
                </div>
              </div>

              {/* Instant Daily Checkin Bonus */}
              <div className="z-10 bg-slate-950/80 border border-amber-500/30 p-4 rounded-2xl flex flex-col items-center text-center">
                <Sparkles className="w-8 h-8 text-amber-400 mb-1 animate-bounce" />
                <div className="text-xs font-bold text-white mb-2">Daily Login XP Multiplier</div>
                <button
                  onClick={() => addXp(150)}
                  className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl shadow-lg active:scale-95 transition-all flex items-center gap-1.5"
                >
                  <Trophy className="w-4 h-4 fill-current" /> Claim +150 Bonus XP
                </button>
              </div>
            </div>

            {/* Quests & Achievements Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Daily Quests Box */}
              <div className="bg-[#121214] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-amber-400" /> Arcade Quests
                  </h3>
                  <span className="text-xs font-mono text-indigo-400">Earn Level XP</span>
                </div>

                <div className="space-y-3">
                  {[
                    { id: 'q1', title: 'Drive 500m in Highway Turbo', desc: 'Play 3D Car Racing game & avoid crashes', reward: 200, icon: '🚗' },
                    { id: 'q2', title: 'Slay 3 Monsters in Pixel Dungeon', desc: 'Explore RPG dungeon rooms and defeat enemies', reward: 250, icon: '⚔️' },
                    { id: 'q3', title: 'Slash Goblins in Pixel Knight', desc: 'Complete Stage 1 of the Indie Platformer', reward: 200, icon: '🛡️' },
                    { id: 'q4', title: 'Win a Match in Tic-Tac-Toe', desc: 'Outsmart the AI bot or local player', reward: 150, icon: '❌' }
                  ].map(q => {
                    const isClaimed = !!claimedQuests[q.id];
                    return (
                      <div key={q.id} className="bg-[#18181c] border border-white/5 rounded-xl p-3.5 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{q.icon}</span>
                          <div>
                            <h4 className="text-xs font-bold text-white">{q.title}</h4>
                            <p className="text-[10px] text-slate-400">{q.desc}</p>
                          </div>
                        </div>
                        <button
                          onClick={() => claimQuest(q.id, q.reward)}
                          disabled={isClaimed}
                          className={`px-3 py-1.5 font-bold text-xs rounded-xl transition-all ${
                            isClaimed
                              ? 'bg-slate-800 text-slate-500 border border-slate-700'
                              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md active:scale-95'
                          }`}
                        >
                          {isClaimed ? 'Claimed ✓' : `Claim +${q.reward} XP`}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Trophies & Badges Box */}
              <div className="bg-[#121214] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" /> Trophies & Badges
                  </h3>
                  <span className="text-xs font-mono text-slate-400">Unlocks at higher levels</span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#18181c] border border-amber-500/30 p-3.5 rounded-xl flex items-center gap-3">
                    <span className="text-3xl">🏆</span>
                    <div>
                      <div className="text-xs font-bold text-amber-300">Retro Champion</div>
                      <div className="text-[10px] text-slate-400">Unlocked Level 5</div>
                    </div>
                  </div>
                  <div className="bg-[#18181c] border border-indigo-500/30 p-3.5 rounded-xl flex items-center gap-3">
                    <span className="text-3xl">🏎️</span>
                    <div>
                      <div className="text-xs font-bold text-indigo-300">Highway Speedster</div>
                      <div className="text-[10px] text-slate-400">Unlocked Level 7</div>
                    </div>
                  </div>
                  <div className="bg-[#18181c] border border-emerald-500/30 p-3.5 rounded-xl flex items-center gap-3">
                    <span className="text-3xl">🧙‍♂️</span>
                    <div>
                      <div className="text-xs font-bold text-emerald-300">Dungeon Master</div>
                      <div className="text-[10px] text-slate-400">Unlocked Level 8</div>
                    </div>
                  </div>
                  <div className="bg-[#18181c] border border-rose-500/30 p-3.5 rounded-xl flex items-center gap-3">
                    <span className="text-3xl">👑</span>
                    <div>
                      <div className="text-xs font-bold text-rose-300">GameHub Legend</div>
                      <div className="text-[10px] text-slate-400">Unlocked Level 10</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 p-8 grid grid-cols-12 gap-8 overflow-y-auto">
            {/* LEFT 8 COLUMNS: FEATURED HERO & GAMES GRID */}
            <div className="col-span-8 flex flex-col space-y-8">
            {/* Featured Hero Game Banner */}
            {!searchQuery && selectedCategory === 'All' && selectedModeFilter === 'all' && (
              <div className="relative h-64 bg-slate-800 rounded-3xl overflow-hidden group shadow-2xl border border-white/10">
                <div className="absolute inset-0 bg-gradient-to-r from-black/95 via-black/70 to-transparent z-10" />
                <img
                  src={featuredGame.thumbnailUrl || 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1200&q=80'}
                  alt={featuredGame.title}
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500 opacity-60"
                />

                <div className="relative z-20 h-full p-8 flex flex-col justify-center max-w-lg">
                  <span className="bg-indigo-500 text-white text-[10px] font-black px-2.5 py-1 rounded-md w-fit mb-3 uppercase tracking-widest shadow-md">
                    Featured Flagship
                  </span>
                  <h2 className="text-3xl font-black text-white mb-2 tracking-tight">
                    {featuredGame.title}
                  </h2>
                  <p className="text-slate-300 text-xs mb-6 leading-relaxed line-clamp-2">
                    {featuredGame.description}
                  </p>
                  <div className="flex space-x-3">
                    <button
                      onClick={() => handleLaunchGame(featuredGame)}
                      className="px-6 py-2.5 bg-white text-black font-black text-xs rounded-xl hover:bg-slate-200 active:scale-95 transition-all shadow-lg flex items-center gap-2"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      Play Pass & Play
                    </button>
                    <button
                      onClick={() => setOnlineLobbyGame(featuredGame)}
                      className="px-5 py-2.5 bg-white/10 backdrop-blur text-white font-bold text-xs rounded-xl border border-white/20 hover:bg-white/20 active:scale-95 transition-all flex items-center gap-2"
                    >
                      <Globe className="w-4 h-4 text-emerald-400" />
                      Host Online
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Games Grid Header */}
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <Gamepad2 className="w-5 h-5 text-indigo-400" />
                  {selectedModeFilter === 'favorites' ? 'Your Favorite Games' : `${selectedCategory} Collection`}
                </h3>
                <p className="text-xs text-slate-400">
                  Showing {filteredGames.length} of {GAMES_CATALOG.length} playable games
                </p>
              </div>

              {filteredGames.length === 0 && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedModeFilter('all');
                  }}
                  className="text-xs text-indigo-400 font-bold hover:underline"
                >
                  Clear Filters
                </button>
              )}
            </div>

            {/* 4-Column Game Cards Grid */}
            <div className="grid grid-cols-4 gap-4">
              {filteredGames.map(game => {
                const isFav = favorites.includes(game.id);
                return (
                  <div
                    key={game.id}
                    onClick={() => handleLaunchGame(game)}
                    className="group bg-[#121214] hover:bg-[#18181c] border border-white/5 hover:border-indigo-500/40 rounded-2xl p-3 flex flex-col justify-between cursor-pointer transition-all hover:-translate-y-1 shadow-lg hover:shadow-indigo-500/10 relative overflow-hidden"
                  >
                    {/* Thumbnail box */}
                    <div className={`aspect-square w-full rounded-xl bg-gradient-to-br ${game.thumbnailGradient} p-3 flex flex-col justify-between relative overflow-hidden border border-white/10 mb-3`}>
                      {game.thumbnailUrl && (
                        <img
                          src={game.thumbnailUrl}
                          alt={game.title}
                          referrerPolicy="no-referrer"
                          className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:opacity-85 group-hover:scale-110 transition-all duration-300"
                        />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/40 z-0 pointer-events-none" />

                      <div className="flex justify-between items-start z-10">
                        <span className="text-[10px] font-black uppercase tracking-wider bg-black/60 backdrop-blur-sm px-2 py-0.5 rounded text-white border border-white/10">
                          {game.category}
                        </span>
                        <button
                          onClick={e => toggleFavorite(game.id, e)}
                          className="p-1 rounded-lg bg-black/60 backdrop-blur-sm hover:bg-black/90 transition-colors"
                        >
                          <Bookmark className={`w-3.5 h-3.5 ${isFav ? 'text-amber-400 fill-amber-400' : 'text-slate-400'}`} />
                        </button>
                      </div>

                      <div className="z-10 flex items-center justify-between text-white">
                        <span className="text-2xl drop-shadow-md">🎮</span>
                        {game.builtInEngine && (
                          <span className="text-[9px] font-black bg-indigo-500/90 backdrop-blur text-white px-1.5 py-0.5 rounded uppercase border border-indigo-400/30 shadow-md">
                            HD Engine
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Meta information */}
                    <div>
                      <h4 className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors truncate mb-1">
                        {game.title}
                      </h4>
                      <p className="text-[10px] text-slate-500 flex items-center justify-between">
                        <span>{game.playersMin === game.playersMax ? `${game.playersMin} Player` : `${game.playersMin}-${game.playersMax} Players`}</span>
                        <span className="text-amber-400 font-bold">★ {game.rating}</span>
                      </p>
                    </div>

                    {/* Quick Online / Pass Play launch buttons on hover */}
                    <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-between">
                      <span className="text-[9px] text-slate-400 uppercase font-mono">
                        {game.modes.includes('online') ? 'Online & Offline' : 'Offline'}
                      </span>
                      <button
                        onClick={e => {
                          e.stopPropagation();
                          setOnlineLobbyGame(game);
                        }}
                        className="p-1 bg-white/5 hover:bg-indigo-600 hover:text-white rounded text-slate-400 text-[10px] font-bold transition-all"
                        title="Host Online Lobby"
                      >
                        <Globe className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* RIGHT 4 COLUMNS: FRIENDS, ACTIVE ROOMS & HUB NEWS */}
          <div className="col-span-4 flex flex-col space-y-6">
            {/* Active Friends & Online Rooms Card */}
            <div className="bg-[#121214] border border-white/5 rounded-2xl p-6 shadow-xl">
              <h3 className="text-sm font-bold text-white mb-4 flex items-center justify-between">
                <span className="flex items-center">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse" />
                  Active Friends (12)
                </span>
                <span className="text-[10px] text-slate-500 font-mono">SERVER: ONLINE</span>
              </h3>

              <div className="space-y-3.5">
                <div className="flex items-center space-x-3 p-2 hover:bg-white/5 rounded-xl transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center font-bold text-indigo-400 text-xs">
                    JD
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">Jax_Dagger</p>
                    <p className="text-[10px] text-indigo-400 font-medium truncate">Playing Connect Four Grand Prix</p>
                  </div>
                  <button
                    onClick={() => handleLaunchGame(GAMES_CATALOG[0])}
                    className="p-1.5 bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600 hover:text-white rounded-lg text-xs"
                    title="Spectate / Join"
                  >
                    <Play className="w-3 h-3" />
                  </button>
                </div>

                <div className="flex items-center space-x-3 p-2 hover:bg-white/5 rounded-xl transition-colors">
                  <div className="w-9 h-9 rounded-lg bg-pink-500/20 border border-pink-500/30 flex items-center justify-center font-bold text-pink-400 text-xs">
                    SL
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">Sora_Luna</p>
                    <p className="text-[10px] text-emerald-400 font-medium truncate">Online • In Lobby</p>
                  </div>
                  <button
                    onClick={() => setOnlineLobbyGame(GAMES_CATALOG[1])}
                    className="p-1.5 bg-white/5 text-slate-400 hover:text-white rounded-lg text-xs"
                    title="Invite to Game"
                  >
                    <MessageSquare className="w-3 h-3" />
                  </button>
                </div>

                <div className="flex items-center space-x-3 p-2 opacity-50">
                  <div className="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-slate-400 text-xs">
                    MX
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-white truncate">Maximus</p>
                    <p className="text-[10px] text-slate-500 truncate">Offline • 2h ago</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Global Leaderboard Card */}
            <GlobalLeaderboard currentPlayerXp={playerXp} />

            {/* Hub News & System Update */}
            <div className="bg-gradient-to-br from-indigo-950/40 to-purple-950/30 border border-indigo-500/20 rounded-2xl p-6 shadow-xl">
              <h3 className="text-xs font-black text-indigo-300 mb-2 uppercase tracking-wide flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" /> GameHub v2.4 Release
              </h3>
              <p className="text-xs text-white font-bold mb-1">100 Games Multi-Engine Installed</p>
              <p className="text-[11px] text-slate-400 mb-4 leading-relaxed">
                Connect Four, Snake Duel, Air Hockey, Tic-Tac-Toe, Battleship & AI Quiz Show ready for online & offline pass and play.
              </p>
              <div className="w-full bg-indigo-950 h-1.5 rounded-full overflow-hidden border border-indigo-500/20">
                <div className="w-full h-full bg-gradient-to-r from-indigo-500 to-purple-500" />
              </div>
              <div className="flex justify-between mt-2">
                <span className="text-[9px] text-slate-500">Local Assets & Engines</span>
                <span className="text-[9px] text-indigo-400 font-bold">100% Ready</span>
              </div>
            </div>

            {/* Player Profile XP Progress Box */}
            <div
              onClick={() => {
                soundManager.play('click');
                setActiveNavTab('profile');
              }}
              className="bg-[#121214] border border-white/5 hover:border-amber-500/40 rounded-2xl p-6 cursor-pointer transition-all"
            >
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h4 className="text-xs font-bold text-white">CyberPlayer</h4>
                  <p className="text-[10px] text-slate-400">Gamer Level {currentLevel}</p>
                </div>
                <span className="text-xs font-black text-amber-400">{playerXp.toLocaleString()} XP</span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden mb-2">
                <div className="h-full bg-amber-400 rounded-full transition-all duration-300" style={{ width: `${(xpInLevel / 300) * 100}%` }} />
              </div>
              <p className="text-[9px] text-slate-500 text-right">{300 - xpInLevel} XP to Level {currentLevel + 1}</p>
            </div>
          </div>
        </div>
      )}

        {/* 3. FOOTER STATS BAR */}
        <footer className="h-12 px-8 bg-[#121214] border-t border-white/5 flex items-center justify-between text-[10px] text-slate-500 z-20">
          <div className="flex space-x-6">
            <span className="flex items-center uppercase tracking-tighter">
              <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full mr-2" />
              100 Games Ready
            </span>
            <span className="flex items-center uppercase tracking-tighter">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2" />
              4,821 Players Online
            </span>
          </div>
          <div className="flex space-x-4 items-center">
            <span>Server Latency: <strong className="text-emerald-400">18ms</strong></span>
            <span>System Status: <strong className="text-white">Optimal</strong></span>
            <div className="w-20 h-1 bg-slate-800 rounded-full overflow-hidden">
              <div className="w-full h-full bg-emerald-500/70" />
            </div>
          </div>
        </footer>
      </main>

      {/* MODALS */}
      {/* 1. Game Launcher Modal */}
      {activeGame && (
        <GameLauncherModal
          game={activeGame}
          onClose={() => {
            setActiveGame(null);
            setActiveRoomData(null);
          }}
          onLaunchOnlineLobby={() => {
            setOnlineLobbyGame(activeGame);
            setActiveGame(null);
          }}
          onlineRoomData={activeRoomData}
          onlineSocket={activeSocket}
        />
      )}

      {/* 2. Online Lobby Modal */}
      {onlineLobbyGame && (
        <OnlineLobbyModal
          game={onlineLobbyGame}
          onClose={() => setOnlineLobbyGame(null)}
          onStartOnlineGame={handleStartOnlineGame}
        />
      )}

      {/* 3. AI Game Master Studio Modal */}
      {showAiQuestModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#121214] border border-white/10 rounded-3xl w-full max-w-xl p-6 shadow-2xl text-slate-200">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-amber-400" />
                <h3 className="text-lg font-black text-white">Gemini AI Game Generator</h3>
              </div>
              <button onClick={() => setShowAiQuestModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Type any theme or scenario to instantly generate a playable custom mini-game powered by Gemini AI.
            </p>

            <div className="flex gap-2 mb-6">
              <input
                type="text"
                value={aiPromptInput}
                onChange={e => setAiPromptInput(e.target.value)}
                placeholder="E.g., Space Alien Invasion, Sci-Fi Detective Trivia, Fantasy Dungeon..."
                className="flex-1 bg-[#1a1a1e] border border-white/10 px-4 py-2.5 rounded-xl text-white text-xs outline-none focus:border-indigo-500"
              />
              <button
                onClick={handleGenerateAiQuest}
                disabled={loadingAiQuest}
                className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg active:scale-95 disabled:opacity-50"
              >
                {loadingAiQuest ? 'Generating...' : 'Create Game'}
              </button>
            </div>

            {aiCustomGameData && (
              <div className="bg-[#1a1a1e] p-4 rounded-2xl border border-white/5 space-y-3">
                <h4 className="text-sm font-bold text-amber-400">{aiCustomGameData.title}</h4>
                <p className="text-xs text-slate-300">{aiCustomGameData.instructions || aiCustomGameData.tagline}</p>
                <button
                  onClick={() => {
                    setShowAiQuestModal(false);
                    // Launch trivia royale with this generated prompt
                    const customGameItem: GameItem = {
                      id: 'ai_custom_game',
                      title: aiCustomGameData.title || 'AI Generated Quest',
                      category: 'Party',
                      description: aiCustomGameData.tagline || 'Custom AI Generated Game',
                      playersMin: 1,
                      playersMax: 4,
                      modes: ['offline', 'bot'],
                      controlType: 'trivia',
                      rating: 5.0,
                      playsCount: 1,
                      tags: ['AI Generated'],
                      thumbnailGradient: 'from-amber-500 to-purple-800',
                      iconName: 'Sparkles',
                      instructions: aiCustomGameData.instructions || 'Answer questions and solve AI puzzles.',
                      builtInEngine: 'trivia'
                    };
                    setActiveGame(customGameItem);
                  }}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md"
                >
                  Launch Generated AI Game →
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
