export type GameCategory = 
  | 'Board'
  | 'Arcade'
  | 'Puzzle'
  | 'Card'
  | 'Party'
  | 'Strategy'
  | 'Sports'
  | 'Retro'
  | 'Action'
  | 'RPG'
  | 'Casual';

export type GameControlMode = 
  | 'turn-based' 
  | 'split-keys' 
  | 'canvas-mouse' 
  | 'reaction' 
  | 'trivia';

export interface GameItem {
  id: string;
  title: string;
  category: GameCategory;
  description: string;
  playersMin: number;
  playersMax: number;
  modes: ('offline' | 'online' | 'bot')[];
  controlType: GameControlMode;
  rating: number;
  playsCount: number;
  tags: string[];
  thumbnailGradient: string;
  thumbnailUrl?: string;
  iconName: string;
  instructions: string;
  featured?: boolean;
  builtInEngine?: string; // e.g. 'connect4', 'snake', 'pong', 'tictactoe', 'dotsboxes', 'battleship', 'trivia', 'typing', 'memory', 'checkers', 'procedural'
}

export interface PlayerProfile {
  id: string;
  name: string;
  avatar: string;
  level: number;
  xp: number;
  coins: number;
  matchesPlayed: number;
  wins: number;
  favoriteGames: string[];
  recentHistory: {
    gameId: string;
    gameTitle: string;
    result: 'win' | 'loss' | 'draw';
    score: number;
    date: string;
  }[];
}

export interface ChatMessage {
  sender: string;
  text: string;
  time: string;
}

export interface OnlinePlayer {
  id: string;
  name: string;
  avatar: string;
  ready: boolean;
  score: number;
  isHost: boolean;
}

export interface OnlineRoomData {
  code: string;
  gameId: string;
  gameTitle: string;
  hostId: string;
  maxPlayers: number;
  status: 'lobby' | 'playing' | 'finished';
  gameState: any;
  messages: ChatMessage[];
  players: OnlinePlayer[];
}
