import express from 'express';
import path from 'path';
import { createServer as createHttpServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;
const httpServer = createHttpServer(app);

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini AI Client lazily/safely on server side
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health Check API
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', serverTime: new Date().toISOString() });
});

// AI Game Master & Dynamic Quiz Generator API
app.post('/api/gemini/ai-game-master', async (req, res) => {
  try {
    const { prompt, action, category } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Fallback response if API key is not yet configured
      return res.json({
        success: true,
        source: 'preset_fallback',
        message: 'Using preset engine data (Add GEMINI_API_KEY in Secrets for live AI generation).',
        gameData: {
          title: `AI Quest: ${category || 'Cyber Arcade'}`,
          description: prompt || 'Solve challenges, score points, and outsmart your opponent!',
          questions: [
            { question: 'What is the speed of light in vacuum?', options: ['299,792 km/s', '150,000 km/s', '1,080,000 km/s', '3,000 km/s'], correctIndex: 0, explanation: 'Light travels at approximately 299,792 km/s in a vacuum.' },
            { question: 'Which retro arcade game featured ghosts named Blinky, Pinky, Inky, and Clyde?', options: ['Pac-Man', 'Space Invaders', 'Donkey Kong', 'Galaga'], correctIndex: 0, explanation: 'Pac-Man was released by Namco in 1980.' },
            { question: 'In strategy games, what does 4X stand for?', options: ['Explore, Expand, Exploit, Exterminate', 'Exit, Execute, Excel, Exceed', 'Extra, Extreme, Explosive, Express', 'Engine, Energy, Element, Entropy'], correctIndex: 0, explanation: '4X is a subgenre of strategy video and board games.' }
          ]
        }
      });
    }

    if (action === 'generate_trivia') {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `Generate 5 fun, engaging multiple-choice trivia questions for a gaming hub. Topic/Topic details: "${prompt || category || 'General Video Games & Pop Culture'}".
Format response purely as JSON matching this structure:
{
  "title": "Short catchy title",
  "questions": [
    {
      "question": "Question text?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctIndex": 0,
      "explanation": "Brief fun fact explanation."
    }
  ]
}`,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const text = response.text || '{}';
      const parsed = JSON.parse(text);
      return res.json({ success: true, gameData: parsed });
    } else if (action === 'game_strategy_tips') {
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `Provide 3 pro strategy tips and winning tactics for playing the game "${prompt}". Keep it concise, punchy, and formatted with bullet points.`
      });
      return res.json({ success: true, tips: response.text });
    } else {
      // General custom AI game generator
      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: `The user wants a custom playable mini-game created on demand based on this prompt: "${prompt}".
Generate a structured JSON configuration for a custom mini-game:
{
  "title": "Game Title",
  "tagline": "Short cool tagline",
  "category": "Party/Puzzle/Action/Strategy",
  "instructions": "Simple rules on how to play",
  "gameType": "trivia_quiz OR word_guess OR reaction_challenge OR choice_adventure",
  "triviaQuestions": [
    {
      "question": "Q1?",
      "options": ["A", "B", "C", "D"],
      "correctIndex": 0,
      "explanation": "Why"
    }
  ],
  "adventureNodes": [
    {
      "id": "start",
      "text": "Story intro text...",
      "choices": [
        {"text": "Option 1", "nextId": "node2", "isWin": false},
        {"text": "Option 2", "nextId": "node3", "isWin": true}
      ]
    }
  ]
}`,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const text = response.text || '{}';
      const parsed = JSON.parse(text);
      return res.json({ success: true, gameData: parsed });
    }
  } catch (error: any) {
    console.error('Error calling Gemini API:', error);
    res.status(500).json({ success: false, error: error.message || 'Failed to call AI Service' });
  }
});

// WebSockets & Room Management
interface PlayerSocket {
  id: string;
  name: string;
  avatar: string;
  ws: WebSocket;
  ready: boolean;
  score: number;
}

interface Room {
  code: string;
  gameId: string;
  gameTitle: string;
  hostId: string;
  players: PlayerSocket[];
  maxPlayers: number;
  status: 'lobby' | 'playing' | 'finished';
  gameState: any;
  messages: Array<{ sender: string; text: string; time: string }>;
  createdAt: number;
}

const rooms = new Map<string, Room>();

// Cleanup stale rooms older than 3 hours
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms.entries()) {
    if (room.players.length === 0 || now - room.createdAt > 3 * 3600 * 1000) {
      rooms.delete(code);
    }
  }
}, 60000);

// Helper to broadcast room state to all players in a room
function broadcastToRoom(room: Room, message: any) {
  const payload = JSON.stringify(message);
  room.players.forEach(p => {
    if (p.ws.readyState === WebSocket.OPEN) {
      p.ws.send(payload);
    }
  });
}

function sanitizeRoomForClient(room: Room) {
  return {
    code: room.code,
    gameId: room.gameId,
    gameTitle: room.gameTitle,
    hostId: room.hostId,
    maxPlayers: room.maxPlayers,
    status: room.status,
    gameState: room.gameState,
    messages: room.messages,
    players: room.players.map(p => ({
      id: p.id,
      name: p.name,
      avatar: p.avatar,
      ready: p.ready,
      score: p.score,
      isHost: p.id === room.hostId
    }))
  };
}

// REST endpoint to get active public rooms
app.get('/api/rooms', (req, res) => {
  const activeRooms = Array.from(rooms.values()).map(r => ({
    code: r.code,
    gameId: r.gameId,
    gameTitle: r.gameTitle,
    playerCount: r.players.length,
    maxPlayers: r.maxPlayers,
    status: r.status,
    hostName: r.players.find(p => p.id === r.hostId)?.name || 'Host'
  }));
  res.json({ rooms: activeRooms });
});

// Attach WebSocket server to HTTP server
const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

wss.on('connection', (ws: WebSocket) => {
  let socketPlayerId: string | null = null;
  let currentRoomCode: string | null = null;

  ws.on('message', (rawMessage: Buffer) => {
    try {
      const data = JSON.parse(rawMessage.toString());
      const { type, payload } = data;

      switch (type) {
        case 'CREATE_ROOM': {
          const { gameId, gameTitle, playerName, avatar, maxPlayers = 2 } = payload;
          const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
          const playerId = `usr_${Math.random().toString(36).substring(2, 9)}`;

          socketPlayerId = playerId;
          currentRoomCode = roomCode;

          const newPlayer: PlayerSocket = {
            id: playerId,
            name: playerName || 'Player 1',
            avatar: avatar || '🎮',
            ws,
            ready: true, // Host is ready by default
            score: 0
          };

          const newRoom: Room = {
            code: roomCode,
            gameId: gameId || 'connect4',
            gameTitle: gameTitle || 'Connect Four',
            hostId: playerId,
            players: [newPlayer],
            maxPlayers: maxPlayers,
            status: 'lobby',
            gameState: { turnIndex: 0, board: null, winner: null },
            messages: [{ sender: 'System', text: `Room ${roomCode} created. Share code to invite friends!`, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }],
            createdAt: Date.now()
          };

          rooms.set(roomCode, newRoom);

          ws.send(JSON.stringify({
            type: 'ROOM_JOINED',
            payload: { playerId, room: sanitizeRoomForClient(newRoom) }
          }));
          break;
        }

        case 'JOIN_ROOM': {
          const { roomCode, playerName, avatar } = payload;
          const cleanCode = (roomCode || '').trim().toUpperCase();
          const room = rooms.get(cleanCode);

          if (!room) {
            ws.send(JSON.stringify({ type: 'ERROR', payload: { message: `Room '${cleanCode}' not found.` } }));
            return;
          }

          if (room.players.length >= room.maxPlayers) {
            ws.send(JSON.stringify({ type: 'ERROR', payload: { message: 'Room is full!' } }));
            return;
          }

          const playerId = `usr_${Math.random().toString(36).substring(2, 9)}`;
          socketPlayerId = playerId;
          currentRoomCode = cleanCode;

          const newPlayer: PlayerSocket = {
            id: playerId,
            name: playerName || `Player ${room.players.length + 1}`,
            avatar: avatar || '🕹️',
            ws,
            ready: false,
            score: 0
          };

          room.players.push(newPlayer);
          room.messages.push({
            sender: 'System',
            text: `${newPlayer.name} joined the room!`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });

          ws.send(JSON.stringify({
            type: 'ROOM_JOINED',
            payload: { playerId, room: sanitizeRoomForClient(room) }
          }));

          broadcastToRoom(room, {
            type: 'ROOM_UPDATED',
            payload: { room: sanitizeRoomForClient(room) }
          });
          break;
        }

        case 'TOGGLE_READY': {
          if (!currentRoomCode) return;
          const room = rooms.get(currentRoomCode);
          if (!room) return;

          const player = room.players.find(p => p.id === socketPlayerId);
          if (player) {
            player.ready = !player.ready;
            broadcastToRoom(room, {
              type: 'ROOM_UPDATED',
              payload: { room: sanitizeRoomForClient(room) }
            });
          }
          break;
        }

        case 'START_GAME': {
          if (!currentRoomCode) return;
          const room = rooms.get(currentRoomCode);
          if (!room || room.hostId !== socketPlayerId) return;

          room.status = 'playing';
          room.gameState = {
            turnIndex: 0,
            activePlayerId: room.players[0].id,
            board: payload?.initialState || null,
            winner: null,
            startedAt: Date.now()
          };

          room.messages.push({
            sender: 'System',
            text: 'Game started! Good luck players!',
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          });

          broadcastToRoom(room, {
            type: 'GAME_STARTED',
            payload: { room: sanitizeRoomForClient(room) }
          });
          break;
        }

        case 'GAME_MOVE': {
          if (!currentRoomCode) return;
          const room = rooms.get(currentRoomCode);
          if (!room) return;

          // Broadcast move payload to all room participants
          room.gameState = { ...room.gameState, ...payload };
          
          if (payload.turnNext) {
            const currentIndex = room.players.findIndex(p => p.id === socketPlayerId);
            const nextIndex = (currentIndex + 1) % room.players.length;
            room.gameState.turnIndex = nextIndex;
            room.gameState.activePlayerId = room.players[nextIndex].id;
          }

          if (payload.winnerId) {
            const winner = room.players.find(p => p.id === payload.winnerId);
            if (winner) winner.score += 100;
          }

          broadcastToRoom(room, {
            type: 'GAME_MOVE_APPLIED',
            payload: {
              move: payload,
              gameState: room.gameState,
              senderId: socketPlayerId,
              room: sanitizeRoomForClient(room)
            }
          });
          break;
        }

        case 'SEND_CHAT': {
          if (!currentRoomCode) return;
          const room = rooms.get(currentRoomCode);
          if (!room) return;

          const player = room.players.find(p => p.id === socketPlayerId);
          const msgText = (payload.text || '').trim();
          if (msgText && player) {
            const chatMsg = {
              sender: player.name,
              text: msgText,
              time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            };
            room.messages.push(chatMsg);
            broadcastToRoom(room, {
              type: 'CHAT_RECEIVED',
              payload: { message: chatMsg, messages: room.messages }
            });
          }
          break;
        }

        case 'LEAVE_ROOM': {
          handleLeaveRoom(socketPlayerId, currentRoomCode);
          socketPlayerId = null;
          currentRoomCode = null;
          break;
        }
      }
    } catch (err) {
      console.error('WebSocket Error:', err);
    }
  });

  ws.on('close', () => {
    if (socketPlayerId && currentRoomCode) {
      handleLeaveRoom(socketPlayerId, currentRoomCode);
    }
  });
});

function handleLeaveRoom(playerId: string | null, roomCode: string | null) {
  if (!playerId || !roomCode) return;
  const room = rooms.get(roomCode);
  if (!room) return;

  room.players = room.players.filter(p => p.id !== playerId);
  if (room.players.length === 0) {
    rooms.delete(roomCode);
  } else {
    // If host left, assign new host
    if (room.hostId === playerId) {
      room.hostId = room.players[0].id;
      room.players[0].ready = true;
    }
    room.messages.push({
      sender: 'System',
      text: 'A player left the room.',
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
    broadcastToRoom(room, {
      type: 'ROOM_UPDATED',
      payload: { room: sanitizeRoomForClient(room) }
    });
  }
}

// Vite or Static Server Setup
async function startAppServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`GameHub Universe Server listening on http://0.0.0.0:${PORT}`);
  });
}

startAppServer();
